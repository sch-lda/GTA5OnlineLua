local utils = require("worryfree/api/utils")
local api = {}

-- 内存操作
api.memory = {
    -- 读取内存值
    read_int = function(address)
        return memory.read_int(address)
    end,
    
    read_float = function(address)
        return memory.read_float(address)
    end,
    
    read_byte = function(address)
        return memory.read_byte(address)
    end,
    
    -- 写入内存值
    write_int = function(address, value)
        memory.write_int(address, value)
    end,
    
    write_float = function(address, value)
        memory.write_float(address, value)
    end,
    
    write_byte = function(address, value)
        memory.write_byte(address, value)
    end,
    
    -- 模式扫描
    pattern_scan = function(pattern)
        return memory.pattern_scan(pattern)
    end
}

-- 进程操作
api.process = {
    -- 获取基址
    get_base = function()
        return memory.get_base_address()
    end,
    
    -- 获取模块基址
    get_module = function(name)
        return memory.get_module_base(name)
    end
}

-- 玩家操作
api.player = {
    -- 获取玩家坐标
    get_position = function()
        local ped = PLAYER.PLAYER_PED_ID()
        return ENTITY.GET_ENTITY_COORDS(ped, true)
    end,
    
    -- 设置玩家坐标
    set_position = function(x, y, z)
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_COORDS(ped, x, y, z, false, false, false, false)
    end,
    
    -- 获取玩家朝向
    get_heading = function()
        local ped = PLAYER.PLAYER_PED_ID()
        return ENTITY.GET_ENTITY_HEADING(ped)
    end,
    
    -- 设置玩家朝向
    set_heading = function(heading)
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_HEADING(ped, heading)
    end,
    
    -- 获取玩家生命值
    get_health = function()
        local ped = PLAYER.PLAYER_PED_ID()
        return ENTITY.GET_ENTITY_HEALTH(ped)
    end,
    
    -- 设置玩家生命值
    set_health = function(health)
        local ped = PLAYER.PLAYER_PED_ID()
        ENTITY.SET_ENTITY_HEALTH(ped, health)
    end,

    -- 获取玩家PED
    get_ped = function()
        return PLAYER.PLAYER_PED_ID()
    end,

    -- 获取玩家ID
    get_id = function()
        return PLAYER.PLAYER_ID()
    end,

    -- 设置玩家无敌
    set_godmode = function(enabled)
        local ped = api.player.get_ped()
        ENTITY.SET_ENTITY_INVINCIBLE(ped, enabled)
        ENTITY.SET_ENTITY_PROOFS(ped, enabled, enabled, enabled, enabled, enabled, enabled, enabled, enabled)
        PED.SET_PED_CAN_RAGDOLL(ped, not enabled)
    end,

    -- 设置通缉等级
    set_wanted_level = function(level)
        PLAYER.SET_PLAYER_WANTED_LEVEL(api.player.get_id(), level, false)
        PLAYER.SET_PLAYER_WANTED_LEVEL_NOW(api.player.get_id(), false)
    end
}

-- 武器操作
api.weapon = {
    -- 给予武器
    give = function(hash_or_name, ammo)
        local hash = type(hash_or_name) == "string" and MISC.GET_HASH_KEY(hash_or_name) or hash_or_name
        WEAPON.GIVE_WEAPON_TO_PED(api.player.get_ped(), hash, ammo or 9999, false, true)
    end,
    
    -- 移除武器
    remove = function(hash_or_name)
        local hash = type(hash_or_name) == "string" and MISC.GET_HASH_KEY(hash_or_name) or hash_or_name
        WEAPON.REMOVE_WEAPON_FROM_PED(api.player.get_ped(), hash)
    end,
    
    -- 设置弹药
    set_ammo = function(hash_or_name, ammo)
        local hash = type(hash_or_name) == "string" and MISC.GET_HASH_KEY(hash_or_name) or hash_or_name
        WEAPON.SET_PED_AMMO(api.player.get_ped(), hash, ammo)
    end
}

-- 载具操作
api.vehicle = {
    -- 创建载具
    create = function(model, coords, heading)
        local hash = MISC.GET_HASH_KEY(model)
        STREAMING.REQUEST_MODEL(hash)
        while not STREAMING.HAS_MODEL_LOADED(hash) do
            utils.yield()
        end
        local vehicle = VEHICLE.CREATE_VEHICLE(hash, coords.x, coords.y, coords.z, heading, true, false)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
        return vehicle
    end,
    
    -- 获取当前载具
    get_current = function()
        return PED.GET_VEHICLE_PED_IS_IN(api.player.get_ped(), false)
    end,
    
    -- 修改载具
    modify = function(vehicle, mods)
        if not api.utils.is_entity_valid(vehicle) then return end
        VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
        for mod_type, mod_index in pairs(mods) do
            VEHICLE.SET_VEHICLE_MOD(vehicle, mod_type, mod_index, false)
        end
    end
}

-- 游戏世界操作
api.world = {
    -- 设置时间
    set_time = function(hour, minute, second)
        NETWORK.NETWORK_OVERRIDE_CLOCK_TIME(hour, minute, second)
    end,
    
    -- 设置天气
    set_weather = function(weather_type)
        MISC.SET_WEATHER_TYPE_NOW_PERSIST(weather_type)
    end,
    
    -- 创建NPC
    create_ped = function(model, x, y, z, heading)
        local hash = MISC.GET_HASH_KEY(model)
        STREAMING.REQUEST_MODEL(hash)
        while not STREAMING.HAS_MODEL_LOADED(hash) do
            util.yield()
        end
        local ped = PED.CREATE_PED(26, hash, x, y, z, heading, true, false)
        STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
        return ped
    end
}

-- 任务操作
api.mission = {
    -- 设置任务状态
    set_status = function(mission_name, status)
        stats.set_int(api.utils.get_mp_prefix() .. mission_name, status)
    end,
    
    -- 移除冷却时间
    remove_cooldown = function(mission_name)
        stats.set_int(api.utils.get_mp_prefix() .. mission_name .. "_COOLDOWN", 0)
    end
}

-- 基础功能API
api.natives = {
    -- 玩家相关
    player = {
        -- 获取玩家坐标
        get_position = function()
            local ped = PLAYER.PLAYER_PED_ID()
            return ENTITY.GET_ENTITY_COORDS(ped, true)
        end,
        
        -- 设置玩家坐标
        set_position = function(x, y, z)
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_COORDS(ped, x, y, z, false, false, false, false)
        end,
        
        -- 获取玩家朝向
        get_heading = function()
            local ped = PLAYER.PLAYER_PED_ID()
            return ENTITY.GET_ENTITY_HEADING(ped)
        end,
        
        -- 设置玩家朝向
        set_heading = function(heading)
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_HEADING(ped, heading)
        end,
        
        -- 获取玩家生命值
        get_health = function()
            local ped = PLAYER.PLAYER_PED_ID()
            return ENTITY.GET_ENTITY_HEALTH(ped)
        end,
        
        -- 设置玩家生命值
        set_health = function(health)
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_HEALTH(ped, health)
        end
    },

    -- 载具相关
    vehicle = {
        -- 创建载具
        create = function(model, x, y, z, heading)
            local hash = MISC.GET_HASH_KEY(model)
            STREAMING.REQUEST_MODEL(hash)
            while not STREAMING.HAS_MODEL_LOADED(hash) do
                util.yield()
            end
            local vehicle = VEHICLE.CREATE_VEHICLE(hash, x, y, z, heading, true, false)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
            return vehicle
        end,
        
        -- 获取当前载具
        get_current = function()
            local ped = PLAYER.PLAYER_PED_ID()
            return PED.GET_VEHICLE_PED_IS_IN(ped, false)
        end,
        
        -- 修改载具性能
        modify = function(vehicle, mods)
            VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
            for mod_type, mod_index in pairs(mods) do
                VEHICLE.SET_VEHICLE_MOD(vehicle, mod_type, mod_index, false)
            end
        end
    },

    -- 武器相关
    weapon = {
        -- 给予武器
        give = function(weapon_name, ammo)
            local ped = PLAYER.PLAYER_PED_ID()
            local hash = MISC.GET_HASH_KEY(weapon_name)
            WEAPON.GIVE_WEAPON_TO_PED(ped, hash, ammo, false, true)
        end,
        
        -- 移除武器
        remove = function(weapon_name)
            local ped = PLAYER.PLAYER_PED_ID()
            local hash = MISC.GET_HASH_KEY(weapon_name)
            WEAPON.REMOVE_WEAPON_FROM_PED(ped, hash)
        end,
        
        -- 设置弹药
        set_ammo = function(weapon_name, ammo)
            local ped = PLAYER.PLAYER_PED_ID()
            local hash = MISC.GET_HASH_KEY(weapon_name)
            WEAPON.SET_PED_AMMO(ped, hash, ammo)
        end
    },

    -- 世界相关
    world = {
        -- 设置时间
        set_time = function(hour, minute, second)
            NETWORK.NETWORK_OVERRIDE_CLOCK_TIME(hour, minute, second)
        end,
        
        -- 设置天气
        set_weather = function(weather_type)
            MISC.SET_WEATHER_TYPE_NOW_PERSIST(weather_type)
        end,
        
        -- 创建NPC
        create_ped = function(model, x, y, z, heading)
            local hash = MISC.GET_HASH_KEY(model)
            STREAMING.REQUEST_MODEL(hash)
            while not STREAMING.HAS_MODEL_LOADED(hash) do
                util.yield()
            end
            local ped = PED.CREATE_PED(26, hash, x, y, z, heading, true, false)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
            return ped
        end
    },

    -- 任务相关
    mission = {
        -- 设置任务状态
        set_status = function(mission_name, status)
            stats.set_int(MPX() .. mission_name, status)
        end,
        
        -- 移除冷却时间
        remove_cooldown = function(mission_name)
            stats.set_int(MPX() .. mission_name .. "_COOLDOWN", 0)
        end
    }
}

-- 扩展功能API
api.extended = {
    -- 自定义传送功能
    teleport = {
        to_coords = function(x, y, z)
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                local vehicle = PED.GET_VEHICLE_PED_IS_IN(ped, false)
                ENTITY.SET_ENTITY_COORDS(vehicle, x, y, z, false, false, false, false)
            else
                ENTITY.SET_ENTITY_COORDS(ped, x, y, z, false, false, false, false)
            end
        end,
        
        to_waypoint = function()
            local blip = HUD.GET_FIRST_BLIP_INFO_ID(8)
            if HUD.DOES_BLIP_EXIST(blip) then
                local coords = HUD.GET_BLIP_COORDS(blip)
                api.extended.teleport.to_coords(coords.x, coords.y, coords.z)
            end
        end
    },
    
    -- 自定义特效
    effects = {
        -- 创建爆炸
        create_explosion = function(x, y, z, type, damage, audible, invisible, shake)
            FIRE.ADD_EXPLOSION(x, y, z, type, damage, audible, invisible, shake, false)
        end,
        
        -- 创建粒子效果
        create_particle = function(asset, effect_name, x, y, z, scale)
            STREAMING.REQUEST_NAMED_PTFX_ASSET(asset)
            while not STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(asset) do
                util.yield()
            end
            GRAPHICS.USE_PARTICLE_FX_ASSET(asset)
            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(
                effect_name,
                x, y, z,
                0.0, 0.0, 0.0,
                scale,
                false, false, false,
                false
            )
        end
    }
}

-- 工具函数
api.utils = {
    -- 获取当前角色
    get_char_slot = function()
        return stats.get_int("MPPLY_LAST_MP_CHAR")
    end,

    -- 获取MP前缀
    get_mp_prefix = function()
        return "MP" .. api.utils.get_char_slot() .. "_"
    end,

    -- 检查实体是否存在
    is_entity_valid = function(entity)
        return entity ~= nil and ENTITY.DOES_ENTITY_EXIST(entity)
    end,

    -- 获取玩家坐标
    get_player_coords = function()
        local ped = PLAYER.PLAYER_PED_ID()
        return ENTITY.GET_ENTITY_COORDS(ped, true)
    end,

    -- 计算两点之间距离
    get_distance = function(pos1, pos2)
        return MISC.GET_DISTANCE_BETWEEN_COORDS(
            pos1.x, pos1.y, pos1.z,
            pos2.x, pos2.y, pos2.z,
            true
        )
    end,

    -- 创建向量
    v3 = function(x, y, z)
        return {x = x or 0, y = y or 0, z = z or 0}
    end
}

-- UI相关核心功能
api.ui = {
    -- 显示通知
    notify = function(message, title)
        gui.show_message(title or "Worryfree", message)
    end,

    -- 显示帮助文本
    show_help = function(message, duration)
        HUD.BEGIN_TEXT_COMMAND_DISPLAY_HELP("STRING")
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(message)
        HUD.END_TEXT_COMMAND_DISPLAY_HELP(0, false, true, duration or 5000)
    end
}

return api 