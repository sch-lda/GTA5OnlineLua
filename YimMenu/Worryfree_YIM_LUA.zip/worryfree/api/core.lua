local core = {}

-- 内存操作
core.memory = {
    -- 读取内存值
    read_int = function(address)
        return memory.read_int(address)
    end,
    
    read_float = function(address)
        return memory.read_float(address)
    end,
    
    read_byte = function(address)
        return memory.read_byte(address)
    end,
    
    -- 写入内存值
    write_int = function(address, value)
        memory.write_int(address, value)
    end,
    
    write_float = function(address, value)
        memory.write_float(address, value)
    end,
    
    write_byte = function(address, value)
        memory.write_byte(address, value)
    end,
    
    -- 模式扫描
    pattern_scan = function(pattern)
        return memory.pattern_scan(pattern)
    end
}

-- 进程操作
core.process = {
    -- 获取基址
    get_base = function()
        return memory.get_base_address()
    end,
    
    -- 获取模块基址
    get_module = function(name)
        return memory.get_module_base(name)
    end
}

-- 玩家操作
core.player = {
    -- 获取玩家坐标
    get_position = function()
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                local x = core.memory.read_float(player + 0x50)
                local y = core.memory.read_float(player + 0x54)
                local z = core.memory.read_float(player + 0x58)
                return {x = x, y = y, z = z}
            end
        end
        return nil
    end,
    
    -- 设置玩家坐标
    set_position = function(x, y, z)
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                core.memory.write_float(player + 0x50, x)
                core.memory.write_float(player + 0x54, y)
                core.memory.write_float(player + 0x58, z)
            end
        end
    end,
    
    -- 获取玩家生命值
    get_health = function()
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                return core.memory.read_float(player + 0x280)
            end
        end
        return 0
    end,
    
    -- 设置玩家生命值
    set_health = function(value)
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                core.memory.write_float(player + 0x280, value)
            end
        end
    end
}

-- 武器操作
core.weapon = {
    -- 获取当前武器
    get_current = function()
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                return core.memory.read_int(player + 0x780)
            end
        end
        return 0
    end,
    
    -- 设置武器弹药
    set_ammo = function(value)
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                local weapon = core.memory.read_int(player + 0x780)
                if weapon then
                    core.memory.write_int(weapon + 0x60, value)
                end
            end
        end
    end
}

-- 载具操作
core.vehicle = {
    -- 获取当前载具
    get_current = function()
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local player = core.memory.read_int(address + core.memory.read_int(address + 3) + 7)
            if player then
                return core.memory.read_int(player + 0xD30)
            end
        end
        return 0
    end,
    
    -- 修改载具速度
    set_speed = function(value)
        local vehicle = core.vehicle.get_current()
        if vehicle then
            core.memory.write_float(vehicle + 0x7C, value)
        end
    end,
    
    -- 修改载具重力
    set_gravity = function(value)
        local vehicle = core.vehicle.get_current()
        if vehicle then
            core.memory.write_float(vehicle + 0xC5C, value)
        end
    end
}

-- 游戏世界操作
core.world = {
    -- 修改游戏时间
    set_time = function(hour, minute)
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local time_addr = core.memory.read_int(address + core.memory.read_int(address + 3) + 7 + 0x10D8)
            if time_addr then
                core.memory.write_byte(time_addr + 0x10, hour)
                core.memory.write_byte(time_addr + 0x11, minute)
            end
        end
    end,
    
    -- 修改天气
    set_weather = function(type)
        local address = core.memory.pattern_scan("48 8B 05 ? ? ? ? 48 8B 48 08 48 85 C9 74 52")
        if address then
            local weather_addr = core.memory.read_int(address + core.memory.read_int(address + 3) + 7 + 0x11B8)
            if weather_addr then
                core.memory.write_int(weather_addr, type)
            end
        end
    end
}

return core 