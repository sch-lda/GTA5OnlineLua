local core = require("worryfree/api/core")
local ui = {}

-- 注入动画的配置
local INJECTION_SETTINGS = {
    duration = 3000,       -- 动画持续时间(毫秒)
    text_scale = 0.8,      -- 文本大小
    logo_size = 0.15,      -- logo大小
    circle_segments = 32,   -- 圆形分段数
    max_particles = 50,     -- 最大粒子数
    particle_speed = 0.01,  -- 粒子移动速度
    firework_count = 5,    -- 烟花数量
    red_packet_count = 8   -- 红包数量
}

-- 春节元素
local SPRING_FESTIVAL = {
    colors = {
        red = {r = 255, g = 40, b = 40},    -- 中国红
        gold = {r = 255, g = 215, b = 0},   -- 金色
    },
    texts = {
        "福", "春", "喜", "恭喜发财", "新年快乐"
    }
}

-- 粒子系统
local particles = {}
local fireworks = {}
local red_packets = {}

-- 创建新粒子(金色)
local function create_particle()
    local angle = math.random() * math.pi * 2
    return {
        x = 0.5 + math.cos(angle) * 0.3,
        y = 0.5 + math.sin(angle) * 0.3,
        speed_x = (math.random() - 0.5) * INJECTION_SETTINGS.particle_speed,
        speed_y = (math.random() - 0.5) * INJECTION_SETTINGS.particle_speed,
        size = math.random() * 0.004 + 0.002,
        alpha = math.random() * 155 + 100,
        color = SPRING_FESTIVAL.colors.gold
    }
end

-- 创建烟花
local function create_firework()
    return {
        x = math.random(),
        y = 1.2,
        speed_y = -0.005,
        exploded = false,
        particles = {},
        color = math.random() > 0.5 and SPRING_FESTIVAL.colors.red or SPRING_FESTIVAL.colors.gold
    }
end

-- 创建红包
local function create_red_packet()
    return {
        x = math.random(),
        y = -0.2,
        speed_y = 0.003,
        rotation = math.random() * 360,
        alpha = 255,
        scale = math.random() * 0.3 + 0.7
    }
end

-- 更新烟花
local function update_fireworks()
    for i = #fireworks, 1, -1 do
        local fw = fireworks[i]
        if not fw.exploded then
            fw.y = fw.y + fw.speed_y
            if fw.y <= math.random() * 0.3 + 0.3 then
                fw.exploded = true
                -- 创建烟花粒子
                for j = 1, 20 do
                    local angle = (j / 20) * math.pi * 2
                    table.insert(fw.particles, {
                        x = fw.x,
                        y = fw.y,
                        speed_x = math.cos(angle) * 0.01,
                        speed_y = math.sin(angle) * 0.01,
                        alpha = 255,
                        size = 0.005
                    })
                end
            end
        else
            -- 更新烟花粒子
            for j = #fw.particles, 1, -1 do
                local p = fw.particles[j]
                p.x = p.x + p.speed_x
                p.y = p.y + p.speed_y
                p.alpha = p.alpha - 5
                if p.alpha <= 0 then
                    table.remove(fw.particles, j)
                end
            end
            if #fw.particles == 0 then
                table.remove(fireworks, i)
            end
        end
    end
    
    -- 添加新烟花
    if #fireworks < INJECTION_SETTINGS.firework_count then
        table.insert(fireworks, create_firework())
    end
end

-- 更新红包
local function update_red_packets()
    for i = #red_packets, 1, -1 do
        local rp = red_packets[i]
        rp.y = rp.y + rp.speed_y
        rp.rotation = rp.rotation + 2
        if rp.y > 1.2 then
            table.remove(red_packets, i)
        end
    end
    
    -- 添加新红包
    if #red_packets < INJECTION_SETTINGS.red_packet_count then
        table.insert(red_packets, create_red_packet())
    end
end

-- 绘制注入动画
function ui.play_injection_animation()
    local start_time = os.clock() * 1000
    local screen_w, screen_h = GRAPHICS.GET_SCREEN_RESOLUTION(0, 0)
    
    -- 注册动画循环
    script.register_looped("InjectionAnimation", function()
        local current_time = os.clock() * 1000
        local elapsed = current_time - start_time
        
        if elapsed >= INJECTION_SETTINGS.duration then
            return false  -- 停止动画
        end
        
        -- 计算动画进度 (0-1)
        local progress = math.min(elapsed / INJECTION_SETTINGS.duration, 1.0)
        local fade_alpha = math.min(progress * 2, 1.0) * 255
        
        -- 绘制背景遮罩(使用半透明红色)
        GRAPHICS.DRAW_RECT(0.5, 0.5, 1.0, 1.0, 40, 0, 0, math.floor(fade_alpha * 0.8))
        
        -- 更新和绘制烟花
        update_fireworks()
        for _, fw in ipairs(fireworks) do
            if not fw.exploded then
                GRAPHICS.DRAW_RECT(fw.x, fw.y, 0.005, 0.005, 
                    fw.color.r, fw.color.g, fw.color.b, fade_alpha)
            else
                for _, p in ipairs(fw.particles) do
                    GRAPHICS.DRAW_RECT(p.x, p.y, p.size, p.size,
                        fw.color.r, fw.color.g, fw.color.b, 
                        math.floor(p.alpha * (fade_alpha/255)))
                end
            end
        end
        
        -- 更新和绘制红包
        update_red_packets()
        for _, rp in ipairs(red_packets) do
            -- 绘制红包(红色矩形)
            GRAPHICS.DRAW_RECT(rp.x, rp.y, 0.05 * rp.scale, 0.08 * rp.scale,
                SPRING_FESTIVAL.colors.red.r,
                SPRING_FESTIVAL.colors.red.g,
                SPRING_FESTIVAL.colors.red.b,
                math.floor(fade_alpha))
            
            -- 绘制福字
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("福")
            HUD.SET_TEXT_SCALE(0.3 * rp.scale, 0.3 * rp.scale)
            HUD.SET_TEXT_COLOUR(255, 215, 0, math.floor(fade_alpha))
            HUD.SET_TEXT_CENTRE(true)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(rp.x, rp.y - 0.01, 0)
        end
        
        -- 绘制加载圆环(金色)
        local radius = 0.05
        local segments = INJECTION_SETTINGS.circle_segments
        local rotation = (elapsed / 1000) * 360
        
        for i = 0, segments do
            local angle1 = ((i + rotation) / segments) * math.pi * 2
            local angle2 = ((i + 1 + rotation) / segments) * math.pi * 2
            
            local x1 = 0.5 + math.cos(angle1) * radius
            local y1 = 0.5 + math.sin(angle1) * radius
            local x2 = 0.5 + math.cos(angle2) * radius
            local y2 = 0.5 + math.sin(angle2) * radius
            
            GRAPHICS.DRAW_LINE(
                x1, y1, 0,
                x2, y2, 0,
                SPRING_FESTIVAL.colors.gold.r,
                SPRING_FESTIVAL.colors.gold.g,
                SPRING_FESTIVAL.colors.gold.b,
                math.floor(fade_alpha)
            )
        end
        
        -- 绘制进度条容器背景（磨砂玻璃效果）
        for i = 0, 15 do
            local alpha = math.floor((0.3 + i * 0.03) * fade_alpha * 0.8)
            local width = 0.32 - i * 0.001
            local height = 0.025 - i * 0.0005
            GRAPHICS.DRAW_RECT(
                0.5,    -- x center
                0.6,    -- y position
                width,   -- width
                height,   -- height
                20, 20, 20, alpha  -- 深灰色渐变
            )
        end
        
        -- 绘制主进度条背景
        GRAPHICS.DRAW_RECT(
            0.5,    -- x center
            0.6,    -- y position
            0.3,    -- width
            0.02,   -- height
            25, 25, 25, math.floor(fade_alpha * 0.95)  -- 深灰色
        )
        
        -- 绘制进度条动态光效
        local pulse = (1 + math.sin(elapsed / 200)) / 2  -- 脉冲效果
        local glow_alpha = math.floor((0.3 + pulse * 0.2) * fade_alpha)
        
        -- 进度条填充（主体）
        local fill_width = 0.3 * progress
        local fill_x = 0.5 - (0.3 - fill_width) / 2
        GRAPHICS.DRAW_RECT(
            fill_x,
            0.6,
            fill_width,
            0.02,
            SPRING_FESTIVAL.colors.red.r,
            SPRING_FESTIVAL.colors.red.g,
            SPRING_FESTIVAL.colors.red.b,
            math.floor(fade_alpha * 0.9)
        )
        
        -- 进度条前端光效
        local glow_x = 0.5 - (0.3 * (1 - progress)) / 2 + (0.3 * progress / 2)
        for i = 1, 8 do
            local glow_size = 0.008 * (9-i) / 8
            local glow_alpha = math.floor((0.4 - i * 0.05) * fade_alpha * (1 + pulse * 0.3))
            GRAPHICS.DRAW_RECT(
                glow_x,
                0.6,
                glow_size,
                0.02,
                255, 215, 0, glow_alpha  -- 金色光晕
            )
        end
        
        -- 进度条装饰纹理（斜线图案）
        local pattern_count = 30
        local pattern_width = fill_width / pattern_count
        for i = 0, pattern_count do
            local x = fill_x - fill_width/2 + i * pattern_width
            if x <= fill_x + fill_width/2 then
                GRAPHICS.DRAW_RECT(
                    x,
                    0.6,
                    0.001,
                    0.02,
                    255, 255, 255, math.floor(fade_alpha * 0.1)
                )
            end
        end
        
        -- 绘制边框装饰
        -- 外层金色边框
        local border_pulse = (1 + math.sin(elapsed / 300)) / 2  -- 边框脉冲
        local border_alpha = math.floor((0.7 + border_pulse * 0.3) * fade_alpha)
        GRAPHICS.DRAW_RECT(0.5, 0.6 - 0.012, 0.32, 0.002, 255, 215, 0, border_alpha)  -- 上边框
        GRAPHICS.DRAW_RECT(0.5, 0.6 + 0.012, 0.32, 0.002, 255, 215, 0, border_alpha)  -- 下边框
        GRAPHICS.DRAW_RECT(0.34, 0.6, 0.002, 0.024, 255, 215, 0, border_alpha)  -- 左边框
        GRAPHICS.DRAW_RECT(0.66, 0.6, 0.002, 0.024, 255, 215, 0, border_alpha)  -- 右边框
        
        -- 装饰角落（带动画效果）
        local corner_size = 0.005 * (1 + border_pulse * 0.2)  -- 角落大小随边框脉冲变化
        local corners = {
            {x = 0.34, y = 0.6 - 0.012},  -- 左上
            {x = 0.66, y = 0.6 - 0.012},  -- 右上
            {x = 0.34, y = 0.6 + 0.012},  -- 左下
            {x = 0.66, y = 0.6 + 0.012}   -- 右下
        }
        
        for _, corner in ipairs(corners) do
            -- 绘制角落装饰
            GRAPHICS.DRAW_RECT(
                corner.x + (corner.x > 0.5 and -corner_size/2 or corner_size/2),
                corner.y + (corner.y > 0.6 and -corner_size/2 or corner_size/2),
                corner_size,
                0.002,
                255, 215, 0, border_alpha
            )
            GRAPHICS.DRAW_RECT(
                corner.x + (corner.x > 0.5 and -corner_size/2 or corner_size/2),
                corner.y + (corner.y > 0.6 and -corner_size/2 or corner_size/2),
                0.002,
                corner_size,
                255, 215, 0, border_alpha
            )
        end
        
        -- 绘制文本
        local text_alpha = math.floor(math.sin(progress * math.pi) * fade_alpha)
        
        -- 绘制标题(金色)
        HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("Worryfree Menu 新年快乐")
        HUD.SET_TEXT_SCALE(INJECTION_SETTINGS.text_scale, INJECTION_SETTINGS.text_scale)
        HUD.SET_TEXT_COLOUR(255, 215, 0, text_alpha)
        HUD.SET_TEXT_CENTRE(true)
        HUD.SET_TEXT_DROPSHADOW(2, 0, 0, 0, text_alpha)
        HUD.END_TEXT_COMMAND_DISPLAY_TEXT(0.5, 0.45, 0)
        
        -- 绘制加载文本(红色)
        local loading_text = string.format("注入中... %.0f%% 恭喜发财", progress * 100)
        HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(loading_text)
        HUD.SET_TEXT_SCALE(INJECTION_SETTINGS.text_scale * 0.7, INJECTION_SETTINGS.text_scale * 0.7)
        HUD.SET_TEXT_COLOUR(255, 40, 40, text_alpha)
        HUD.SET_TEXT_CENTRE(true)
        HUD.SET_TEXT_DROPSHADOW(2, 0, 0, 0, text_alpha)
        HUD.END_TEXT_COMMAND_DISPLAY_TEXT(0.5, 0.55, 0)
    end)
end

-- 添加UI元素
function ui.add_elements(menu)
    -- 创建信息显示面板
    local info_panel = menu:add_tab("信息面板")
    
    -- 实时信息显示
    script.register_looped("InfoDisplay", function()
        -- 获取屏幕分辨率
        local screen_w, screen_h = GRAPHICS.GET_SCREEN_RESOLUTION(0, 0)
        
        -- 设置基础位置和大小
        local base_x = 0.01
        local base_y = 0.01
        local box_width = 0.2
        local box_height = 0.15
        local line_height = 0.02
        
        -- 绘制半透明背景
        GRAPHICS.DRAW_RECT(
            base_x + box_width/2, 
            base_y + box_height/2,
            box_width,
            box_height,
            0, 0, 0, 180
        )
        
        -- 绘制装饰边框(中国红)
        GRAPHICS.DRAW_RECT(
            base_x + box_width/2,
            base_y,
            box_width,
            0.003,
            SPRING_FESTIVAL.colors.red.r,
            SPRING_FESTIVAL.colors.red.g,
            SPRING_FESTIVAL.colors.red.b,
            255
        )
        
        -- 获取玩家信息
        local player_id = PLAYER.PLAYER_ID()
        local ped = PLAYER.PLAYER_PED_ID()
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(ped, false)
        
        -- 获取金钱信息
        local bank_money = stats.get_int("BANK_BALANCE")
        local cash_money = stats.get_int("MP0_WALLET_BALANCE")
        
        -- 获取时间信息
        local real_time = os.date("%H:%M:%S")
        local game_hours = CLOCK.GET_CLOCK_HOURS()
        local game_minutes = CLOCK.GET_CLOCK_MINUTES()
        local game_seconds = CLOCK.GET_CLOCK_SECONDS()
        local game_time = string.format("%02d:%02d:%02d", game_hours, game_minutes, game_seconds)
        
        -- 获取其他状态
        local health = ENTITY.GET_ENTITY_HEALTH(ped)
        local max_health = ENTITY.GET_ENTITY_MAX_HEALTH(ped)
        local armor = PED.GET_PED_ARMOUR(ped)
        local wanted_level = PLAYER.GET_PLAYER_WANTED_LEVEL(player_id)
        local speed = vehicle and math.floor(ENTITY.GET_ENTITY_SPEED(vehicle) * 3.6) or 0  -- km/h
        
        -- 定义显示文本
        local info_texts = {
            {"现实时间", real_time, SPRING_FESTIVAL.colors.gold},
            {"游戏时间", game_time, SPRING_FESTIVAL.colors.gold},
            {"银行现金", "$" .. utils.format_number(bank_money), {r=0, g=255, b=0}},
            {"现金", "$" .. utils.format_number(cash_money), {r=0, g=255, b=0}},
            {"生命值", string.format("%d/%d", health, max_health), {r=255, g=50, b=50}},
            {"护甲值", tostring(armor), {r=50, g=150, b=255}},
            {"通缉等级", string.format("%d★", wanted_level), {r=255, g=150, b=0}},
            vehicle and {"车速", speed .. " km/h", {r=255, g=255, b=255}} or nil
        }
        
        -- 绘制信息文本
        local current_y = base_y + 0.005
        for _, info in ipairs(info_texts) do
            if info then  -- 检查是否为nil
                local label, value, color = table.unpack(info)
                
                -- 绘制标签
                HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
                HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(label .. ":")
                HUD.SET_TEXT_SCALE(0.3, 0.3)
                HUD.SET_TEXT_COLOUR(255, 255, 255, 255)
                HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255)
                HUD.END_TEXT_COMMAND_DISPLAY_TEXT(base_x + 0.005, current_y, 0)
                
                -- 绘制值
                HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
                HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(value)
                HUD.SET_TEXT_SCALE(0.3, 0.3)
                HUD.SET_TEXT_COLOUR(color.r, color.g, color.b, 255)
                HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255)
                HUD.END_TEXT_COMMAND_DISPLAY_TEXT(base_x + 0.1, current_y, 0)
                
                current_y = current_y + line_height
            end
        end
    end)
    
    -- 标题
    menu:add_text("                   Worryfree Menu")
    menu:add_text("                      Version 1.4")
    menu:add_text("作者: Worryfree")
    
    -- 通知设置
    local notifications = menu:add_tab("通知设置")
    
    -- 通知开关
    local notify_enabled = notifications:add_checkbox("启用通知")
    notify_enabled:set_enabled(true)
    
    -- 通知位置
    local positions = {"左上", "右上", "左下", "右下", "中心"}
    local notify_position = notifications:add_combo_box("通知位置", positions)
    notify_position:set_selected_index(1)
    
    -- 通知持续时间
    local notify_duration = notifications:add_slider("通知持续时间(秒)", 1, 10)
    notify_duration:set_value(3)
    
    -- 测试通知
    notifications:add_button("测试通知", function()
        if notify_enabled:is_enabled() then
            core.ui.notify("这是一条测试通知", "测试")
        end
    end)
    
    -- 帮助文本设置
    local help_text = menu:add_tab("帮助文本")
    
    -- 帮助文本开关
    local help_enabled = help_text:add_checkbox("显示帮助文本")
    help_enabled:set_enabled(true)
    
    -- 帮助文本持续时间
    local help_duration = help_text:add_slider("显示持续时间(秒)", 1, 10)
    help_duration:set_value(5)
    
    -- 测试帮助文本
    help_text:add_button("测试帮助文本", function()
        if help_enabled:is_enabled() then
            core.ui.show_help("这是一条测试帮助文本", help_duration:get_value() * 1000)
        end
    end)
end

return ui 