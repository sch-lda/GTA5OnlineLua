-- UI模块
local ui = {}

-- 动画状态
local animation = {
    start_time = 0,
    duration = 3.0,
    is_playing = false,
    progress = 0
}

-- 播放注入动画
function ui.play_injection_animation()
    animation.start_time = os.clock()
    animation.is_playing = true
    
    -- 显示加载提示
    HUD.BEGIN_TEXT_COMMAND_BUSYSPINNER_ON("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("正在加载 Worryfree...")
    HUD.END_TEXT_COMMAND_BUSYSPINNER_ON(4)
    
    -- 等待一段时间
    coroutine.yield(1000)
    
    -- 关闭加载提示
    HUD.BUSYSPINNER_OFF()
    
    -- 显示欢迎消息和进度条
    local scaleform = GRAPHICS.REQUEST_SCALEFORM_MOVIE("MP_BIG_MESSAGE_FREEMODE")
    
    while not GRAPHICS.HAS_SCALEFORM_MOVIE_LOADED(scaleform) do
        coroutine.yield(0)
    end
    
    local start_time = os.clock()
    local duration = 3.0 -- 进度条持续时间
    
    while os.clock() - start_time < duration do
        local progress = (os.clock() - start_time) / duration
        
        -- 绘制背景
        GRAPHICS.DRAW_RECT(0.5, 0.5, 1.0, 1.0, 0, 0, 0, 200)
        
        -- 绘制标题
        HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("欢迎使用 Worryfree")
        HUD.END_TEXT_COMMAND_DISPLAY_TEXT(0.5, 0.4, 1.0)
        
        -- 绘制进度条背景
        GRAPHICS.DRAW_RECT(0.5, 0.5, 0.4, 0.02, 255, 255, 255, 255)
        
        -- 绘制进度条
        GRAPHICS.DRAW_RECT(0.3 + (0.4 * progress / 2), 0.5, 0.4 * progress, 0.02, 0, 127, 255, 255)
        
        -- 绘制进度文本
        local percent = math.floor(progress * 100)
        HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
        HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(string.format("加载中... %d%%", percent))
        HUD.END_TEXT_COMMAND_DISPLAY_TEXT(0.5, 0.55, 1.0)
        
        coroutine.yield(0)
    end
    
    -- 显示完成消息
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME("加载完成!")
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(0.5, 0.55, 1.0)
    coroutine.yield(1000)
    
    GRAPHICS.SET_SCALEFORM_MOVIE_AS_NO_LONGER_NEEDED(scaleform)
end

return ui 