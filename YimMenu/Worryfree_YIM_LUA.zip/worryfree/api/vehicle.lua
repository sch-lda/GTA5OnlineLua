local vehicle = {}

-- 载具生成器
function vehicle.add_vehicle_spawner(menu)
    -- 常用载具列表
    local vehicles = {
        ["超级跑车"] = {
            "t20",
            "zentorno",
            "adder",
            "nero",
            "tempesta"
        },
        ["跑车"] = {
            "elegy",
            "jester",
            "carbonizzare",
            "comet5",
            "feltzer2"
        },
        ["肌肉车"] = {
            "dominator",
            "dukes",
            "gauntlet",
            "vigero",
            "phoenix"
        },
        ["SUV"] = {
            "baller",
            "granger",
            "huntley",
            "patriot",
            "xls"
        },
        ["军用载具"] = {
            "rhino",
            "khanjali",
            "apc",
            "insurgent",
            "barrage"
        }
    }

    -- 创建载具生成菜单
    local spawner = menu:add_tab("载具生成器")
    for category, models in pairs(vehicles) do
        local category_tab = spawner:add_tab(category)
        for _, model in ipairs(models) do
            category_tab:add_button(model, function()
                local hash = MISC.GET_HASH_KEY(model)
                STREAMING.REQUEST_MODEL(hash)
                while not STREAMING.HAS_MODEL_LOADED(hash) do
                    script.yield()
                end
                
                local ped = PLAYER.PLAYER_PED_ID()
                local pos = ENTITY.GET_OFFSET_FROM_ENTITY_IN_WORLD_COORDS(ped, 0.0, 5.0, 0.0)
                local heading = ENTITY.GET_ENTITY_HEADING(ped)
                
                local vehicle = VEHICLE.CREATE_VEHICLE(hash, pos.x, pos.y, pos.z, heading, true, false)
                STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
                
                -- 设置载具属性
                VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
                VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, 255, 255, 255)
                VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, 0, 0, 0)
                VEHICLE.SET_VEHICLE_DIRT_LEVEL(vehicle, 0.0)
                
                -- 将玩家传送到载具中
                PED.SET_PED_INTO_VEHICLE(ped, vehicle, -1)
            end)
        end
    end
end

-- 载具改装功能
function vehicle.add_vehicle_mods(menu)
    -- 一键最大化改装
    menu:add_button("一键最大化改装", function()
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
        if vehicle ~= 0 then
            -- 设置改装套件
            VEHICLE.SET_VEHICLE_MOD_KIT(vehicle, 0)
            
            -- 应用所有可能的改装
            for i = 0, 49 do
                local max_mod = VEHICLE.GET_NUM_VEHICLE_MODS(vehicle, i) - 1
                if max_mod > -1 then
                    VEHICLE.SET_VEHICLE_MOD(vehicle, i, max_mod, false)
                end
            end
            
            -- 设置额外选项
            VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, 18, true) -- 涡轮
            VEHICLE.TOGGLE_VEHICLE_MOD(vehicle, 22, true) -- 氙气大灯
            VEHICLE.SET_VEHICLE_TYRES_CAN_BURST(vehicle, false) -- 防爆轮胎
            VEHICLE.SET_VEHICLE_WINDOW_TINT(vehicle, 1) -- 深色车窗
        end
    end)

    -- 修复载具
    menu:add_button("修复载具", function()
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
        if vehicle ~= 0 then
            VEHICLE.SET_VEHICLE_FIXED(vehicle)
            VEHICLE.SET_VEHICLE_DEFORMATION_FIXED(vehicle)
            VEHICLE.SET_VEHICLE_DIRT_LEVEL(vehicle, 0.0)
        end
    end)

    -- 清洁载具
    menu:add_button("清洁载具", function()
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
        if vehicle ~= 0 then
            VEHICLE.SET_VEHICLE_DIRT_LEVEL(vehicle, 0.0)
        end
    end)

    -- 彩虹喷漆
    local rainbow_paint = menu:add_checkbox("彩虹喷漆")
    script.register_looped("RainbowPaint", function()
        if rainbow_paint:is_enabled() then
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                local r = math.floor(math.sin(MISC.GET_GAME_TIMER() * 0.001) * 127 + 128)
                local g = math.floor(math.sin(MISC.GET_GAME_TIMER() * 0.001 + 2) * 127 + 128)
                local b = math.floor(math.sin(MISC.GET_GAME_TIMER() * 0.001 + 4) * 127 + 128)
                VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, r, g, b)
                VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, b, r, g)
            end
        end
    end)
end

-- 载具能力
function vehicle.add_vehicle_abilities(menu)
    -- 载具无敌
    local vehicle_godmode = menu:add_checkbox("载具无敌")
    script.register_looped("VehicleGodmode", function()
        if vehicle_godmode:is_enabled() then
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                ENTITY.SET_ENTITY_INVINCIBLE(vehicle, true)
                ENTITY.SET_ENTITY_PROOFS(vehicle, true, true, true, true, true, true, true, true)
                VEHICLE.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(vehicle, false)
            end
        end
    end)

    -- 载具加速
    local vehicle_boost = menu:add_checkbox("载具加速")
    script.register_looped("VehicleBoost", function()
        if vehicle_boost:is_enabled() then
            if PAD.IS_CONTROL_PRESSED(0, 71) then -- 按住W键
                local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
                if vehicle ~= 0 then
                    VEHICLE.SET_VEHICLE_FORWARD_SPEED(vehicle, 100.0)
                end
            end
        end
    end)

    -- 载具跳跃
    local vehicle_jump = menu:add_checkbox("载具跳跃")
    script.register_looped("VehicleJump", function()
        if vehicle_jump:is_enabled() then
            if PAD.IS_CONTROL_JUST_PRESSED(0, 22) then -- 按空格键
                local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
                if vehicle ~= 0 then
                    ENTITY.APPLY_FORCE_TO_ENTITY(vehicle, 1, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
                end
            end
        end
    end)

    -- 载具飞行
    local vehicle_fly = menu:add_checkbox("载具飞行")
    script.register_looped("VehicleFly", function()
        if vehicle_fly:is_enabled() then
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                ENTITY.SET_ENTITY_HAS_GRAVITY(vehicle, false)
                
                -- 获取按键输入
                local up_down = PAD.GET_CONTROL_NORMAL(0, 87) - PAD.GET_CONTROL_NORMAL(0, 88) -- W/S
                local left_right = PAD.GET_CONTROL_NORMAL(0, 89) - PAD.GET_CONTROL_NORMAL(0, 90) -- A/D
                local forward_back = PAD.GET_CONTROL_NORMAL(0, 71) - PAD.GET_CONTROL_NORMAL(0, 72) -- W/S
                
                -- 计算方向
                local rot = ENTITY.GET_ENTITY_ROTATION(vehicle, 2)
                local vel = {x = 0.0, y = 0.0, z = 0.0}
                
                -- 前后移动
                vel.x = vel.x + forward_back * math.sin(-rot.z * math.pi / 180.0) * 10
                vel.y = vel.y + forward_back * math.cos(-rot.z * math.pi / 180.0) * 10
                
                -- 左右移动
                vel.x = vel.x + left_right * math.cos(rot.z * math.pi / 180.0) * 10
                vel.y = vel.y + left_right * math.sin(rot.z * math.pi / 180.0) * 10
                
                -- 上下移动
                vel.z = vel.z + up_down * 10
                
                -- 应用速度
                ENTITY.SET_ENTITY_VELOCITY(vehicle, vel.x, vel.y, vel.z)
            end
        else
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                ENTITY.SET_ENTITY_HAS_GRAVITY(vehicle, true)
            end
        end
    end)

    -- 自动驾驶
    local auto_pilot = menu:add_checkbox("自动驾驶")
    script.register_looped("AutoPilot", function()
        if auto_pilot:is_enabled() then
            local vehicle = PED.GET_VEHICLE_PED_IS_IN(PLAYER.PLAYER_PED_ID(), false)
            if vehicle ~= 0 then
                local waypoint = HUD.GET_FIRST_BLIP_INFO_ID(8) -- 获取地图标记点
                if HUD.DOES_BLIP_EXIST(waypoint) then
                    local coords = HUD.GET_BLIP_COORDS(waypoint)
                    TASK.TASK_VEHICLE_DRIVE_TO_COORD(
                        PLAYER.PLAYER_PED_ID(),
                        vehicle,
                        coords.x, coords.y, coords.z,
                        30.0, -- 速度
                        1.0, -- 停车精度
                        ENTITY.GET_ENTITY_MODEL(vehicle),
                        786603, -- 驾驶风格
                        1.0 -- 最大速度限制
                    )
                end
            end
        end
    end)
end

return vehicle
