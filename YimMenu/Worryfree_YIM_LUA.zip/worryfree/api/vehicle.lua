local core = require("worryfree/api/core")
local vehicle = {}

-- 添加载具生成器
function vehicle.add_vehicle_spawner(menu)
    local spawner = menu:add_tab("载具生成器")
    
    -- 常用载具列表
    local common_vehicles = {
        {"小型车", "ADDER"},
        {"跑车", "T20"},
        {"SUV", "BALLER"},
        {"摩托车", "AKUMA"},
        {"直升机", "BUZZARD"},
        {"飞机", "LAZER"},
        {"军用车", "INSURGENT"}
    }
    
    -- 添加常用载具按钮
    for _, vehicle_info in ipairs(common_vehicles) do
        spawner:add_button(vehicle_info[1], function()
            local coords = core.utils.get_player_coords()
            local heading = ENTITY.GET_ENTITY_HEADING(core.player.get_ped())
            local vehicle = core.vehicle.create(vehicle_info[2], coords, heading)
            
            if core.utils.is_entity_valid(vehicle) then
                PED.SET_PED_INTO_VEHICLE(core.player.get_ped(), vehicle, -1)
                core.ui.notify("已生成 " .. vehicle_info[1])
            end
        end)
    end
    
    -- 自定义载具生成
    local custom_vehicle_text = spawner:add_text("输入载具名称:")
    spawner:add_button("生成自定义载具", function()
        local model = custom_vehicle_text:get_text()
        if model and model ~= "" then
            local coords = core.utils.get_player_coords()
            local heading = ENTITY.GET_ENTITY_HEADING(core.player.get_ped())
            local vehicle = core.vehicle.create(model, coords, heading)
            
            if core.utils.is_entity_valid(vehicle) then
                PED.SET_PED_INTO_VEHICLE(core.player.get_ped(), vehicle, -1)
                core.ui.notify("已生成载具: " .. model)
            else
                core.ui.notify("生成载具失败: " .. model)
            end
        end
    end)
end

-- 添加载具改装
function vehicle.add_vehicle_mods(menu)
    local mods = menu:add_tab("载具改装")
    
    -- 最大改装
    mods:add_button("最大改装当前载具", function()
        local current = core.vehicle.get_current()
        if core.utils.is_entity_valid(current) then
            -- 基础改装
            core.vehicle.modify(current, {
                [11] = 3,  -- 引擎
                [12] = 2,  -- 刹车
                [13] = 2,  -- 变速箱
                [15] = 3,  -- 悬挂
                [16] = 4,  -- 装甲
                [18] = 1   -- 涡轮增压
            })
            
            -- 额外改装
            VEHICLE.TOGGLE_VEHICLE_MOD(current, 18, true)  -- 涡轮
            VEHICLE.TOGGLE_VEHICLE_MOD(current, 22, true)  -- 氙气大灯
            
            -- 设置车轮类型
            VEHICLE.SET_VEHICLE_WHEEL_TYPE(current, 7)
            VEHICLE.SET_VEHICLE_MOD(current, 23, 0, false)  -- 前轮
            VEHICLE.SET_VEHICLE_MOD(current, 24, 0, false)  -- 后轮
            
            core.ui.notify("载具已完成最大改装")
        else
            core.ui.notify("请先进入一辆载具")
        end
    end)
    
    -- 修复载具
    mods:add_button("修复当前载具", function()
        local current = core.vehicle.get_current()
        if core.utils.is_entity_valid(current) then
            VEHICLE.SET_VEHICLE_FIXED(current)
            VEHICLE.SET_VEHICLE_DEFORMATION_FIXED(current)
            VEHICLE.SET_VEHICLE_DIRT_LEVEL(current, 0.0)
            core.ui.notify("载具已修复")
        else
            core.ui.notify("请先进入一辆载具")
        end
    end)
end

-- 添加载具能力
function vehicle.add_vehicle_abilities(menu)
    local abilities = menu:add_tab("载具能力")
    
    -- 载具无敌
    local vehicle_godmode = abilities:add_checkbox("载具无敌")
    script.register_looped("VehicleGodmode", function()
        if vehicle_godmode:is_enabled() then
            local current = core.vehicle.get_current()
            if core.utils.is_entity_valid(current) then
                ENTITY.SET_ENTITY_INVINCIBLE(current, true)
                ENTITY.SET_ENTITY_PROOFS(current, true, true, true, true, true, true, true, true)
                VEHICLE.SET_VEHICLE_CAN_BE_VISIBLY_DAMAGED(current, false)
            end
        end
    end)
    
    -- 载具加速
    local vehicle_boost = abilities:add_checkbox("载具加速")
    script.register_looped("VehicleBoost", function()
        if vehicle_boost:is_enabled() then
            local current = core.vehicle.get_current()
            if core.utils.is_entity_valid(current) then
                if PAD.IS_CONTROL_PRESSED(0, 71) then  -- W键
                    VEHICLE.SET_VEHICLE_FORWARD_SPEED(current, 100.0)
                end
            end
        end
    end)
end

return vehicle
