local player = {}

-- 超级能力
function player.add_super_powers(parent_tab)
    local powers = parent_tab:add_tab("超级能力")
    
    -- 超级跑步
    local super_run = powers:add_checkbox("超级跑步")
    script.register_looped("SuperRun", function()
        if super_run:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if ENTITY.DOES_ENTITY_EXIST(ped) and not PED.IS_PED_IN_ANY_VEHICLE(ped, true) then
                if PAD.IS_CONTROL_PRESSED(0, 21) then -- SHIFT键
                    ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1, true, true, true, false, true)
                end
            end
        end
    end)
    
    -- 超级力量
    local super_strength = powers:add_checkbox("超级力量")
    script.register_looped("SuperStrength", function()
        if super_strength:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 500.0)
            PED.SET_PED_RAGDOLL_FORCE_FALL(ped)
            PED.SET_PED_CAN_RAGDOLL_FROM_PLAYER_IMPACT(ped, false)
        end
    end)
    
    -- 隐身模式
    local invisibility = powers:add_checkbox("隐身模式")
    script.register_looped("Invisibility", function()
        if invisibility:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_VISIBLE(ped, false, false)
            NETWORK.SET_LOCAL_PLAYER_VISIBLE_LOCALLY(true)
        else
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_VISIBLE(ped, true, true)
        end
    end)
end

-- 战斗增强
function player.add_combat_options(parent_tab)
    local combat = parent_tab:add_tab("战斗增强")
    
    -- 自动瞄准
    local auto_aim = combat:add_checkbox("自动瞄准")
    script.register_looped("AutoAim", function()
        if auto_aim:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
            
            for _, pid in ipairs(entities.get_all_peds_as_handles()) do
                if pid ~= ped and not PED.IS_PED_DEAD_OR_DYING(pid, true) then
                    local ped_pos = ENTITY.GET_ENTITY_COORDS(pid, true)
                    if MISC.GET_DISTANCE_BETWEEN_COORDS(pos.x, pos.y, pos.z, ped_pos.x, ped_pos.y, ped_pos.z, true) < 50.0 then
                        MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(pos.x, pos.y, pos.z + 1.0, ped_pos.x, ped_pos.y, ped_pos.z, 1, true, MISC.GET_HASH_KEY("WEAPON_STUNGUN"), ped, true, false, 1000.0)
                    end
                end
            end
        end
    end)
    
    -- 近战格挡
    local auto_block = combat:add_checkbox("自动格挡")
    script.register_looped("AutoBlock", function()
        if auto_block:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PED.SET_PED_COMBAT_ABILITY(ped, 100)
            PED.SET_PED_COMBAT_ATTRIBUTES(ped, 2, true) -- 可以格挡
        end
    end)
    
    -- 快速恢复
    local quick_recovery = combat:add_checkbox("快速恢复")
    script.register_looped("QuickRecovery", function()
        if quick_recovery:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_HEALTH(ped, ENTITY.GET_ENTITY_MAX_HEALTH(ped))
            PED.ADD_ARMOUR_TO_PED(ped, 100)
        end
    end)
end

-- 玩家属性
function player.add_attributes(parent_tab)
    local attributes = parent_tab:add_tab("玩家属性")
    
    -- 最大生命值
    local max_health = attributes:add_checkbox("最大生命值")
    script.register_looped("MaxHealth", function()
        if max_health:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_MAX_HEALTH(ped, 10000)
            ENTITY.SET_ENTITY_HEALTH(ped, 10000)
        end
    end)
    
    -- 超级跑步
    local super_speed = attributes:add_checkbox("超级跑步")
    script.register_looped("SuperSpeed", function()
        if super_speed:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PLAYER.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), 1.49)
        else
            PLAYER.SET_RUN_SPRINT_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), 1.0)
        end
    end)
    
    -- 超级游泳
    local super_swim = attributes:add_checkbox("超级游泳")
    script.register_looped("SuperSwim", function()
        if super_swim:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PED.SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), 1.49)
        else
            PED.SET_SWIM_MULTIPLIER_FOR_PLAYER(PLAYER.PLAYER_ID(), 1.0)
        end
    end)
end

-- 玩家基础能力
function player.add_basic_abilities(menu)
    -- 无敌模式
    local godmode = menu:add_checkbox("无敌模式")
    script.register_looped("Godmode", function()
        if godmode:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_INVINCIBLE(ped, true)
            ENTITY.SET_ENTITY_PROOFS(ped, true, true, true, true, true, true, true, true)
            PED.SET_PED_CAN_RAGDOLL(ped, false)
            PED.SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(ped, 1)
        else
            local ped = PLAYER.PLAYER_PED_ID()
            ENTITY.SET_ENTITY_INVINCIBLE(ped, false)
            ENTITY.SET_ENTITY_PROOFS(ped, false, false, false, false, false, false, false, false)
            PED.SET_PED_CAN_RAGDOLL(ped, true)
            PED.SET_PED_CAN_BE_KNOCKED_OFF_VEHICLE(ped, 0)
        end
    end)

    -- 警察无视
    local police_ignore = menu:add_checkbox("警察无视")
    script.register_looped("PoliceIgnore", function()
        if police_ignore:is_enabled() then
            PLAYER.SET_POLICE_IGNORE_PLAYER(PLAYER.PLAYER_ID(), true)
            PLAYER.SET_EVERYONE_IGNORE_PLAYER(PLAYER.PLAYER_ID(), true)
            PLAYER.SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(PLAYER.PLAYER_ID(), false)
            PLAYER.SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(PLAYER.PLAYER_ID(), true)
        else
            PLAYER.SET_POLICE_IGNORE_PLAYER(PLAYER.PLAYER_ID(), false)
            PLAYER.SET_EVERYONE_IGNORE_PLAYER(PLAYER.PLAYER_ID(), false)
            PLAYER.SET_PLAYER_CAN_BE_HASSLED_BY_GANGS(PLAYER.PLAYER_ID(), true)
            PLAYER.SET_IGNORE_LOW_PRIORITY_SHOCKING_EVENTS(PLAYER.PLAYER_ID(), false)
        end
    end)

    -- 超级跑步
    local super_run = menu:add_checkbox("超级跑步")
    script.register_looped("SuperRun", function()
        if super_run:is_enabled() then
            if PAD.IS_CONTROL_PRESSED(0, 21) then -- SHIFT键
                local ped = PLAYER.PLAYER_PED_ID()
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                local heading = ENTITY.GET_ENTITY_HEADING(ped)
                local force = 50.0
                if PAD.IS_CONTROL_PRESSED(0, 32) then -- W键
                    local x = force * math.sin(-math.rad(heading))
                    local y = force * math.cos(-math.rad(heading))
                    ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, x, y, 0.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
                end
            end
        end
    end)

    -- 超级跳跃
    local super_jump = menu:add_checkbox("超级跳跃")
    script.register_looped("SuperJump", function()
        if super_jump:is_enabled() then
            if PAD.IS_CONTROL_JUST_PRESSED(0, 22) then -- 空格键
                local ped = PLAYER.PLAYER_PED_ID()
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, 0.0, 0.0, 100.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
            end
        end
    end)

    -- 无限耐力
    local infinite_stamina = menu:add_checkbox("无限耐力")
    script.register_looped("InfiniteStamina", function()
        if infinite_stamina:is_enabled() then
            PLAYER.RESTORE_PLAYER_STAMINA(PLAYER.PLAYER_ID(), 100.0)
        end
    end)
end

-- 玩家传送功能
function player.add_teleport_options(menu)
    -- 传送到标记点
    menu:add_button("传送到标记点", function()
        local waypoint = HUD.GET_FIRST_BLIP_INFO_ID(8)
        if HUD.DOES_BLIP_EXIST(waypoint) then
            local coords = HUD.GET_BLIP_COORDS(waypoint)
            local ped = PLAYER.PLAYER_PED_ID()
            -- 获取地面高度
            local ground_z = 0
            for i = 0, 1000 do
                ground_z = coords.z + i
                ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, coords.x, coords.y, ground_z, false, false, false)
                script.yield(100)
                if not ENTITY.IS_ENTITY_IN_AIR(ped) then
                    break
                end
            end
        end
    end)

    -- 传送到目标点
    local teleport_locations = {
        ["洛圣都改车王"] = {x = -365.425, y = -131.809, z = 37.873},
        ["武器店"] = {x = 247.3652, y = -45.8777, z = 69.9411},
        ["机场"] = {x = -1102.2910, y = -2894.5256, z = 13.9467},
        ["军事基地"] = {x = -2012.8470, y = 2956.5270, z = 32.8101},
        ["赌场"] = {x = 924.9835, y = 46.9568, z = 80.9957},
        ["夜总会"] = {x = -1604.664, y = -3012.583, z = -78.000}
    }

    -- 创建传送菜单
    local teleport_menu = menu:add_tab("传送地点")
    for name, coords in pairs(teleport_locations) do
        teleport_menu:add_button(name, function()
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_IN_ANY_VEHICLE(ped, false) then
                ped = PED.GET_VEHICLE_PED_IS_IN(ped, false)
            end
            ENTITY.SET_ENTITY_COORDS_NO_OFFSET(ped, coords.x, coords.y, coords.z, false, false, false)
        end)
    end
end

-- 玩家外观选项
function player.add_appearance_options(menu)
    -- 随机外观
    menu:add_button("随机外观", function()
        local ped = PLAYER.PLAYER_PED_ID()
        PED.SET_PED_RANDOM_COMPONENT_VARIATION(ped, 0)
        PED.SET_PED_RANDOM_PROPS(ped)
    end)

    -- 清除血迹
    menu:add_button("清除血迹", function()
        local ped = PLAYER.PLAYER_PED_ID()
        PED.CLEAR_PED_BLOOD_DAMAGE(ped)
        PED.RESET_PED_VISIBLE_DAMAGE(ped)
    end)

    -- 更换模型
    local common_models = {
        ["警察"] = "s_m_y_cop_01",
        ["特警"] = "s_m_y_swat_01",
        ["消防员"] = "s_m_y_fireman_01",
        ["医生"] = "s_m_m_doctor_01",
        ["小丑"] = "s_m_y_clown_01",
        ["僵尸"] = "u_m_y_zombie_01"
    }

    -- 创建模型菜单
    local model_menu = menu:add_tab("更换模型")
    for name, model in pairs(common_models) do
        model_menu:add_button(name, function()
            local hash = MISC.GET_HASH_KEY(model)
            STREAMING.REQUEST_MODEL(hash)
            while not STREAMING.HAS_MODEL_LOADED(hash) do
                script.yield()
            end
            PLAYER.SET_PLAYER_MODEL(PLAYER.PLAYER_ID(), hash)
            STREAMING.SET_MODEL_AS_NO_LONGER_NEEDED(hash)
        end)
    end
end

-- 玩家战斗选项
function player.add_combat_options(menu)
    -- 自动瞄准
    local auto_aim = menu:add_checkbox("自动瞄准")
    script.register_looped("AutoAim", function()
        if auto_aim:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
            
            -- 获取最近的NPC
            local closest_ped = nil
            local min_dist = 1000000.0
            
            for _, target in ipairs(entities.get_all_peds_as_handles()) do
                if target ~= ped and not ENTITY.IS_ENTITY_DEAD(target) then
                    local target_pos = ENTITY.GET_ENTITY_COORDS(target, true)
                    local dist = SYSTEM.VDIST(pos.x, pos.y, pos.z, target_pos.x, target_pos.y, target_pos.z)
                    if dist < min_dist then
                        min_dist = dist
                        closest_ped = target
                    end
                end
            end
            
            -- 瞄准最近的NPC
            if closest_ped then
                local target_pos = ENTITY.GET_ENTITY_COORDS(closest_ped, true)
                MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(
                    pos.x, pos.y, pos.z,
                    target_pos.x, target_pos.y, target_pos.z,
                    1, true, WEAPON.GET_SELECTED_PED_WEAPON(ped), ped, true, false, 1000.0
                )
            end
        end
    end)

    -- 一击必杀
    local one_hit_kill = menu:add_checkbox("一击必杀")
    script.register_looped("OneHitKill", function()
        if one_hit_kill:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 999999.0)
            PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 999999.0)
        else
            local ped = PLAYER.PLAYER_PED_ID()
            PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 1.0)
            PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 1.0)
        end
    end)

    -- 爆炸拳
    local explosive_melee = menu:add_checkbox("爆炸拳")
    script.register_looped("ExplosiveMelee", function()
        if explosive_melee:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_IN_MELEE_COMBAT(ped) then
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z, 1, 1.0, true, false, 0.0, false)
            end
        end
    end)

    -- 范围清除NPC
    menu:add_button("范围清除NPC", function()
        local ped = PLAYER.PLAYER_PED_ID()
        local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
        local radius = 100.0
        
        for _, target in ipairs(entities.get_all_peds_as_handles()) do
            if target ~= ped then
                local target_pos = ENTITY.GET_ENTITY_COORDS(target, true)
                local dist = SYSTEM.VDIST(pos.x, pos.y, pos.z, target_pos.x, target_pos.y, target_pos.z)
                if dist < radius then
                    ENTITY.SET_ENTITY_HEALTH(target, 0)
                end
            end
        end
    end)
end

return player 