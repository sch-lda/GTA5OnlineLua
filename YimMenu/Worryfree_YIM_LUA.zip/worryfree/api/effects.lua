local effects = {}
local utils = require("worryfree/api/utils")

-- 粒子特效系统
function effects.add_particle_effects(menu)
    -- 常用粒子效果
    local particle_list = {
        ["火焰环绕"] = {
            asset = "scr_rcbarry2",
            effect = "scr_clown_appears",
            scale = 1.0,
            offset = {x = 0.0, y = 0.0, z = 0.0}
        },
        ["烟雾环绕"] = {
            asset = "scr_rcbarry2",
            effect = "scr_exp_clown",
            scale = 2.0,
            offset = {x = 0.0, y = 0.0, z = 0.0}
        },
        ["闪电环绕"] = {
            asset = "scr_agencyheist",
            effect = "scr_fbi_mop_drips",
            scale = 1.0,
            offset = {x = 0.0, y = 0.0, z = 1.0}
        }
    }

    for name, data in pairs(particle_list) do
        local effect_toggle = menu:add_checkbox(name)
        script.register_looped(name .. "Effect", function()
            if effect_toggle:is_enabled() then
                local ped = PLAYER.PLAYER_PED_ID()
                if ENTITY.DOES_ENTITY_EXIST(ped) then
                    local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                    STREAMING.REQUEST_NAMED_PTFX_ASSET(data.asset)
                    if STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(data.asset) then
                        GRAPHICS.USE_PARTICLE_FX_ASSET(data.asset)
                        for i = 0, 360, 45 do
                            local angle = math.rad(i)
                            local radius = 1.0
                            local x = pos.x + math.cos(angle) * radius + data.offset.x
                            local y = pos.y + math.sin(angle) * radius + data.offset.y
                            local z = pos.z + data.offset.z
                            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(
                                data.effect,
                                x, y, z,
                                0.0, 0.0, 0.0,
                                data.scale,
                                false, false, false,
                                false
                            )
                        end
                    end
                end
            end
        end)
    end
end

-- 获取当前时间(毫秒)
local function get_time_ms()
    return os.clock() * 1000
end

-- 魂环特效系统
function effects.add_soul_ring_effects(menu)
    local soul_rings = menu:add_tab("魂环特效")
    
    -- 魂环配置
    local ring_types = {
        ["千年魂环"] = {
            color = {r = 255, g = 215, b = 0},  -- 金色
            scale = 1.0,
            height_offset = 0.8,  -- 头部位置
            rings = 1,
            animation_start = 3.0,
            ring_segments = 36,
            inner_glow = true,
            outer_glow = true
        },
        ["万年魂环"] = {
            color = {r = 138, g = 43, b = 226},  -- 紫色
            scale = 1.2,
            height_offset = 0.5,  -- 肩部位置
            rings = 2,
            animation_start = 4.0,
            ring_segments = 48,
            inner_glow = true,
            outer_glow = true
        },
        ["十万年魂环"] = {
            color = {r = 255, g = 0, b = 0},  -- 红色
            scale = 1.5,
            height_offset = 0.2,  -- 腰部位置
            rings = 3,
            animation_start = 5.0,
            particle_effect = {
                asset = "scr_agencyheist",
                name = "scr_fbi_mop_drips",
                density = 24
            },
            ring_segments = 60,
            inner_glow = true,
            outer_glow = true
        },
        ["百万年魂环"] = {
            color = {r = 0, g = 191, b = 255},  -- 深蓝色
            scale = 2.0,
            height_offset = -0.1,  -- 脚部位置
            rings = 4,
            animation_start = 6.0,
            ring_segments = 72,
            inner_glow = true,
            outer_glow = true
        }
    }
    
    -- 存储动画状态
    local animation_states = {}
    
    -- 为每种魂环创建开关
    for name, data in pairs(ring_types) do
        local ring_toggle = soul_rings:add_checkbox(name)
        animation_states[name] = {
            is_animating = false,
            current_height = data.animation_start,
            target_height = data.height_offset,
            rotation = 0.0,
            pulse = 0.0,  -- 添加脉冲效果
            particle_time = 0  -- 粒子效果计时器
        }
        
        script.register_looped(name .. "SoulRing", function()
            if ring_toggle:is_enabled() then
                local ped = PLAYER.PLAYER_PED_ID()
                if ENTITY.DOES_ENTITY_EXIST(ped) then
                    local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                    local state = animation_states[name]
                    
                    -- 处理动画
                    if not state.is_animating then
                        state.is_animating = true
                        state.current_height = data.animation_start
                    end
                    
                    -- 平滑过渡动画
                    if state.current_height > data.height_offset then
                        state.current_height = state.current_height - 0.1
                        if state.current_height < data.height_offset then
                            state.current_height = data.height_offset
                        end
                    end
                    
                    -- 更新旋转角度
                    state.rotation = state.rotation + 1.0
                    if state.rotation >= 360.0 then
                        state.rotation = 0.0
                    end
                    
                    -- 更新脉冲效果
                    state.pulse = math.sin(get_time_ms() / 200) * 0.2 + 0.8
                    
                    -- 创建多层魂环
                    for ring = 1, data.rings do
                        -- 计算魂环高度，使用height_offset来定位
                        local base_height = pos.z + data.height_offset
                        local height = base_height + (state.current_height * 0.1 * ring)  -- 减小每层的间距
                        local scale = data.scale * (1.0 + (ring - 1) * 0.1) * state.pulse  -- 稍微增大每层的大小
                        local base_radius = 1.0 * (1.0 + (ring - 1) * 0.1)  -- 稍微增大每层的半径
                        
                        -- 创建主光环
                        for i = 0, 360, 360/data.ring_segments do
                            local angle = math.rad(i + state.rotation)
                            -- 添加波浪效果
                            local wave = math.sin(math.rad(i * 4 + state.rotation * 2)) * 0.1
                            local radius = base_radius * (1.0 + wave)
                            
                            local x = pos.x + math.cos(angle) * radius
                            local y = pos.y + math.sin(angle) * radius
                            
                            -- 创建主光点
                            GRAPHICS.DRAW_LIGHT_WITH_RANGE(
                                x, y, height,
                                data.color.r, data.color.g, data.color.b,
                                scale * 1.5, 1.0
                            )
                            
                            -- 内部光晕
                            if data.inner_glow then
                                local inner_radius = radius * 0.8
                                local inner_x = pos.x + math.cos(angle) * inner_radius
                                local inner_y = pos.y + math.sin(angle) * inner_radius
                                GRAPHICS.DRAW_LIGHT_WITH_RANGE(
                                    inner_x, inner_y, height,
                                    data.color.r, data.color.g, data.color.b,
                                    scale * 0.8, 0.5
                                )
                            end
                            
                            -- 外部光晕
                            if data.outer_glow then
                                local outer_radius = radius * 1.2
                                local outer_x = pos.x + math.cos(angle) * outer_radius
                                local outer_y = pos.y + math.sin(angle) * outer_radius
                                GRAPHICS.DRAW_LIGHT_WITH_RANGE(
                                    outer_x, outer_y, height,
                                    data.color.r, data.color.g, data.color.b,
                                    scale * 0.6, 0.3
                                )
                            end
                            
                            -- 创建能量线
                            if i > 0 then
                                local prev_angle = math.rad(i - 360/data.ring_segments + state.rotation)
                                local prev_wave = math.sin(math.rad((i - 360/data.ring_segments) * 4 + state.rotation * 2)) * 0.1
                                local prev_radius = base_radius * (1.0 + prev_wave)
                                local prev_x = pos.x + math.cos(prev_angle) * prev_radius
                                local prev_y = pos.y + math.sin(prev_angle) * prev_radius
                                
                                -- 能量脉冲线
                                for j = 0, 2 do
                                    local pulse_offset = j * 0.1
                                    local pulse_height = height + pulse_offset
                                    GRAPHICS.DRAW_LINE(
                                        prev_x, prev_y, pulse_height,
                                        x, y, pulse_height,
                                        data.color.r, data.color.g, data.color.b, 
                                        math.floor(255 * (0.8 - j * 0.2) * state.pulse)
                                    )
                                end
                            end
                        end
                        
                        -- 增强粒子效果（仅限十万年魂环）
                        if name == "十万年魂环" then
                            state.particle_time = state.particle_time + 1
                            if state.particle_time % 3 == 0 then  -- 进一步提高粒子生成频率
                                STREAMING.REQUEST_NAMED_PTFX_ASSET(data.particle_effect.asset)
                                if STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(data.particle_effect.asset) then
                                    GRAPHICS.USE_PARTICLE_FX_ASSET(data.particle_effect.asset)
                                    -- 在环周围生成更多粒子
                                    for i = 0, 360, 360/data.particle_effect.density do
                                        local particle_angle = math.rad(i + state.rotation * 2)
                                        local particle_radius = base_radius * (1.0 + math.sin(math.rad(i * 4 + state.rotation * 2)) * 0.1)
                                        local particle_x = pos.x + math.cos(particle_angle) * particle_radius
                                        local particle_y = pos.y + math.sin(particle_angle) * particle_radius
                                        -- 增加多层粒子效果
                                        for layer = 1, 2 do
                                            local particle_height = height + (layer - 1) * 0.2
                                            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(
                                                data.particle_effect.name,
                                                particle_x, particle_y, particle_height,
                                                0.0, 0.0, state.rotation,
                                                scale * 1.2,  -- 增加粒子大小
                                                false, false, false,
                                                false
                                            )
                                        end
                                    end
                                end
                            end
                        end
                    end
                end
            else
                -- 重置动画状态
                animation_states[name].is_animating = false
                animation_states[name].particle_time = 0
            end
        end)
    end
    
    -- 添加魂技特效按钮
    soul_rings:add_button("释放魂技", function()
        local ped = PLAYER.PLAYER_PED_ID()
        if ENTITY.DOES_ENTITY_EXIST(ped) then
            local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
            
            -- 创建爆炸效果
            FIRE.ADD_EXPLOSION(
                pos.x, pos.y, pos.z,
                29,  -- 爆炸类型 (EXP_TAG_RAYGUN)
                1.0, -- 伤害
                true, -- 是否可见
                false, -- 是否听得见
                0.0 -- 摄像机晃动
            )
            
            -- 创建光环扩散效果
            local start_time = get_time_ms()
            script.register_looped("SoulRingExplosion", function()
                local elapsed = get_time_ms() - start_time
                if elapsed > 2000 then -- 2秒后结束
                    return false
                end
                
                local progress = elapsed / 2000 -- 0到1的进度
                local radius = progress * 20.0 -- 最大半径20.0
                local pulse = math.sin(elapsed / 100) * 0.3 + 0.7 -- 添加脉冲
                
                -- 创建多层扩散环
                for layer = 1, 3 do
                    local layer_radius = radius * (1 + (layer - 1) * 0.2)
                    for angle = 0, 360, 5 do
                        local rad = math.rad(angle)
                        local x = pos.x + math.cos(rad) * layer_radius
                        local y = pos.y + math.sin(rad) * layer_radius
                        local z = pos.z + progress * 2.0 + (layer - 1) * 0.2
                        
                        -- 主光环
                        GRAPHICS.DRAW_LIGHT_WITH_RANGE(
                            x, y, z,
                            255, 255, 255,  -- 白色
                            (1.0 * (1 - progress) * pulse) / layer, -- 光强度随时间减弱
                            0.5
                        )
                        
                        -- 创建连接线
                        if angle > 0 then
                            local prev_rad = math.rad(angle - 5)
                            local prev_x = pos.x + math.cos(prev_rad) * layer_radius
                            local prev_y = pos.y + math.sin(prev_rad) * layer_radius
                            
                            GRAPHICS.DRAW_LINE(
                                prev_x, prev_y, z,
                                x, y, z,
                                255, 255, 255, math.floor(255 * (1 - progress) * pulse)
                            )
                        end
                    end
                    
                    -- 添加垂直光束
                    if layer == 1 then
                        local beam_height = pos.z + progress * 10.0
                        GRAPHICS.DRAW_LIGHT_WITH_RANGE(
                            pos.x, pos.y, beam_height,
                            255, 255, 255,
                            3.0 * (1 - progress) * pulse,
                            1.0
                        )
                    end
                end
                return true
            end)
        end
    end)
end

-- 初始化函数
function effects.setup(menu)
    effects.add_particle_effects(menu)
    effects.add_soul_ring_effects(menu)
end

return effects
