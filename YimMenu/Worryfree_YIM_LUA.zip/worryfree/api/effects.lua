local effects = {}

-- 粒子特效系统
function effects.add_particle_effects(menu)
    -- 常用粒子效果
    local particle_list = {
        ["火焰环绕"] = {
            asset = "scr_rcbarry2",
            effect = "scr_clown_appears",
            scale = 1.0,
            offset = {x = 0.0, y = 0.0, z = 0.0}
        },
        ["烟雾环绕"] = {
            asset = "scr_rcbarry2",
            effect = "scr_exp_clown",
            scale = 2.0,
            offset = {x = 0.0, y = 0.0, z = 0.0}
        },
        ["闪电环绕"] = {
            asset = "scr_agencyheist",
            effect = "scr_fbi_mop_drips",
            scale = 1.0,
            offset = {x = 0.0, y = 0.0, z = 1.0}
        },
        ["能量环绕"] = {
            asset = "scr_rcbarry1",
            effect = "scr_alien_disintegrate",
            scale = 1.0,
            offset = {x = 0.0, y = 0.0, z = 0.5}
        },
        ["彩虹环绕"] = {
            asset = "scr_rcbarry2",
            effect = "scr_clown_bul",
            scale = 1.5,
            offset = {x = 0.0, y = 0.0, z = 0.0}
        }
    }

    -- 为每个粒子效果创建开关
    for name, data in pairs(particle_list) do
        local effect_toggle = menu:add_checkbox(name)
        script.register_looped(name .. "Effect", function()
            if effect_toggle:is_enabled() then
                local ped = PLAYER.PLAYER_PED_ID()
                if ENTITY.DOES_ENTITY_EXIST(ped) then
                    local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                    
                    -- 请求粒子资源
                    STREAMING.REQUEST_NAMED_PTFX_ASSET(data.asset)
                    if STREAMING.HAS_NAMED_PTFX_ASSET_LOADED(data.asset) then
                        GRAPHICS.USE_PARTICLE_FX_ASSET(data.asset)
                        
                        -- 创建环绕效果
                        for i = 0, 360, 45 do
                            local angle = math.rad(i)
                            local radius = 1.0
                            local x = pos.x + math.cos(angle) * radius + data.offset.x
                            local y = pos.y + math.sin(angle) * radius + data.offset.y
                            local z = pos.z + data.offset.z
                            
                            GRAPHICS.START_NETWORKED_PARTICLE_FX_NON_LOOPED_AT_COORD(
                                data.effect,
                                x, y, z,
                                0.0, 0.0, 0.0,
                                data.scale,
                                false, false, false,
                                false
                            )
                        end
                    end
                end
            end
        end)
    end
end

-- 视觉效果系统
function effects.add_visual_effects(menu)
    -- 屏幕效果
    local screen_effects = {
        ["迷幻效果"] = "DrugsDrivingIn",
        ["醉酒效果"] = "DrugsMichaelAliensFightIn",
        ["电击效果"] = "DeathFailOut",
        ["水下效果"] = "UnderWater",
        ["夜视效果"] = "NightVision",
        ["热成像"] = "ThermalVision",
        ["模糊视觉"] = "MenuMGHeistIn",
        ["闪光效果"] = "ExplosionJosh3",
        ["黑白电影"] = "DeathFailNeutralIn"
    }

    -- 为每个屏幕效果创建开关
    for name, effect_name in pairs(screen_effects) do
        local effect_toggle = menu:add_checkbox(name)
        script.register_looped(name .. "ScreenEffect", function()
            if effect_toggle:is_enabled() then
                GRAPHICS.SET_TIMECYCLE_MODIFIER(effect_name)
                GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(1.0)
            else
                GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
            end
        end)
    end

    -- 相机效果
    local camera_effects = {
        ["手持相机"] = {
            name = "手持相机",
            shake_type = "HAND_SHAKE",
            intensity = 0.5
        },
        ["醉酒摇晃"] = {
            name = "醉酒摇晃",
            shake_type = "DRUNK_SHAKE",
            intensity = 1.0
        },
        ["小型爆炸"] = {
            name = "小型爆炸",
            shake_type = "SMALL_EXPLOSION_SHAKE",
            intensity = 0.3
        },
        ["中型爆炸"] = {
            name = "中型爆炸",
            shake_type = "MEDIUM_EXPLOSION_SHAKE",
            intensity = 0.5
        },
        ["大型爆炸"] = {
            name = "大型爆炸",
            shake_type = "LARGE_EXPLOSION_SHAKE",
            intensity = 0.7
        }
    }

    -- 为每个相机效果创建开关
    for name, data in pairs(camera_effects) do
        local effect_toggle = menu:add_checkbox(data.name)
        script.register_looped(name .. "CameraEffect", function()
            if effect_toggle:is_enabled() then
                CAM.SHAKE_GAMEPLAY_CAM(data.shake_type, data.intensity)
            else
                CAM.STOP_GAMEPLAY_CAM_SHAKING(true)
            end
        end)
    end
end

-- 动画效果系统
function effects.add_animation_effects(menu)
    -- 常用动画列表
    local animations = {
        ["跳舞1"] = {
            dict = "mini@strip_club@private_dance@part1",
            anim = "priv_dance_p1",
            flag = 1
        },
        ["跳舞2"] = {
            dict = "mini@strip_club@private_dance@part2",
            anim = "priv_dance_p2",
            flag = 1
        },
        ["瑜伽"] = {
            dict = "rcmcollect_paperleadinout@",
            anim = "meditiate_idle",
            flag = 1
        },
        ["俯卧撑"] = {
            dict = "amb@world_human_push_ups@male@idle_a",
            anim = "idle_d",
            flag = 1
        },
        ["仰卧起坐"] = {
            dict = "amb@world_human_sit_ups@male@idle_a",
            anim = "idle_a",
            flag = 1
        },
        ["摇滚"] = {
            dict = "anim@mp_player_intupperfinger",
            anim = "idle_a",
            flag = 1
        },
        ["喝醉"] = {
            dict = "random@drunk_driver_1",
            anim = "drunk_driver_stand_loop_dd1",
            flag = 1
        },
        ["跳舞3"] = {
            dict = "mini@strip_club@private_dance@part3",
            anim = "priv_dance_p3",
            flag = 1
        }
    }

    -- 创建动画菜单
    local anim_menu = menu:add_tab("动画菜单")
    
    -- 当前播放的动画
    local current_anim = nil
    
    -- 为每个动画创建按钮
    for name, data in pairs(animations) do
        anim_menu:add_button(name, function()
            local ped = PLAYER.PLAYER_PED_ID()
            if ENTITY.DOES_ENTITY_EXIST(ped) and not PED.IS_PED_IN_ANY_VEHICLE(ped, true) then
                -- 如果已经在播放这个动画，就停止
                if current_anim == name then
                    TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
                    current_anim = nil
                    return
                end
                
                -- 加载动画字典
                STREAMING.REQUEST_ANIM_DICT(data.dict)
                
                -- 等待动画加载完成
                local timeout = 0
                while not STREAMING.HAS_ANIM_DICT_LOADED(data.dict) and timeout < 50 do
                    script.yield()
                    timeout = timeout + 1
                end
                
                if STREAMING.HAS_ANIM_DICT_LOADED(data.dict) then
                    -- 播放动画
                    TASK.TASK_PLAY_ANIM(ped, data.dict, data.anim, 8.0, -8.0, -1, data.flag, 0, false, false, false)
                    current_anim = name
                end
            end
        end)
    end
    
    -- 停止动画按钮
    anim_menu:add_button("停止动画", function()
        local ped = PLAYER.PLAYER_PED_ID()
        if ENTITY.DOES_ENTITY_EXIST(ped) then
            TASK.CLEAR_PED_TASKS_IMMEDIATELY(ped)
            current_anim = nil
        end
    end)
end

return effects
