local utils = {}

-- 将字符串转换为hash值
function utils.joaat(text)
    return MISC.GET_HASH_KEY(text)
end

-- 等待指定时间(毫秒)
function utils.sleep(ms)
    local start = os.clock()
    while os.clock() - start <= ms/1000 do end
end

-- 获取当前时间戳(毫秒)
function utils.get_current_time_ms()
    return os.clock() * 1000
end

-- 检查值是否在范围内
function utils.is_in_range(value, min, max)
    return value >= min and value <= max
end

-- 限制值在范围内
function utils.clamp(value, min, max)
    return math.max(min, math.min(max, value))
end

-- 创建v3向量
function utils.v3(x, y, z)
    x = x or 0.0
    y = y or 0.0
    z = z or 0.0
    return {x = x, y = y, z = z}
end

-- 格式化时间
function utils.format_time(seconds)
    local hours = math.floor(seconds / 3600)
    local minutes = math.floor((seconds % 3600) / 60)
    seconds = seconds % 60
    return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end

-- 格式化数字(添加千位分隔符)
function utils.format_number(number)
    local formatted = tostring(math.floor(number))
    local k = #formatted % 3
    if k == 0 then k = 3 end
    return string.sub(formatted, 1, k) .. string.gsub(string.sub(formatted, k+1), "(...)", ",%1")
end

-- 随机选择数组中的一个元素
function utils.random_choice(array)
    if #array > 0 then
        return array[math.random(1, #array)]
    end
    return nil
end

-- 检查表是否为空
function utils.is_table_empty(t)
    return next(t) == nil
end

-- 深度复制表
function utils.deep_copy(orig)
    local orig_type = type(orig)
    local copy
    if orig_type == 'table' then
        copy = {}
        for orig_key, orig_value in next, orig, nil do
            copy[utils.deep_copy(orig_key)] = utils.deep_copy(orig_value)
        end
        setmetatable(copy, utils.deep_copy(getmetatable(orig)))
    else
        copy = orig
    end
    return copy
end

-- 武器相关工具函数
function utils.set_weapon_recoil(weapon, value)
    if not value then value = 0.0 end
    WEAPON.SET_WEAPON_DAMAGE_MODIFIER(weapon, value)
end

-- 设置武器换弹速度
function utils.set_weapon_reload_speed(ped)
    -- 直接给予满弹药
    local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
    if weapon ~= 0 then
        WEAPON.REFILL_AMMO_INSTANTLY(ped)
    end
end

-- 时间循环修改器
function utils.set_timecycle_modifier(name, strength)
    if not strength then strength = 1.0 end
    if name then
        GRAPHICS.SET_TRANSITION_TIMECYCLE_MODIFIER(name, strength)
    else
        GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
    end
end

return utils 