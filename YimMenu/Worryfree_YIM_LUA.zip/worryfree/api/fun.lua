local core = require("worryfree/api/core")
local utils = require("worryfree/api/utils")
local fun = {}

-- 玩家特效
function fun.add_player_effects(menu)
    -- 超级力量
    local super_power = menu:add_checkbox("超级力量")
    script.register_looped("SuperPower", function()
        if super_power:is_enabled() then
            PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 500.0)
            PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 500.0)
        else
            PLAYER.SET_PLAYER_MELEE_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 1.0)
            PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 1.0)
        end
    end)

    -- 无限体力
    local infinite_stamina = menu:add_checkbox("无限体力")
    script.register_looped("InfiniteStamina", function()
        if infinite_stamina:is_enabled() then
            PLAYER.RESTORE_PLAYER_STAMINA(PLAYER.PLAYER_ID(), 100.0)
        end
    end)

    -- 隐身模式
    local invisible = menu:add_checkbox("隐身模式")
    script.register_looped("Invisible", function()
        if invisible:is_enabled() then
            ENTITY.SET_ENTITY_VISIBLE(PLAYER.PLAYER_PED_ID(), false, false)
        else
            ENTITY.SET_ENTITY_VISIBLE(PLAYER.PLAYER_PED_ID(), true, false)
        end
    end)

    -- 超级跳跃
    local super_jump = menu:add_checkbox("超级跳跃")
    script.register_looped("SuperJump", function()
        if super_jump:is_enabled() then
            MISC.SET_SUPER_JUMP_THIS_FRAME(core.player.get_id())
            if PAD.IS_CONTROL_JUST_PRESSED(0, 22) then -- 空格键
                local ped = core.player.get_ped()
                TASK.TASK_JUMP(ped, true)
                ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, 0.0, 0.0, 10.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
            end
        end
    end)

    -- 超级冲刺
    local super_sprint = menu:add_checkbox("超级冲刺")
    script.register_looped("SuperSprint", function()
        if super_sprint:is_enabled() then
            if PAD.IS_CONTROL_PRESSED(0, 21) then -- SHIFT键
                local ped = core.player.get_ped()
                local pos = core.utils.get_player_coords()
                local heading = ENTITY.GET_ENTITY_HEADING(ped)
                local force = 50.0
                
                if PAD.IS_CONTROL_PRESSED(0, 32) then -- W键
                    local x = force * math.sin(-math.rad(heading))
                    local y = force * math.cos(-math.rad(heading))
                    ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, x, y, 0.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
                end
            end
        end
    end)
    
    -- 超级滑行
    local super_slide = menu:add_checkbox("超级滑行")
    script.register_looped("SuperSlide", function()
        if super_slide:is_enabled() then
            if PAD.IS_CONTROL_PRESSED(0, 36) then -- C键
                local ped = core.player.get_ped()
                local pos = core.utils.get_player_coords()
                local heading = ENTITY.GET_ENTITY_HEADING(ped)
                local force = 30.0
                local x = force * math.sin(-math.rad(heading))
                local y = force * math.cos(-math.rad(heading))
                ENTITY.APPLY_FORCE_TO_ENTITY(ped, 1, x, y, 0.0, 0.0, 0.0, 0.0, 0, true, true, true, false, true)
            end
        end
    end)

    -- 爆炸拳
    local explosive_melee = menu:add_checkbox("爆炸拳")
    script.register_looped("ExplosiveMelee", function()
        if explosive_melee:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_IN_MELEE_COMBAT(ped) then
                local target = PED.GET_MELEE_TARGET_FOR_PED(ped)
                if target ~= 0 then
                    local target_pos = ENTITY.GET_ENTITY_COORDS(target, true)
                    -- 使用无伤害爆炸类型,并将玩家设为免疫
                    FIRE.ADD_OWNED_EXPLOSION(ped, target_pos.x, target_pos.y, target_pos.z, 7, 1.0, true, false, 0.0)
                end
            end
        end
    end)

    -- 火焰脚印
    local fire_footsteps = menu:add_checkbox("火焰脚印")
    script.register_looped("FireFootsteps", function()
        if fire_footsteps:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if ENTITY.IS_ENTITY_IN_AIR(ped) == false then
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z - 1.0, 38, 0.0, true, false, 0.0, false)
            end
        end
    end)
end

-- 世界特效
function fun.add_world_effects(menu)
    -- 暴乱模式
    local riot_mode = menu:add_checkbox("暴乱模式")
    script.register_looped("RiotMode", function()
        if riot_mode:is_enabled() then
            -- 通过设置所有NPC为敌对来模拟暴乱
            local peds = entities.get_all_peds_as_handles()
            for _, ped in ipairs(peds) do
                if not PED.IS_PED_A_PLAYER(ped) then
                    PED.SET_PED_COMBAT_ATTRIBUTES(ped, 46, true)
                    PED.SET_PED_FLEE_ATTRIBUTES(ped, 0, false)
                    PED.SET_PED_COMBAT_ABILITY(ped, 100)
                end
            end
        end
    end)

    -- 慢动作
    local slow_motion = menu:add_checkbox("慢动作")
    script.register_looped("SlowMotion", function()
        if slow_motion:is_enabled() then
            MISC.SET_TIME_SCALE(0.2)
        else
            MISC.SET_TIME_SCALE(1.0)
        end
    end)

    -- 低重力
    local low_gravity = menu:add_checkbox("低重力")
    script.register_looped("LowGravity", function()
        if low_gravity:is_enabled() then
            MISC.SET_GRAVITY_LEVEL(1)
        else
            MISC.SET_GRAVITY_LEVEL(0)
        end
    end)

    -- 雷暴天气
    local thunder_storm = menu:add_checkbox("雷暴天气")
    script.register_looped("ThunderStorm", function()
        if thunder_storm:is_enabled() then
            MISC.SET_WEATHER_TYPE_NOW_PERSIST("THUNDER")
            if math.random() < 0.1 then
                MISC.FORCE_LIGHTNING_FLASH()
            end
        end
    end)

    -- 醉酒效果
    local drunk_effect = menu:add_checkbox("醉酒效果")
    script.register_looped("DrunkEffect", function()
        if drunk_effect:is_enabled() then
            CAM.SET_CAM_SHAKE_AMPLITUDE(1.0)
            CAM.SHAKE_GAMEPLAY_CAM("DRUNK_SHAKE", 1.0)
        else
            CAM.STOP_GAMEPLAY_CAM_SHAKING(true)
            CAM.STOP_SCRIPT_GLOBAL_SHAKING(true)
        end
    end)

    -- 彩虹天气
    local rainbow_weather = menu:add_checkbox("彩虹天气")
    script.register_looped("RainbowWeather", function()
        if rainbow_weather:is_enabled() then
            local weathers = {"CLEAR", "CLOUDS", "SMOG", "FOGGY", "OVERCAST", "RAIN", "THUNDER", "CLEARING", "NEUTRAL"}
            if math.random() < 0.01 then
                local weather = weathers[math.random(#weathers)]
                MISC.SET_WEATHER_TYPE_NOW_PERSIST(weather)
            end
        end
    end)

    -- 随机车辆爆炸
    local random_explosions = menu:add_checkbox("随机车辆爆炸")
    script.register_looped("RandomExplosions", function()
        if random_explosions:is_enabled() then
            if math.random() < 0.01 then
                local vehicles = entities.get_all_vehicles_as_handles()
                if #vehicles > 0 then
                    local vehicle = vehicles[math.random(#vehicles)]
                    local pos = ENTITY.GET_ENTITY_COORDS(vehicle, true)
                    FIRE.ADD_EXPLOSION(pos.x, pos.y, pos.z, 7, 1.0, true, false, 0.0, false)
                end
            end
        end
    end)

    -- 彩虹车辆
    local rainbow_vehicles = menu:add_checkbox("彩虹车辆")
    script.register_looped("RainbowVehicles", function()
        if rainbow_vehicles:is_enabled() then
            local vehicles = entities.get_all_vehicles_as_handles()
            for _, vehicle in ipairs(vehicles) do
                local r = math.random(255)
                local g = math.random(255)
                local b = math.random(255)
                VEHICLE.SET_VEHICLE_CUSTOM_PRIMARY_COLOUR(vehicle, r, g, b)
                VEHICLE.SET_VEHICLE_CUSTOM_SECONDARY_COLOUR(vehicle, b, r, g)
            end
        end
    end)

    -- 混沌模式
    local chaos_mode = menu:add_checkbox("混沌模式")
    script.register_looped("ChaosMode", function()
        if chaos_mode:is_enabled() then
            -- 随机天气
            if math.random() < 0.01 then
                local weathers = {"CLEAR", "EXTRASUNNY", "CLOUDS", "OVERCAST", "RAIN", "CLEARING", "THUNDER", "SMOG", "FOGGY", "SNOW"}
                MISC.SET_WEATHER_TYPE_NOW_PERSIST(weathers[math.random(#weathers)])
            end
            
            -- 随机时间
            if math.random() < 0.01 then
                NETWORK.NETWORK_OVERRIDE_CLOCK_TIME(math.random(0, 23), math.random(0, 59), math.random(0, 59))
            end
            
            -- 随机爆炸
            if math.random() < 0.005 then
                local pos = core.utils.get_player_coords()
                local offset = 20.0
                local x = pos.x + (math.random() * offset * 2 - offset)
                local y = pos.y + (math.random() * offset * 2 - offset)
                local z = pos.z + (math.random() * offset * 2 - offset)
                FIRE.ADD_EXPLOSION(x, y, z, 7, 1.0, true, false, 0.0, false)
            end
        end
    end)

    -- 彩虹世界
    local rainbow_world = menu:add_checkbox("彩虹世界")
    script.register_looped("RainbowWorld", function()
        if rainbow_world:is_enabled() then
            local time = MISC.GET_GAME_TIMER() * 0.001
            local r = math.floor(math.sin(time) * 127 + 128)
            local g = math.floor(math.sin(time + 2) * 127 + 128)
            local b = math.floor(math.sin(time + 4) * 127 + 128)
            
            -- 修改天空颜色
            MISC.SET_TIMECYCLE_MODIFIER("rply_saturation")
            GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(1.0)
            
            -- 修改灯光颜色
            GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE(true)
            GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE_AFFECTS_VEHICLES(false)
            GRAPHICS.SET_ARTIFICIAL_VEHICLE_LIGHTS_STATE(false)
        else
            GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
            GRAPHICS.SET_ARTIFICIAL_LIGHTS_STATE(false)
        end
    end)
end

return fun
