local mission = {}

-- 任务助手
function mission.add_mission_helper(parent_tab)
    local helper = parent_tab:add_tab("任务助手")
    
    -- 赌场豪劫
    local casino = helper:add_tab("赌场豪劫")
    
    -- 设置目标
    local targets = {
        ["现金"] = 1,
        ["黄金"] = 2,
        ["艺术品"] = 3,
        ["钻石"] = 4
    }
    
    for name, value in pairs(targets) do
        casino:add_button("设置目标: " .. name, function()
            stats.set_int("MP0_H3OPT_TARGET", value)
            stats.set_int("MP1_H3OPT_TARGET", value)
        end)
    end
    
    -- 快速完成准备任务
    casino:add_button("跳过准备任务", function()
        local prefix = {"MP0_", "MP1_"}
        for _, p in ipairs(prefix) do
            stats.set_int(p .. "H3OPT_DISRUPTSHIP", 3)
            stats.set_int(p .. "H3OPT_KEYLEVELS", 2)
            stats.set_int(p .. "H3OPT_VEHS", 3)
            stats.set_int(p .. "H3OPT_WEAPS", 1)
            stats.set_int(p .. "H3OPT_BITSET0", -1)
            stats.set_int(p .. "H3OPT_BITSET1", -1)
            stats.set_int(p .. "H3OPT_COMPLETEDPOSIX", -1)
        end
    end)
    
    -- 佩里科岛
    local cayo = helper:add_tab("佩里科岛")
    
    -- 设置主要目标
    local primary_targets = {
        ["西西米托龙舌兰"] = 0,
        ["红宝石项链"] = 1,
        ["不记名债券"] = 2,
        ["粉钻"] = 3,
        ["玛德拉索文件"] = 4,
        ["蓝宝石猎豹雕像"] = 5
    }
    
    for name, value in pairs(primary_targets) do
        cayo:add_button("主要目标: " .. name, function()
            stats.set_int("MP0_H4CNF_TARGET", value)
            stats.set_int("MP1_H4CNF_TARGET", value)
        end)
    end
    
    -- 快速完成准备
    cayo:add_button("跳过准备任务", function()
        local prefix = {"MP0_", "MP1_"}
        for _, p in ipairs(prefix) do
            stats.set_int(p .. "H4CNF_BS_GEN", -1)
            stats.set_int(p .. "H4CNF_BS_ENTR", 63)
            stats.set_int(p .. "H4CNF_BS_ABIL", 63)
            stats.set_int(p .. "H4CNF_WEAPONS", 1)
            stats.set_int(p .. "H4CNF_WEP_DISRP", 3)
            stats.set_int(p .. "H4CNF_ARM_DISRP", 3)
            stats.set_int(p .. "H4CNF_HEL_DISRP", 3)
        end
    end)
    
    -- 末日豪劫
    local doomsday = helper:add_tab("末日豪劫")
    
    -- 设置ACT
    local acts = {
        ["数据泄露"] = 1,
        ["波格丹危机"] = 2,
        ["末日将至"] = 3
    }
    
    for name, value in pairs(acts) do
        doomsday:add_button("设置ACT: " .. name, function()
            stats.set_int("MP0_GANGOPS_FLOW_MISSION_PROG", value)
            stats.set_int("MP1_GANGOPS_FLOW_MISSION_PROG", value)
        end)
    end
end

-- 任务修改器
function mission.add_mission_modifier(parent_tab)
    local modifier = parent_tab:add_tab("任务修改器")
    
    -- 任务倍率
    local multipliers = modifier:add_tab("任务倍率")
    
    -- RP倍率
    multipliers:add_slider("RP倍率", 1, 1000, 1, function(value)
        globals.set_float(262145 + 1, value)
    end)
    
    -- 金钱倍率
    multipliers:add_slider("金钱倍率", 1, 1000, 1, function(value)
        globals.set_float(262145 + 2, value)
    end)
    
    -- 任务难度
    local difficulties = {
        ["简单"] = 0,
        ["普通"] = 1,
        ["困难"] = 2
    }
    
    local difficulty_menu = modifier:add_tab("任务难度")
    for name, value in pairs(difficulties) do
        difficulty_menu:add_button(name, function()
            globals.set_int(2815059 + 4624, value)
        end)
    end
end

return mission 