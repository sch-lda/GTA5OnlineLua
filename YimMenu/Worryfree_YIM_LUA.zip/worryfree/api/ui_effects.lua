local ui_effects = {}

-- UI绘制状态
local ui_state = {
    enabled = false,
    last_frame_time = os.clock(),
    frame_count = 0,
    current_fps = 0,
    update_interval = 0.5, -- 每0.5秒更新一次FPS
    last_update_time = 0,
    position = {x = 0.01, y = 0.01}, -- 左上角位置
    scale = {x = 0.3, y = 0.3},      -- 文本大小
    colors = {
        background = {r = 0, g = 0, b = 0, a = 150},
        text = {r = 255, g = 255, b = 255, a = 255},
        fps_normal = {r = 0, g = 255, b = 0, a = 255},
        fps_warning = {r = 255, g = 255, b = 0, a = 255},
        fps_critical = {r = 255, g = 0, b = 0, a = 255}
    }
}

-- 计算FPS
local function calculate_fps()
    local current_time = os.clock()
    local delta_time = current_time - ui_state.last_frame_time
    ui_state.frame_count = ui_state.frame_count + 1

    if current_time - ui_state.last_update_time >= ui_state.update_interval then
        ui_state.current_fps = math.floor(ui_state.frame_count / (current_time - ui_state.last_update_time))
        ui_state.frame_count = 0
        ui_state.last_update_time = current_time
    end

    ui_state.last_frame_time = current_time
end

-- 获取FPS颜色
local function get_fps_color()
    if ui_state.current_fps >= 50 then
        return ui_state.colors.fps_normal
    elseif ui_state.current_fps >= 30 then
        return ui_state.colors.fps_warning
    else
        return ui_state.colors.fps_critical
    end
end

-- 获取当前时间
local function get_current_time()
    return os.date("%H:%M:%S")
end

-- 获取游戏内时间
local function get_game_time()
    local hours = CLOCK.GET_CLOCK_HOURS()
    local minutes = CLOCK.GET_CLOCK_MINUTES()
    local seconds = CLOCK.GET_CLOCK_SECONDS()
    return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end

-- 绘制背景
local function draw_background(x, y, width, height)
    local color = ui_state.colors.background
    GRAPHICS.DRAW_RECT(x, y, width, height, color.r, color.g, color.b, color.a)
end

-- 绘制文本
local function draw_text(text, x, y, scale, color)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)
    HUD.SET_TEXT_SCALE(scale.x, scale.y)
    HUD.SET_TEXT_COLOUR(color.r, color.g, color.b, color.a)
    HUD.SET_TEXT_CENTRE(false)
    HUD.SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0)
end

-- 添加UI效果到菜单
function ui_effects.add_ui_effects(menu)
    local effects = menu:add_tab("界面效果")
    
    -- 显示/隐藏UI
    local show_ui = effects:add_checkbox("显示界面信息")
    script.register_looped("ShowUI", function()
        ui_state.enabled = show_ui:is_enabled()
        
        if ui_state.enabled then
            -- 计算FPS
            calculate_fps()
            
            -- 获取时间信息
            local real_time = get_current_time()
            local game_time = get_game_time()
            
            -- 绘制背景
            local bg_width = 0.15
            local bg_height = 0.08
            local bg_x = ui_state.position.x + (bg_width / 2)
            local bg_y = ui_state.position.y + (bg_height / 2)
            draw_background(bg_x, bg_y, bg_width, bg_height)
            
            -- 绘制文本
            local text_x = ui_state.position.x + 0.01
            local text_y = ui_state.position.y + 0.01
            local line_spacing = 0.025
            
            -- 显示FPS
            local fps_color = get_fps_color()
            draw_text(string.format("FPS: %d", ui_state.current_fps), 
                     text_x, text_y, ui_state.scale, fps_color)
            
            -- 显示真实时间
            draw_text(string.format("系统时间: %s", real_time),
                     text_x, text_y + line_spacing, ui_state.scale, ui_state.colors.text)
            
            -- 显示游戏时间
            draw_text(string.format("游戏时间: %s", game_time),
                     text_x, text_y + (line_spacing * 2), ui_state.scale, ui_state.colors.text)
        end
    end)
    
    -- 位置预设
    local position_presets = effects:add_tab("位置预设")
    position_presets:add_button("左上角", function()
        ui_state.position = {x = 0.01, y = 0.01}
    end)
    position_presets:add_button("右上角", function()
        ui_state.position = {x = 0.84, y = 0.01}
    end)
    position_presets:add_button("左下角", function()
        ui_state.position = {x = 0.01, y = 0.91}
    end)
    position_presets:add_button("右下角", function()
        ui_state.position = {x = 0.84, y = 0.91}
    end)
    
    -- 大小预设
    local size_presets = effects:add_tab("大小预设")
    size_presets:add_button("小", function()
        ui_state.scale = {x = 0.2, y = 0.2}
    end)
    size_presets:add_button("中", function()
        ui_state.scale = {x = 0.3, y = 0.3}
    end)
    size_presets:add_button("大", function()
        ui_state.scale = {x = 0.4, y = 0.4}
    end)
    
    -- 背景透明度预设
    local alpha_presets = effects:add_tab("透明度预设")
    alpha_presets:add_button("完全透明", function()
        ui_state.colors.background.a = 0
    end)
    alpha_presets:add_button("半透明", function()
        ui_state.colors.background.a = 150
    end)
    alpha_presets:add_button("不透明", function()
        ui_state.colors.background.a = 255
    end)
end

return ui_effects
