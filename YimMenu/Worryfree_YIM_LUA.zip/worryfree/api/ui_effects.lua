local core = require("worryfree/api/core")
local utils = require("worryfree/api/utils")
local ui_effects = {}

-- UI绘制状态
local ui_state = {
    enabled = false,
    last_frame_time = os.clock(),
    frame_count = 0,
    current_fps = 0,
    update_interval = 0.5, -- 每0.5秒更新一次FPS
    last_update_time = 0,
    position = {x = 0.01, y = 0.01}, -- 左上角位置
    scale = {x = 0.3, y = 0.3},      -- 文本大小
    colors = {
        background = {r = 0, g = 0, b = 0, a = 150},
        text = {r = 255, g = 255, b = 255, a = 255},
        fps_normal = {r = 0, g = 255, b = 0, a = 255},
        fps_warning = {r = 255, g = 255, b = 0, a = 255},
        fps_critical = {r = 255, g = 0, b = 0, a = 255}
    }
}

-- 存储当前显示的横幅
local current_banners = {}
local max_banners = 3  -- 最大同时显示数量

-- 横幅通知的基本设置
local BANNER_SETTINGS = {
    duration = 5000,    -- 显示时间(毫秒)
    fade_in = 300,     -- 淡入时间
    fade_out = 300,    -- 淡出时间
    margin = 20,       -- 边距
    padding = 25,      -- 内边距
    height = 60,       -- 高度
    start_y = 150,     -- 起始Y坐标
    icon_size = 30,    -- 图标大小
    slide_distance = 50 -- 滑动距离
}

-- 横幅图标设置
local BANNER_ICONS = {
    info = "❯",
    success = "✓",
    warning = "⚠",
    error = "✕"
}

-- 获取当前时间戳(毫秒)
local function get_current_time_ms()
    return os.clock() * 1000
end

-- 计算FPS
local function calculate_fps()
    local current_time = os.clock()
    local delta_time = current_time - ui_state.last_frame_time
    ui_state.frame_count = ui_state.frame_count + 1

    if current_time - ui_state.last_update_time >= ui_state.update_interval then
        ui_state.current_fps = math.floor(ui_state.frame_count / (current_time - ui_state.last_update_time))
        ui_state.frame_count = 0
        ui_state.last_update_time = current_time
    end

    ui_state.last_frame_time = current_time
end

-- 获取FPS颜色
local function get_fps_color()
    if ui_state.current_fps >= 50 then
        return ui_state.colors.fps_normal
    elseif ui_state.current_fps >= 30 then
        return ui_state.colors.fps_warning
    else
        return ui_state.colors.fps_critical
    end
end

-- 获取当前时间
local function get_current_time()
    return os.date("%H:%M:%S")
end

-- 获取游戏内时间
local function get_game_time()
    local hours = CLOCK.GET_CLOCK_HOURS()
    local minutes = CLOCK.GET_CLOCK_MINUTES()
    local seconds = CLOCK.GET_CLOCK_SECONDS()
    return string.format("%02d:%02d:%02d", hours, minutes, seconds)
end

-- 绘制背景
local function draw_background(x, y, width, height)
    local color = ui_state.colors.background
    GRAPHICS.DRAW_RECT(x, y, width, height, color.r, color.g, color.b, color.a)
end

-- 绘制文本
local function draw_text(text, x, y, scale, color)
    HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
    HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(text)
    HUD.SET_TEXT_SCALE(scale.x, scale.y)
    HUD.SET_TEXT_COLOUR(color.r, color.g, color.b, color.a)
    HUD.SET_TEXT_CENTRE(false)
    HUD.SET_TEXT_DROPSHADOW(0, 0, 0, 0, 255)
    HUD.END_TEXT_COMMAND_DISPLAY_TEXT(x, y, 0)
end

-- 添加UI效果到菜单
function ui_effects.add_ui_effects(menu)
    -- 创建UI特效主选项卡
    local effects = menu:add_tab("UI特效")
    
    -- 信息显示面板
    local info_display = effects:add_tab("信息显示")
    
    -- 基础开关
    local enable_info = info_display:add_checkbox("启用信息显示")
    enable_info:set_enabled(true)
    
    -- 显示项目设置
    local show_items = {
        time = info_display:add_checkbox("显示时间信息"),
        money = info_display:add_checkbox("显示金钱信息"),
        health = info_display:add_checkbox("显示生命值"),
        armor = info_display:add_checkbox("显示护甲值"),
        wanted = info_display:add_checkbox("显示通缉等级"),
        vehicle = info_display:add_checkbox("显示车速")
    }
    -- 默认全部开启
    for _, checkbox in pairs(show_items) do
        checkbox:set_enabled(true)
    end
    
    -- 位置设置
    local current_position = 1  -- 1=左上, 2=右上, 3=左下, 4=右下
    local position_text = info_display:add_text("当前位置: 左上")
    
    -- 切换位置按钮
    info_display:add_button("切换位置", function()
        current_position = current_position + 1
        if current_position > 4 then
            current_position = 1
        end
        
        local position_names = {
            [1] = "左上",
            [2] = "右上",
            [3] = "左下",
            [4] = "右下"
        }
        position_text:set_text("当前位置: " .. position_names[current_position])
    end)
    
    -- 背景透明度 (0-255)
    local bg_alpha = info_display:add_input_int("背景透明度 (0-255)")
    bg_alpha:set_value(180)
    
    -- 文字大小 (20-50)
    local text_scale = info_display:add_input_int("文字大小 (20-50)")
    text_scale:set_value(30)
    
    -- 注册信息显示循环
    script.register_looped("InfoDisplay", function()
        if not enable_info:is_enabled() then return end
        
        -- 获取并限制输入值的范围
        local alpha_value = math.max(0, math.min(255, bg_alpha:get_value()))
        local scale_value = math.max(20, math.min(50, text_scale:get_value())) / 100
        
        -- 获取屏幕分辨率
        local screen_w, screen_h = GRAPHICS.GET_SCREEN_RESOLUTION(0, 0)
        
        -- 根据选择的位置设置基础坐标
        local base_x, base_y
        if current_position == 1 then  -- 左上
            base_x, base_y = 0.01, 0.01
        elseif current_position == 2 then  -- 右上
            base_x, base_y = 0.79, 0.01
        elseif current_position == 3 then  -- 左下
            base_x, base_y = 0.01, 0.75
        else  -- 右下
            base_x, base_y = 0.79, 0.75
        end
        
        -- 设置基础大小
        local box_width = 0.2
        local box_height = 0.15
        local line_height = 0.02
        
        -- 获取所有需要显示的信息
        local info_texts = {}
        
        -- 获取玩家信息
        local player_id = PLAYER.PLAYER_ID()
        local ped = PLAYER.PLAYER_PED_ID()
        local vehicle = PED.GET_VEHICLE_PED_IS_IN(ped, false)
        
        -- 根据设置添加显示项
        if show_items.time:is_enabled() then
            table.insert(info_texts, {"现实时间", os.date("%H:%M:%S"), {r=255, g=215, b=0}})
            table.insert(info_texts, {"游戏时间", string.format("%02d:%02d:%02d", 
                CLOCK.GET_CLOCK_HOURS(), 
                CLOCK.GET_CLOCK_MINUTES(), 
                CLOCK.GET_CLOCK_SECONDS()), 
                {r=255, g=215, b=0}})
        end
        
        if show_items.money:is_enabled() then
            local bank_money = stats.get_int("BANK_BALANCE")
            local cash_money = stats.get_int("MP0_WALLET_BALANCE")
            table.insert(info_texts, {"银行现金", "$" .. tostring(bank_money), {r=0, g=255, b=0}})
            table.insert(info_texts, {"现金", "$" .. tostring(cash_money), {r=0, g=255, b=0}})
        end
        
        if show_items.health:is_enabled() then
            local health = ENTITY.GET_ENTITY_HEALTH(ped)
            local max_health = ENTITY.GET_ENTITY_MAX_HEALTH(ped)
            table.insert(info_texts, {"生命值", string.format("%d/%d", health, max_health), {r=255, g=50, b=50}})
        end
        
        if show_items.armor:is_enabled() then
            local armor = PED.GET_PED_ARMOUR(ped)
            table.insert(info_texts, {"护甲值", tostring(armor), {r=50, g=150, b=255}})
        end
        
        if show_items.wanted:is_enabled() then
            local wanted_level = PLAYER.GET_PLAYER_WANTED_LEVEL(player_id)
            table.insert(info_texts, {"通缉等级", string.format("%d★", wanted_level), {r=255, g=150, b=0}})
        end
        
        if show_items.vehicle:is_enabled() and vehicle then
            local speed = math.floor(ENTITY.GET_ENTITY_SPEED(vehicle) * 3.6)
            table.insert(info_texts, {"车速", speed .. " km/h", {r=255, g=255, b=255}})
        end
        
        -- 绘制背景
        GRAPHICS.DRAW_RECT(
            base_x + box_width/2, 
            base_y + box_height/2,
            box_width,
            box_height,
            0, 0, 0, alpha_value
        )
        
        -- 绘制装饰边框(中国红)
        GRAPHICS.DRAW_RECT(
            base_x + box_width/2,
            base_y,
            box_width,
            0.003,
            255, 40, 40, 255
        )
        
        -- 绘制信息文本
        local current_y = base_y + 0.005
        for _, info in ipairs(info_texts) do
            local label, value, color = table.unpack(info)
            
            -- 绘制标签
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(label .. ":")
            HUD.SET_TEXT_SCALE(scale_value, scale_value)
            HUD.SET_TEXT_COLOUR(255, 255, 255, 255)
            HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(base_x + 0.005, current_y, 0)
            
            -- 绘制值
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(value)
            HUD.SET_TEXT_SCALE(scale_value, scale_value)
            HUD.SET_TEXT_COLOUR(color.r, color.g, color.b, 255)
            HUD.SET_TEXT_DROPSHADOW(1, 0, 0, 0, 255)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(base_x + 0.1, current_y, 0)
            
            current_y = current_y + line_height
        end
    end)
    
    -- 横幅测试选项卡
    local banner_test = effects:add_tab("横幅测试")
    
    -- 添加测试按钮
    banner_test:add_button("测试所有横幅", function()
        ui_effects.show_banner("这是一条信息通知", "info")
        utils.sleep(1000)  -- 使用utils.sleep替代script.yield
        ui_effects.show_banner("操作成功!", "success")
        utils.sleep(1000)
        ui_effects.show_banner("警告: 请注意!", "warning")
        utils.sleep(1000)
        ui_effects.show_banner("发生错误!", "error")
    end)
    
    banner_test:add_button("显示信息横幅", function()
        ui_effects.show_banner("这是一条信息通知", "info")
    end)
    
    banner_test:add_button("显示成功横幅", function()
        ui_effects.show_banner("操作成功!", "success")
    end)
    
    banner_test:add_button("显示警告横幅", function()
        ui_effects.show_banner("警告: 请注意!", "warning")
    end)
    
    banner_test:add_button("显示错误横幅", function()
        ui_effects.show_banner("发生错误!", "error")
    end)
    
    -- 屏幕效果选项卡
    local screen = effects:add_tab("屏幕效果")
    
    -- 夜视仪效果
    local night_vision = screen:add_checkbox("夜视仪")
    script.register_looped("NightVision", function()
        if night_vision:is_enabled() then
            GRAPHICS.SET_NIGHTVISION(true)
            GRAPHICS.SET_TIMECYCLE_MODIFIER("blackout")
            GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(0.5)
        else
            GRAPHICS.SET_NIGHTVISION(false)
            GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
        end
    end)
    
    -- 热成像效果
    local thermal_vision = screen:add_checkbox("热成像")
    script.register_looped("ThermalVision", function()
        if thermal_vision:is_enabled() then
            GRAPHICS.SET_SEETHROUGH(true)
            GRAPHICS.SET_TIMECYCLE_MODIFIER("CAMERA_secuirity_FUZZ")
            GRAPHICS.SET_TIMECYCLE_MODIFIER_STRENGTH(1.0)
        else
            GRAPHICS.SET_SEETHROUGH(false)
            GRAPHICS.CLEAR_TIMECYCLE_MODIFIER()
        end
    end)
    
    -- HUD设置选项卡
    local hud = effects:add_tab("HUD设置")
    
    -- 隐藏HUD
    local hide_hud = hud:add_checkbox("隐藏HUD")
    script.register_looped("HideHUD", function()
        if hide_hud:is_enabled() then
            HUD.HIDE_HUD_AND_RADAR_THIS_FRAME()
        end
    end)
    
    -- 隐藏小地图
    local hide_radar = hud:add_checkbox("隐藏小地图")
    script.register_looped("HideRadar", function()
        if hide_radar:is_enabled() then
            HUD.DISPLAY_RADAR(false)
        else
            HUD.DISPLAY_RADAR(true)
        end
    end)
    
    -- 自定义小地图缩放
    local radar_zoom = hud:add_input_int("小地图缩放 (0-100)")
    radar_zoom:set_value(0)
    script.register_looped("RadarZoom", function()
        if not hide_radar:is_enabled() then
            local value = math.max(0, math.min(100, radar_zoom:get_value()))
            HUD.SET_RADAR_ZOOM(value)
        end
    end)
    
    -- 通知效果选项卡
    local notifications = effects:add_tab("通知效果")
    
    -- 帮助文本效果选项卡
    local help_text = effects:add_tab("帮助文本效果")
    
    -- 测试帮助文本
    help_text:add_button("显示测试帮助", function()
        core.ui.show_help("这是一条测试帮助文本", 5000)
    end)
    
    return effects
end

-- 创建新的横幅通知
function ui_effects.show_banner(text, type)
    type = type or "info"
    
    -- 颜色设置 (使用更现代的颜色)
    local colors = {
        info = {r = 66, g = 139, b = 202, a = 255},      -- 现代蓝
        success = {r = 92, g = 184, b = 92, a = 255},    -- 柔和绿
        warning = {r = 240, g = 173, b = 78, a = 255},   -- 温暖橙
        error = {r = 217, g = 83, b = 79, a = 255}       -- 柔和红
    }
    
    -- 创建新横幅
    local banner = {
        text = text,
        type = type,
        color = colors[type],
        icon = BANNER_ICONS[type],
        start_time = get_current_time_ms(),
        alpha = 0,
        offset_x = BANNER_SETTINGS.slide_distance,  -- 初始X偏移
        scale = 0.8  -- 初始缩放
    }
    
    -- 添加到显示队列
    table.insert(current_banners, banner)
    
    -- 如果超过最大显示数量,移除最早的
    while #current_banners > max_banners do
        table.remove(current_banners, 1)
    end
end

-- 更新和渲染横幅
script.register_looped("banner_update", function()
    local current_time = get_current_time_ms()
    local screen_w, screen_h = GRAPHICS.GET_SCREEN_RESOLUTION(0, 0)
    
    -- 遍历所有横幅
    for i = #current_banners, 1, -1 do
        local banner = current_banners[i]
        local elapsed = current_time - banner.start_time
        
        -- 计算动画值
        if elapsed < BANNER_SETTINGS.fade_in then
            -- 淡入阶段
            local progress = elapsed / BANNER_SETTINGS.fade_in
            banner.alpha = math.floor(progress * 255)
            banner.offset_x = BANNER_SETTINGS.slide_distance * (1 - progress)
            banner.scale = 0.8 + (0.2 * progress)
        elseif elapsed > BANNER_SETTINGS.duration - BANNER_SETTINGS.fade_out then
            -- 淡出阶段
            local progress = (BANNER_SETTINGS.duration - elapsed) / BANNER_SETTINGS.fade_out
            banner.alpha = math.floor(progress * 255)
            banner.offset_x = BANNER_SETTINGS.slide_distance * (1 - progress)
            banner.scale = 0.8 + (0.2 * progress)
        else
            -- 完全显示
            banner.alpha = 255
            banner.offset_x = 0
            banner.scale = 1.0
        end
        
        -- 如果显示时间结束,移除横幅
        if elapsed >= BANNER_SETTINGS.duration then
            table.remove(current_banners, i)
        else
            -- 计算位置
            local y_pos = BANNER_SETTINGS.start_y + (i - 1) * (BANNER_SETTINGS.height + BANNER_SETTINGS.margin)
            local x_center = 0.5 + (banner.offset_x / screen_w)
            
            -- 绘制主背景 (带模糊效果)
            local bg_alpha = math.floor(banner.alpha * 0.85)
            GRAPHICS.DRAW_RECT(
                x_center,
                y_pos / screen_h,
                (screen_w - BANNER_SETTINGS.margin * 4) / screen_w,
                BANNER_SETTINGS.height / screen_h,
                20, 20, 20, bg_alpha
            )
            
            -- 绘制左侧装饰条
            GRAPHICS.DRAW_RECT(
                x_center - ((screen_w - BANNER_SETTINGS.margin * 4) / screen_w / 2),
                y_pos / screen_h,
                3 / screen_w,
                (BANNER_SETTINGS.height - 10) / screen_h,
                banner.color.r,
                banner.color.g,
                banner.color.b,
                banner.alpha
            )
            
            -- 绘制图标
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(banner.icon)
            HUD.SET_TEXT_SCALE(0.6 * banner.scale, 0.6 * banner.scale)
            HUD.SET_TEXT_COLOUR(banner.color.r, banner.color.g, banner.color.b, banner.alpha)
            HUD.SET_TEXT_CENTRE(true)
            HUD.SET_TEXT_DROPSHADOW(2, 0, 0, 0, banner.alpha)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(
                x_center - 0.15,
                (y_pos - 5) / screen_h,
                0
            )
            
            -- 绘制文本
            HUD.BEGIN_TEXT_COMMAND_DISPLAY_TEXT("STRING")
            HUD.ADD_TEXT_COMPONENT_SUBSTRING_PLAYER_NAME(banner.text)
            HUD.SET_TEXT_SCALE(0.45 * banner.scale, 0.45 * banner.scale)
            HUD.SET_TEXT_COLOUR(255, 255, 255, banner.alpha)
            HUD.SET_TEXT_DROPSHADOW(2, 0, 0, 0, banner.alpha)
            HUD.SET_TEXT_WRAP(x_center - 0.1, x_center + 0.1)
            HUD.END_TEXT_COMMAND_DISPLAY_TEXT(
                x_center,
                (y_pos - BANNER_SETTINGS.height / 4) / screen_h,
                0
            )
        end
    end
end)

return ui_effects
