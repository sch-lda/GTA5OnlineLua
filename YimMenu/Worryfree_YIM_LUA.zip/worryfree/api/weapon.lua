local weapon = {}

-- 武器改装
function weapon.add_weapon_mods(parent_tab)
    local mods = parent_tab:add_tab("武器改装")
    
    -- 无限弹药
    local infinite_ammo = mods:add_checkbox("无限弹药")
    script.register_looped("InfiniteAmmo", function()
        if infinite_ammo:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            WEAPON.SET_PED_INFINITE_AMMO_CLIP(ped, true)
        else
            local ped = PLAYER.PLAYER_PED_ID()
            WEAPON.SET_PED_INFINITE_AMMO_CLIP(ped, false)
        end
    end)

    -- 无后坐力
    local no_recoil = mods:add_checkbox("无后坐力")
    script.register_looped("NoRecoil", function()
        if no_recoil:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                WEAPON.SET_WEAPON_RECOIL_SHAKE_AMPLITUDE(weapon, 0.0)
            end
        end
    end)

    -- 无扩散
    local no_spread = mods:add_checkbox("无扩散")
    script.register_looped("NoSpread", function()
        if no_spread:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                WEAPON.SET_WEAPON_ACCURACY(weapon, 100.0)
            end
        end
    end)

    -- 快速换弹
    local fast_reload = mods:add_checkbox("快速换弹")
    script.register_looped("FastReload", function()
        if fast_reload:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if WEAPON.IS_PED_ARMED(ped, 4) then
                PED.SET_PED_RELOAD_WEAPON_INSTANTLY(ped, true)
            end
        end
    end)

    -- 自动瞄准
    local auto_aim = mods:add_checkbox("自动瞄准")
    script.register_looped("AutoAim", function()
        if auto_aim:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PLAYER.SET_PLAYER_TARGETING_MODE(1) -- 自动瞄准模式
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local closest_ped = nil
                local min_dist = 1000000.0
                local player_pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                
                -- 寻找最近的NPC
                local peds = entities.get_all_peds_as_handles()
                for _, target in ipairs(peds) do
                    if target ~= ped and not ENTITY.IS_ENTITY_DEAD(target) then
                        local target_pos = ENTITY.GET_ENTITY_COORDS(target, true)
                        local dist = SYSTEM.VDIST(player_pos.x, player_pos.y, player_pos.z,
                                                target_pos.x, target_pos.y, target_pos.z)
                        if dist < min_dist then
                            min_dist = dist
                            closest_ped = target
                        end
                    end
                end
                
                -- 瞄准最近的NPC
                if closest_ped then
                    local target_pos = ENTITY.GET_ENTITY_COORDS(closest_ped, true)
                    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(
                        player_pos.x, player_pos.y, player_pos.z,
                        target_pos.x, target_pos.y, target_pos.z,
                        1, true, WEAPON.GET_SELECTED_PED_WEAPON(ped), ped, true, false, 1000.0
                    )
                end
            end
        end
    end)

    -- 子弹类型选择器
    local bullet_types = {
        ["普通子弹"] = 0,
        ["爆炸子弹"] = 1,
        ["燃烧子弹"] = 2,
        ["穿甲子弹"] = 3,
        ["电击子弹"] = 4,
        ["EMP子弹"] = 5
    }
    
    -- 一键最大化改装
    mods:add_button("一键最大改装", function()
        local ped = PLAYER.PLAYER_PED_ID()
        local weapon_hash = WEAPON.GET_SELECTED_PED_WEAPON(ped)
        
        -- 添加所有配件
        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weapon_hash, 0x359B7AAE) -- 消音器
        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weapon_hash, 0x65EA7EBB) -- 扩容弹夹
        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weapon_hash, 0x7BC4CDDC) -- 手电筒
        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weapon_hash, 0x9D2FBF29) -- 瞄准镜
        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, weapon_hash, 0xA73D4664) -- 握把
        
        -- 设置武器染色
        WEAPON.SET_PED_WEAPON_TINT_INDEX(ped, weapon_hash, 7) -- 彩虹色
    end)
    
    -- 武器染色
    local tints = {
        ["默认"] = 0,
        ["绿色"] = 1,
        ["金色"] = 2,
        ["粉色"] = 3,
        ["军绿"] = 4,
        ["橙色"] = 5,
        ["铂金"] = 6,
        ["彩虹"] = 7
    }
    
    local tint_menu = mods:add_tab("武器染色")
    for name, index in pairs(tints) do
        tint_menu:add_button(name, function()
            local ped = PLAYER.PLAYER_PED_ID()
            local weapon_hash = WEAPON.GET_SELECTED_PED_WEAPON(ped)
            WEAPON.SET_PED_WEAPON_TINT_INDEX(ped, weapon_hash, index)
        end)
    end
end

-- 武器效果
function weapon.add_weapon_effects(parent_tab)
    local effects = parent_tab:add_tab("武器效果")
    
    -- 子弹类型
    local bullet_types = {
        ["普通子弹"] = 0,
        ["爆炸子弹"] = 1,
        ["燃烧子弹"] = 2,
        ["穿甲子弹"] = 3,
        ["电击子弹"] = 4,
        ["EMP子弹"] = 5,
        ["追踪子弹"] = 6
    }
    
    for name, type in pairs(bullet_types) do
        local bullet_toggle = effects:add_checkbox(name)
        script.register_looped(name, function()
            if bullet_toggle:is_enabled() then
                local ped = PLAYER.PLAYER_PED_ID()
                WEAPON.SET_PED_AMMO_TO_DROP(ped, 0) -- 防止掉落弹药
                
                if type == 1 then
                    MISC.SET_EXPLOSIVE_AMMO_THIS_FRAME(PLAYER.PLAYER_ID())
                elseif type == 2 then
                    MISC.SET_FIRE_AMMO_THIS_FRAME(PLAYER.PLAYER_ID())
                end
                
                -- 其他子弹类型的效果...
            end
        end)
    end
    
    -- 无后坐力
    local no_recoil = effects:add_checkbox("无后坐力")
    script.register_looped("NoRecoil", function()
        if no_recoil:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            WEAPON.SET_PED_SHOOT_RATE(ped, 1000)
        end
    end)
    
    -- 无需换弹
    local no_reload = effects:add_checkbox("无需换弹")
    script.register_looped("NoReload", function()
        if no_reload:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            local weapon_hash = WEAPON.GET_SELECTED_PED_WEAPON(ped)
            local _, max_ammo = WEAPON.GET_MAX_AMMO(ped, weapon_hash)
            WEAPON.SET_PED_AMMO(ped, weapon_hash, max_ammo)
        end
    end)
end

-- 武器生成器
function weapon.add_weapon_spawner(menu)
    -- 常用武器列表
    local common_weapons = {
        ["手枪"] = "WEAPON_PISTOL",
        ["战斗手枪"] = "WEAPON_COMBATPISTOL",
        ["重型手枪"] = "WEAPON_HEAVYPISTOL",
        ["冲锋手枪"] = "WEAPON_APPISTOL",
        ["微型冲锋枪"] = "WEAPON_MICROSMG",
        ["冲锋枪"] = "WEAPON_SMG",
        ["突击步枪"] = "WEAPON_ASSAULTRIFLE",
        ["卡宾步枪"] = "WEAPON_CARBINERIFLE",
        ["高级步枪"] = "WEAPON_ADVANCEDRIFLE",
        ["狙击步枪"] = "WEAPON_SNIPERRIFLE",
        ["重型狙击步枪"] = "WEAPON_HEAVYSNIPER",
        ["霰弹枪"] = "WEAPON_PUMPSHOTGUN",
        ["战斗霰弹枪"] = "WEAPON_COMBATSHOTGUN",
        ["火箭筒"] = "WEAPON_RPG",
        ["制导火箭筒"] = "WEAPON_HOMINGLAUNCHER",
        ["电击枪"] = "WEAPON_STUNGUN",
        ["近战武器"] = "WEAPON_KNIFE",
        ["棒球棍"] = "WEAPON_BAT",
        ["燃烧瓶"] = "WEAPON_MOLOTOV",
        ["手榴弹"] = "WEAPON_GRENADE"
    }
    
    -- 创建武器生成菜单
    local spawner = menu:add_tab("武器生成器")
    for name, hash in pairs(common_weapons) do
        spawner:add_button(name, function()
            local ped = PLAYER.PLAYER_PED_ID()
            local weapon_hash = MISC.GET_HASH_KEY(hash)
            WEAPON.GIVE_WEAPON_TO_PED(ped, weapon_hash, 9999, false, true)
            WEAPON.SET_CURRENT_PED_WEAPON(ped, weapon_hash, true)
        end)
    end
    
    -- 补充弹药
    spawner:add_button("补充所有弹药", function()
        local ped = PLAYER.PLAYER_PED_ID()
        for _, hash in pairs(common_weapons) do
            local weapon_hash = MISC.GET_HASH_KEY(hash)
            if WEAPON.HAS_PED_GOT_WEAPON(ped, weapon_hash, false) then
                local _, max_ammo = WEAPON.GET_MAX_AMMO(ped, weapon_hash)
                WEAPON.SET_PED_AMMO(ped, weapon_hash, max_ammo)
            end
        end
    end)

    -- 移除所有武器
    spawner:add_button("移除所有武器", function()
        local ped = PLAYER.PLAYER_PED_ID()
        WEAPON.REMOVE_ALL_PED_WEAPONS(ped, true)
    end)
end

return weapon 