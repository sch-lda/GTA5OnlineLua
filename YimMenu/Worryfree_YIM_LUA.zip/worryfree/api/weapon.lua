local core = require("worryfree/api/core")
local utils = require("worryfree/api/utils")
local weapon = {}

-- 创建v3向量
local function v3(x, y, z)
    x = x or 0.0
    y = y or 0.0
    z = z or 0.0
    return {x = x, y = y, z = z}
end

-- 添加武器生成器
function weapon.add_weapon_spawner(menu)
    local spawner = menu:add_tab("武器生成器")
    
    -- 常用武器列表
    local common_weapons = {
        {"手枪", "WEAPON_PISTOL"},
        {"冲锋枪", "WEAPON_SMG"},
        {"步枪", "WEAPON_CARBINERIFLE"},
        {"狙击枪", "WEAPON_HEAVYSNIPER"},
        {"火箭筒", "WEAPON_RPG"},
        {"微型冲锋枪", "WEAPON_MICROSMG"},
        {"霰弹枪", "WEAPON_PUMPSHOTGUN"}
    }
    
    -- 添加常用武器按钮
    for _, weapon_info in ipairs(common_weapons) do
        spawner:add_button(weapon_info[1], function()
            WEAPON.GIVE_WEAPON_TO_PED(PLAYER.PLAYER_PED_ID(), utils.joaat(weapon_info[2]), 9999, false, true)
            core.ui.notify("已获得 " .. weapon_info[1])
        end)
    end
    
    -- 移除所有武器
    spawner:add_button("移除所有武器", function()
        WEAPON.REMOVE_ALL_PED_WEAPONS(PLAYER.PLAYER_PED_ID(), true)
        core.ui.notify("已移除所有武器")
    end)
end

-- 添加武器改装
function weapon.add_weapon_mods(menu)
    local mods = menu:add_tab("武器改装")
    
    -- 最大改装当前武器
    mods:add_button("最大改装当前武器", function()
        local ped = PLAYER.PLAYER_PED_ID()
        local current_weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
        
        if current_weapon ~= 0 then
            -- 获取武器类型
            local weapon_group = WEAPON.GET_WEAPONTYPE_GROUP(current_weapon)
            
            -- 根据武器类型添加特定配件
            local components = {
                -- 手枪配件
                [416676503] = {
                    0xED265A1C, -- 消音器
                    0x359B7AAE, -- 手电筒
                    0x65EA7EBB, -- 扩容弹匣
                    0x359B7AAE, -- 瞄准镜
                },
                -- 冲锋枪配件
                [3337201093] = {
                    0x65EA7EBB, -- 扩容弹匣
                    0x7BC4CDDC, -- 消音器
                    0x359B7AAE, -- 手电筒
                    0x9D2FBF29, -- 瞄准镜
                    0x487AAE09, -- 握把
                },
                -- 步枪配件
                [970310034] = {
                    0x7BC4CDDC, -- 消音器
                    0x359B7AAE, -- 手电筒
                    0x65EA7EBB, -- 扩容弹匣
                    0x9D2FBF29, -- 瞄准镜
                    0x487AAE09, -- 握把
                    0xC164F53,  -- 高级瞄准镜
                    0x1C221B1A, -- 夜视瞄准镜
                    0x8ED4BB70  -- 热成像瞄准镜
                },
                -- 狙击枪配件
                [3082541095] = {
                    0xA73D4664, -- 消音器
                    0x65EA7EBB, -- 扩容弹匣
                    0xC164F53,  -- 高级瞄准镜
                    0x487AAE09, -- 握把
                    0x1C221B1A, -- 夜视瞄准镜
                    0x8ED4BB70  -- 热成像瞄准镜
                },
                -- 霰弹枪配件
                [860033945] = {
                    0x7BC4CDDC, -- 消音器
                    0x359B7AAE, -- 手电筒
                    0x65EA7EBB, -- 扩容弹匣
                    0x9D2FBF29  -- 瞄准镜
                }
            }
            
            -- 应用武器组特定配件
            if components[weapon_group] then
                for _, component in ipairs(components[weapon_group]) do
                    if WEAPON.DOES_WEAPON_TAKE_WEAPON_COMPONENT(current_weapon, component) then
                        WEAPON.GIVE_WEAPON_COMPONENT_TO_PED(ped, current_weapon, component)
                    end
                end
            end
            
            -- 通用强化
            -- 设置武器染色(彩虹色)
            WEAPON.SET_PED_WEAPON_TINT_INDEX(ped, current_weapon, 7)
            
            -- 设置最大弹药
            local _, max_ammo = WEAPON.GET_MAX_AMMO(ped, current_weapon)
            WEAPON.SET_PED_AMMO(ped, current_weapon, max_ammo)
            
            -- 提升武器属性
            WEAPON.SET_WEAPON_DAMAGE_MODIFIER(current_weapon, 2.0)  -- 提升伤害
            PED.SET_PED_ACCURACY(ped, 100)  -- 提升精准度
            
            core.ui.notify("当前武器已完成最大改装")
        else
            core.ui.notify("请先装备一把武器")
        end
    end)
    
    -- 无限弹药
    local infinite_ammo = mods:add_checkbox("无限弹药")
    script.register_looped("InfiniteAmmo", function()
        if infinite_ammo:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            WEAPON.SET_PED_INFINITE_AMMO_CLIP(ped, true)
        end
    end)

    -- 无后坐力
    local no_recoil = mods:add_checkbox("无后坐力")
    script.register_looped("NoRecoil", function()
        if no_recoil:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                WEAPON.SET_WEAPON_DAMAGE_MODIFIER(weapon, 1.0)
                PED.SET_PED_SHOOT_RATE(ped, 1000)
                PLAYER.SET_PLAYER_WEAPON_DEFENSE_MODIFIER(PLAYER.PLAYER_ID(), 0.0)
                PLAYER.SET_PLAYER_WEAPON_DAMAGE_MODIFIER(PLAYER.PLAYER_ID(), 1.0)
            end
        end
    end)

    -- 无扩散
    local no_spread = mods:add_checkbox("无扩散")
    script.register_looped("NoSpread", function()
        if no_spread:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            PED.SET_PED_ACCURACY(ped, 100)
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                WEAPON.SET_PED_CHANCE_OF_FIRING_BLANKS(ped, 0.0)
            end
        end
    end)

    -- 快速换弹
    local fast_reload = mods:add_checkbox("快速换弹")
    script.register_looped("FastReload", function()
        if fast_reload:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if WEAPON.IS_PED_ARMED(ped, 4) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                if weapon ~= 0 then
                    WEAPON.REFILL_AMMO_INSTANTLY(ped)
                end
            end
        end
    end)

    -- 夜视仪和热成像控制
    local vision_mode = 0  -- 0=正常, 1=夜视, 2=热成像
    local night_vision = mods:add_checkbox("夜视仪")
    local thermal_vision = mods:add_checkbox("热成像仪")
    
    script.register_looped("VisionControl", function()
        if night_vision:is_enabled() then
            GRAPHICS.SET_NIGHTVISION(true)
            vision_mode = 1
            thermal_vision:set_enabled(false)
        elseif thermal_vision:is_enabled() then
            GRAPHICS.SET_SEETHROUGH(true)
            vision_mode = 2
            night_vision:set_enabled(false)
        else
            if vision_mode ~= 0 then
                GRAPHICS.SET_NIGHTVISION(false)
                GRAPHICS.SET_SEETHROUGH(false)
                vision_mode = 0
            end
        end
    end)
end

-- 添加武器效果
function weapon.add_weapon_effects(menu)
    local effects = menu:add_tab("武器效果")
    
    -- 爆炸子弹
    local explosive_tab = effects:add_tab("爆炸子弹设置")
    local explosive_rounds = explosive_tab:add_checkbox("启用爆炸子弹")
    local explosion_scale = 10 -- 默认值
    local explosion_scale_text = explosive_tab:add_text("爆炸范围: " .. explosion_scale)
    explosive_tab:add_button("增加范围", function()
        explosion_scale = math.min(explosion_scale + 1, 100)
        explosion_scale_text:set_text("爆炸范围: " .. explosion_scale)
    end)
    explosive_tab:add_button("减少范围", function()
        explosion_scale = math.max(explosion_scale - 1, 1)
        explosion_scale_text:set_text("爆炸范围: " .. explosion_scale)
    end)
    local explosion_invisible = explosive_tab:add_checkbox("隐形爆炸")
    local explosion_audible = explosive_tab:add_checkbox("无声爆炸")
    
    script.register_looped("ExplosiveRounds", function()
        if explosive_rounds:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_SHOOTING(ped) then
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                local raycast = ENTITY.GET_ENTITY_FORWARD_VECTOR(ped)
                local endCoords = {
                    x = pos.x + raycast.x * 1000.0,
                    y = pos.y + raycast.y * 1000.0,
                    z = pos.z + raycast.z * 1000.0
                }
                
                local ray = SHAPETEST.START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(
                    pos.x, pos.y, pos.z,
                    endCoords.x, endCoords.y, endCoords.z,
                    -1,
                    ped,
                    7
                )
                local _, hit, hitCoords = SHAPETEST.GET_SHAPE_TEST_RESULT(ray)
                
                if hit then
                    local scale = explosion_scale / 10
                    FIRE.ADD_EXPLOSION(
                        hitCoords.x, hitCoords.y, hitCoords.z,
                        1, -- 默认使用小型爆炸
                        scale,
                        explosion_audible:is_enabled(),
                        explosion_invisible:is_enabled(),
                        1.0,
                        false
                    )
                end
            end
        end
    end)
    
    -- 燃烧子弹
    local fire_tab = effects:add_tab("燃烧子弹设置")
    local fire_rounds = fire_tab:add_checkbox("启用燃烧子弹")
    local fire_scale = 10 -- 默认值
    local fire_scale_text = fire_tab:add_text("火焰范围: " .. fire_scale)
    fire_tab:add_button("增加范围", function()
        fire_scale = math.min(fire_scale + 1, 100)
        fire_scale_text:set_text("火焰范围: " .. fire_scale)
    end)
    fire_tab:add_button("减少范围", function()
        fire_scale = math.max(fire_scale - 1, 1)
        fire_scale_text:set_text("火焰范围: " .. fire_scale)
    end)
    
    script.register_looped("FireRounds", function()
        if fire_rounds:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_SHOOTING(ped) then
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                local raycast = ENTITY.GET_ENTITY_FORWARD_VECTOR(ped)
                local endCoords = {
                    x = pos.x + raycast.x * 1000.0,
                    y = pos.y + raycast.y * 1000.0,
                    z = pos.z + raycast.z * 1000.0
                }
                
                local ray = SHAPETEST.START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(
                    pos.x, pos.y, pos.z,
                    endCoords.x, endCoords.y, endCoords.z,
                    -1,
                    ped,
                    7
                )
                local _, hit, hitCoords = SHAPETEST.GET_SHAPE_TEST_RESULT(ray)
                
                if hit then
                    local scale = fire_scale / 10
                    FIRE.ADD_EXPLOSION(
                        hitCoords.x, hitCoords.y, hitCoords.z,
                        3, -- 燃烧爆炸
                        scale,
                        true,
                        false,
                        1.0,
                        false
                    )
                    FIRE.START_SCRIPT_FIRE(hitCoords.x, hitCoords.y, hitCoords.z, 25, true)
                end
            end
        end
    end)
    
    -- 电击子弹
    local electric_tab = effects:add_tab("电击子弹设置")
    local electric_rounds = electric_tab:add_checkbox("启用电击子弹")
    local electric_scale = 10 -- 默认值
    local electric_scale_text = electric_tab:add_text("电击范围: " .. electric_scale)
    electric_tab:add_button("增加范围", function()
        electric_scale = math.min(electric_scale + 1, 100)
        electric_scale_text:set_text("电击范围: " .. electric_scale)
    end)
    electric_tab:add_button("减少范围", function()
        electric_scale = math.max(electric_scale - 1, 1)
        electric_scale_text:set_text("电击范围: " .. electric_scale)
    end)
    
    script.register_looped("ElectricRounds", function()
        if electric_rounds:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_SHOOTING(ped) then
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                local raycast = ENTITY.GET_ENTITY_FORWARD_VECTOR(ped)
                local endCoords = {
                    x = pos.x + raycast.x * 1000.0,
                    y = pos.y + raycast.y * 1000.0,
                    z = pos.z + raycast.z * 1000.0
                }
                
                local ray = SHAPETEST.START_EXPENSIVE_SYNCHRONOUS_SHAPE_TEST_LOS_PROBE(
                    pos.x, pos.y, pos.z,
                    endCoords.x, endCoords.y, endCoords.z,
                    -1,
                    ped,
                    7
                )
                local _, hit, hitCoords = SHAPETEST.GET_SHAPE_TEST_RESULT(ray)
                
                if hit then
                    local scale = electric_scale / 10
                    FIRE.ADD_EXPLOSION(
                        hitCoords.x, hitCoords.y, hitCoords.z,
                        83, -- EMP爆炸
                        scale,
                        true,
                        false,
                        1.0,
                        false
                    )
                end
            end
        end
    end)
    
    -- 追踪子弹
    local tracking_tab = effects:add_tab("追踪子弹设置")
    local tracking_rounds = tracking_tab:add_checkbox("启用追踪子弹")
    local tracking_range = 100 -- 默认值
    local tracking_range_text = tracking_tab:add_text("追踪范围: " .. tracking_range)
    tracking_tab:add_button("增加范围", function()
        tracking_range = math.min(tracking_range + 10, 1000)
        tracking_range_text:set_text("追踪范围: " .. tracking_range)
    end)
    tracking_tab:add_button("减少范围", function()
        tracking_range = math.max(tracking_range - 10, 10)
        tracking_range_text:set_text("追踪范围: " .. tracking_range)
    end)
    
    local tracking_speed = 50 -- 默认值
    local tracking_speed_text = tracking_tab:add_text("追踪速度: " .. tracking_speed)
    tracking_tab:add_button("增加速度", function()
        tracking_speed = math.min(tracking_speed + 1, 100)
        tracking_speed_text:set_text("追踪速度: " .. tracking_speed)
    end)
    tracking_tab:add_button("减少速度", function()
        tracking_speed = math.max(tracking_speed - 1, 1)
        tracking_speed_text:set_text("追踪速度: " .. tracking_speed)
    end)
    
    script.register_looped("TrackingRounds", function()
        if tracking_rounds:is_enabled() then
            local ped = PLAYER.PLAYER_PED_ID()
            if PED.IS_PED_SHOOTING(ped) then
                local weapon = WEAPON.GET_SELECTED_PED_WEAPON(ped)
                local pos = ENTITY.GET_ENTITY_COORDS(ped, true)
                local range = tracking_range
                
                -- 获取最近的NPC
                local closest_ped = nil
                local min_dist = range
                
                for _, target in ipairs(entities.get_all_peds_as_handles()) do
                    if ENTITY.DOES_ENTITY_EXIST(target) and target ~= ped and not ENTITY.IS_ENTITY_DEAD(target) then
                        local target_pos = ENTITY.GET_ENTITY_COORDS(target, true)
                        local dist = SYSTEM.VDIST(pos.x, pos.y, pos.z, target_pos.x, target_pos.y, target_pos.z)
                        
                        if dist < min_dist then
                            closest_ped = target
                            min_dist = dist
                        end
                    end
                end
                
                if closest_ped then
                    local target_pos = ENTITY.GET_ENTITY_COORDS(closest_ped, true)
                    MISC.SHOOT_SINGLE_BULLET_BETWEEN_COORDS(
                        pos.x, pos.y, pos.z,
                        target_pos.x, target_pos.y, target_pos.z,
                        200,
                        true,
                        weapon,
                        ped,
                        true,
                        false,
                        tracking_speed * 2.0
                    )
                end
            end
        end
    end)
end

return weapon 