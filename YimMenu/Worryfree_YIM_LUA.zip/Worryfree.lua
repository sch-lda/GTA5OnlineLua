--[[
    脚本名称: Worryfree
    作者: Worryfree
    版本: 1.4
]]

-- 导入模块
local ui = require("worryfree/api/ui")
local ui_effects = require("worryfree/api/ui_effects")
local fun = require("worryfree/api/fun")
local vehicle = require("worryfree/api/vehicle")
local player = require("worryfree/api/player")
local weapon = require("worryfree/api/weapon")

-- 必要的辅助函数
local function MPX()
    local PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 0 then
        return "MP0_"
    else
        return "MP1_"
    end
end

-- 创建主菜单
local Worryfree = gui.get_tab("Worryfree Menu")

-- 初始化变量
local has_played_animation = false

-- 注册动画播放事件
script.register_looped("PlayAnimation", function()
    if not has_played_animation then
        ui.play_injection_animation()
        has_played_animation = true
    end
end)

-- 添加标题和版本信息
Worryfree:add_text("                   Worryfree Menu")
Worryfree:add_text("                      Version 1.4")
Worryfree:add_text("作者: Worryfree")

-- 显示玩家信息
Worryfree:add_text("当前等级: " .. stats.get_int(MPX() .. "CHAR_RANK_FM"))
Worryfree:add_text("当前RP值: " .. stats.get_int(MPX() .. "CHAR_XP_FM"))

-- 创建自我菜单
local Self = Worryfree:add_tab("自我选项")
player.add_basic_abilities(Self)
player.add_appearance_options(Self)
player.add_combat_options(Self)
player.add_super_powers(Self)
player.add_attributes(Self)

-- 创建传送菜单
local Teleport = Worryfree:add_tab("传送选项")
player.add_teleport_options(Teleport)

-- 创建载具菜单
local Vehicle = Worryfree:add_tab("载具选项")
vehicle.add_vehicle_spawner(Vehicle)
vehicle.add_vehicle_mods(Vehicle)
vehicle.add_vehicle_abilities(Vehicle)

-- 创建武器菜单
local Weapon = Worryfree:add_tab("武器选项")
weapon.add_weapon_spawner(Weapon)
weapon.add_weapon_mods(Weapon)
weapon.add_weapon_effects(Weapon)

-- 创建娱乐菜单
local Fun = Worryfree:add_tab("娱乐选项")
local fun_effects = Fun:add_tab("娱乐特效")
fun.add_player_effects(fun_effects)
fun.add_world_effects(fun_effects)
ui_effects.add_ui_effects(Fun)

-- 创建任务菜单
local Mission = Worryfree:add_tab("任务选项")

-- 移除赌场任务冷却
Mission:add_button("移除赌场任务冷却", function()
    stats.set_int(MPX() .. "CASINO_HEIST_COOLDOWN", -1)
end)

-- 移除佩里科岛抢劫冷却
Mission:add_button("移除佩里科岛抢劫冷却", function()
    stats.set_int(MPX() .. "H4_TARGET_POSIX", 0)
    stats.set_int(MPX() .. "H4_COOLDOWN", 0)
end)

-- 添加更多任务功能
Mission:add_button("解锁所有任务", function()
    stats.set_int(MPX() .. "HEIST_PLANNING_STAGE", -1)
    stats.set_int(MPX() .. "HEIST_COMPLETION", 100)
    stats.set_int(MPX() .. "HEIST_STATUS", 3)
end)

-- 一键完成任务准备
Mission:add_button("一键完成任务准备", function()
    stats.set_int(MPX() .. "HEIST_SETUP_DONE", -1)
    stats.set_int(MPX() .. "HEIST_PREP_DONE", -1)
end)

-- 创建在线菜单
local Online = Worryfree:add_tab("在线选项")

-- 添加在线功能
Online:add_button("清除通缉等级", function()
    stats.set_int(MPX() .. "WANTED_LEVEL", 0)
end)

local AntiAFK = Online:add_checkbox("防挂机")
script.register_looped("AntiAFK", function()
    if AntiAFK:is_enabled() then
        STATS.PLAYSTATS_IDLE_KICK(0)
        NETWORK.NETWORK_BAIL(0, 0, 0)
    end
end)

-- 添加新的在线功能
Online:add_button("清除不良记录", function()
    stats.set_int(MPX() .. "BAD_SPORT_BITSET", 0)
    stats.set_float(MPX() .. "PLAYER_MENTAL_STATE", 0.0)
end)

-- 创建恢复菜单
local Recovery = Worryfree:add_tab("恢复选项")

Recovery:add_button("解锁所有研究", function()
    for i = 0, 100 do
        stats.set_bool_masked(MPX() .. "DLCGUNPSTAT_BOOL0", true, i)
        stats.set_bool_masked(MPX() .. "DLCGUNPSTAT_BOOL1", true, i)
        stats.set_bool_masked(MPX() .. "DLCGUNPSTAT_BOOL2", true, i)
        stats.set_bool_masked(MPX() .. "GUNTATPSTAT_BOOL0", true, i)
        stats.set_bool_masked(MPX() .. "GUNTATPSTAT_BOOL1", true, i)
        stats.set_bool_masked(MPX() .. "GUNTATPSTAT_BOOL2", true, i)
    end
end)

Recovery:add_button("解锁所有涂装", function()
    stats.set_int(MPX() .. "CHAR_FM_VEHICLE_1_UNLCK", -1)
    stats.set_int(MPX() .. "CHAR_FM_VEHICLE_2_UNLCK", -1)
end)

Recovery:add_button("解锁所有成就", function()
    for i = 1, 78 do
        stats.set_int(MPX() .. "COMPLETEDAILYOBJ" .. i, 100)
    end
end)

return Worryfree 