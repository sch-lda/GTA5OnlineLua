# menu function
----------------------------------------------------------------------------------------------------
nil        menu.print(any userdata)
nil        menu.notify(any userdata)
number     menu.current_character_slot()
nil        menu.change_session(int value)
nil        menu.call_kosatka()
nil        menu.disable_bounds_death()
bool       menu.localplayer_is_online()
nil        menu.get_crate_ceo(int value)
nil        menu.get_cargo_hangar(int value)
nil        menu.casino_force_slot_transaction()
nil        menu.casion_rig_slot()
nil        menu.casino_select_lucky_wheel_slot(int value)
nil        menu.instant_heist_cut(int value)
nil        menu.apartment_heist_player_cut(int playerid, int value)
nil        menu.doomsday_heist_player_cut(int playerid, int value)
nil        menu.doomsday_heist_force_player_ready()
nil        menu.restart_facility_board()
nil        menu.casino_heist_player_cut(int playerid, int value)
nil        menu.casino_heist_force_player_ready()
nil        menu.cayo_heist_player_cut(int playerid, int value)
nil        menu.cayo_heist_force_player_ready()
nil        menu.restart_kosatka_board()
nil        menu.lscar_mission_localplayer_pay(int value)
nil        menu.dre_mission_localplayer_pay(int value)
nil        menu.instant_mission_team_life(string scriptname, int value)
nil        menu.instant_mission_take(string scriptname, int value)
nil        menu.instant_mission_minigame_passed()
nil        menu.instant_mission_passed(string scriptname, bool cutscene)

# stats function
----------------------------------------------------------------------------------------------------
number     stats.stat_get_int(string statname)
number     stats.stat_get_float(string statname)
bool       stats.stat_get_bool(string statname)
bool       stats.get_packed_stat_bool_code(int index)
number     stats.get_packed_stat_int_code(int index)
nil        stats.stat_set_int(string statname, int value)
nil        stats.stat_set_float(string statname, float value)
nil        stats.stat_set_bool(string statname, bool value)
nil        stats.set_packed_stat_bool_code(int index, bool value)
nil        stats.set_packed_stat_int_code(int index, int value)

# entity function
----------------------------------------------------------------------------------------------------
nil        entity.teleport_to_position(int playerid, v3pos[])

# vehicle function
----------------------------------------------------------------------------------------------------
pointer    vehicle.create_vehicle(string vehiclename, v3pos[], bool mod)

# ped function
----------------------------------------------------------------------------------------------------
pointer    ped.create_ped(int type, string pedname, v3pos[])

# script function
----------------------------------------------------------------------------------------------------
nil        script.start_new_script(string scriptname, int stacksize)