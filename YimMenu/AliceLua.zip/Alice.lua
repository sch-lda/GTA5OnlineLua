pre_load = coroutine.create(function()
	local old_path = package.path
	package.path = package.path:gsub("?.lua", "?._lua")
	require("Alice-Script/main")
	package.path = old_path
end) -- 创建一个lua线程的协程,将在纤程执行后执行...

script.run_in_fiber(function(lua_util)
	repeat
		lua_util:yield()
	until pre_load
	coroutine.resume(pre_load) -- 调用协程一次...
end) -- 纤程将在游戏完全加载后执行...