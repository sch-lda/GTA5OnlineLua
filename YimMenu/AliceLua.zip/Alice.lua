local old_path = package.path
package.path = package.path:gsub("?.lua", "?._lua")
require("Alice-Script/main")
package.path = old_path