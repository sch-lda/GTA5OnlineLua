--require("Alice-Script[Dev]/lib")
require("Alice-Script/lib")
Alice, ini = {}, {}
Alice["Alice"] = gui.add_tab("Alice2333 Lua Script")
Alice["Alice->世界杂项"] = Alice["Alice"]:add_tab("> 世界杂项")
Alice["Alice->资产管理"] = Alice["Alice"]:add_tab("> 资产管理")
Alice["Alice->解锁杂项"] = Alice["Alice"]:add_tab("> 解锁杂项")
Alice["Alice->解锁杂项->线上角色数据"] = Alice["Alice->解锁杂项"]:add_tab(">> 线上角色数据")
Alice["Alice->解锁杂项->DLC解锁"] = Alice["Alice->解锁杂项"]:add_tab(">> DLC解锁")
Alice["Alice->解锁杂项->恶意玩家编辑"] = Alice["Alice->解锁杂项"]:add_tab(">> 恶意玩家编辑")
Alice["Alice->解锁杂项->收支编辑"] = Alice["Alice->解锁杂项"]:add_tab(">> 收支编辑")
Alice["Alice->抢劫任务"] = Alice["Alice"]:add_tab("> 抢劫任务")
Alice["Alice->抢劫任务->公寓抢劫"] = Alice["Alice->抢劫任务"]:add_tab(">> 公寓抢劫")
Alice["Alice->抢劫任务->末日豪劫"] = Alice["Alice->抢劫任务"]:add_tab(">> 末日豪劫")
Alice["Alice->抢劫任务->名钻赌场豪劫"] = Alice["Alice->抢劫任务"]:add_tab(">> 名钻赌场豪劫")
Alice["Alice->抢劫任务->佩里科岛"] = Alice["Alice->抢劫任务"]:add_tab(">> 佩里科岛")
Alice["Alice->抢劫任务->改装铺合约"] = Alice["Alice->抢劫任务"]:add_tab(">> 改装铺合约")
Alice["Alice->抢劫任务->事务所合约"] = Alice["Alice->抢劫任务"]:add_tab(">> 事务所合约")

------------------------------------------------------------------------------------------------ memory offset
memory.entity = {
	["coords"] = {
		["x"] = 0x90, 
		["y"] = 0x94, 
		["z"] = 0x98
	}, 
	["health"] = 0x280, 
	["max_health"] = 0x284, 
}
memory.ped = {
	
}
memory.vehicle = {
	["gravity"] = 0xc3c, 
	["model"] = {
		["extras"] = 0x58b, 
		["hash"] = 0x18
	}
}
memory.weapon = {
	["damage"] = 0x20, 
	["explosion"] = 0x24, 
	["bullets_in_batch"] = 0x120
}

------------------------------------------------------------------------------------------------ local function
local function TP(ped_i, v3pos)
	menu.create_thread(function(util)
		if player.player_is_in_vehicle(ped_i) then
			if not network.network_has_control_of_entity(player.get_player_vehicle(ped_i)) then
				repeat
					network.network_request_control_of_entity(player.get_player_vehicle(ped_i))
					util:yield()
				until network.network_has_control_of_entity(player.get_player_vehicle(ped_i))
			end
			entity.set_entity_coords(player.get_player_vehicle(ped_i), v3pos)
		else
			entity.set_entity_coords(ped_i, v3pos)
		end
	end)
end

------------------------------------------------------------------------------------------------ 世界杂项
Alice["Alice->世界杂项"]:add_text("<战局更改>")

menu.add_feature("离开GTA线上模式", "action", Alice["Alice->世界杂项"], function(util)
	menu.change_session(-1)
end);Alice["Alice->世界杂项"]:add_sameline()

menu.add_feature("仅限邀请的战局", "action", Alice["Alice->世界杂项"], function(util)
	menu.change_session(11)
end);Alice["Alice->世界杂项"]:add_sameline()

ini["快速加入"] = menu.add_feature("快速加入", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	while ini["快速加入"]:is_enabled() do
		if (STREAMING.IS_PLAYER_SWITCH_IN_PROGRESS() and not NETWORK.NETWORK_IS_GAME_IN_PROGRESS()) then
			GRAPHICS.ANIMPOSTFX_STOP_ALL()
			if NETWORK.NETWORK_IS_IN_SESSION() then
				STREAMING.STOP_PLAYER_SWITCH()
				PLAYER.SET_PLAYER_CONTROL(player.player_id(), true, true)
			end
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_separator()

Alice["Alice->世界杂项"]:add_text("<全局玩家>")

ini["全局爆炸玩家"] = menu.add_feature("全局爆炸玩家", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	while ini["全局爆炸玩家"]:is_enabled() do
		for i = 0, 31 do
			if i ~= player.player_id() then
				fire.add_owned_explosion(player.get_player_ped(i), entity.get_entity_coords(player.get_player_ped(i)), 82)
			end
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["事件声音崩溃"] = menu.add_feature("事件声音崩溃 [全局崩溃]", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	while ini["事件声音崩溃"]:is_enabled() do
		for i = 0, 63 do
			audio.play_sound_from_coord(-1, "Event_Message_Purple", entity.get_entity_coords(player.player_ped()), "GTAO_FM_Events_Soundset")
		end
		util:yield()
	end
end, function(util, bool)
	while ini["事件声音崩溃"]:is_enabled() do
		for i = 0, 31 do
			audio.play_sound_from_coord(-1, "Event_Message_Purple", entity.get_entity_coords(player.get_player_ped(i)), "GTAO_FM_Events_Soundset")
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_separator()

Alice["Alice->世界杂项"]:add_text("<传送>")

ini["传送到导航点"] = menu.add_feature("传送到导航点 [不是司机也生效]", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	while ini["传送到导航点"]:is_enabled() do
		if hud.is_waypoint_active() then
			if player.player_is_in_vehicle(player.player_ped()) then
				if not network.network_has_control_of_entity(player.get_player_vehicle(player.player_ped())) then
					repeat
						network.network_request_control_of_entity(player.get_player_vehicle(player.player_ped()))
						util:yield()
					until network.network_has_control_of_entity(player.get_player_vehicle(player.player_ped()))
				end
				command.call("waypointtp", {})
			else
				command.call("waypointtp", {})
			end
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_sameline()

menu.add_feature("传送到目标点", "action", Alice["Alice->世界杂项"], function(util)
	if player.player_is_in_vehicle(player.player_ped()) then
		if not network.network_has_control_of_entity(player.get_player_vehicle(player.player_ped())) then
			repeat
				network.network_request_control_of_entity(player.get_player_vehicle(player.player_ped()))
				util:yield()
			until network.network_has_control_of_entity(player.get_player_vehicle(player.player_ped()))
		end
		command.call("objectivetp", {})
	else
		command.call("objectivetp", {})
	end
end);Alice["Alice->世界杂项"]:add_sameline()

menu.add_feature("将所有玩家传送到我", "action", Alice["Alice->世界杂项"], function(util)
	local pos = entity.get_entity_coords(player.player_ped())
	for i = 0, 31 do
		if i ~= player.player_id() then
			if menu.get_number_to_boolean(player.get_player_ped(i)) then
				if player.player_is_in_vehicle(player.get_player_ped(i)) then
					if not network.network_has_control_of_entity(player.get_player_vehicle(player.get_player_ped(i))) then
						repeat
							network.network_request_control_of_entity(player.get_player_vehicle(player.get_player_ped(i)))
							util:yield()
						until network.network_has_control_of_entity(player.get_player_vehicle(player.get_player_ped(i)))
						menu.notify("正在请求控制实体!", "请求控制 VEHICLE_"..player.get_player_vehicle(player.get_player_ped(i)).." 实体成功!")
					end
					entity.set_entity_coords(player.get_player_vehicle(player.get_player_ped(i)), v3(pos.x, pos.y, pos.z - 100))
				else
					network.set_player_coords(i, pos.x, pos.y, pos.z - 100)
				end
			end
		end
	end
end);Alice["Alice->世界杂项"]:add_separator()

Alice["Alice->世界杂项"]:add_text("<武器>")

ini["增加射击子弹数"] = menu.add_feature("增加射击子弹数", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	local old = {
		["bullets"] = {
			["ptr"] = memory.get_current_weapon():add(memory.weapon.bullets_in_batch)
		}, 
	}
	old.weapon_index = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped())
	old.bullets.value = old.bullets.ptr:get_dword()
	while ini["增加射击子弹数"]:is_enabled() do
		if (memory.get_current_weapon():add(memory.weapon.damage):get_dword() ~= 2) then -- 徒手?
			repeat
				old.bullets.ptr:set_dword(10)
				util:yield()
			until (not ini["增加射击子弹数"]:is_enabled() or (WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped()) ~= old.weapon_index))
			old.bullets.ptr:set_dword(old.bullets.value)
			-- menu.print("callback")
			old.weapon_index = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped())
			old.bullets.ptr = memory.get_current_weapon():add(memory.weapon.bullets_in_batch)
			old.bullets.value = old.bullets.ptr:get_dword()
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["随机效果枪"] = menu.add_feature("随机效果枪", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	local old = {
		["damage"] = {
			["ptr"] = memory.get_current_weapon():add(memory.weapon.damage)
		}, 
		["explosion"] = {
			["ptr"] = memory.get_current_weapon():add(memory.weapon.explosion)
		}
	}
	old.weapon_index = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped())
	old.damage.type = old.damage.ptr:get_dword()
	old.explosion.type = old.explosion.ptr:get_dword()
	while ini["随机效果枪"]:is_enabled() do
		if (memory.get_current_weapon():add(memory.weapon.damage):get_dword() ~= 2) then -- 徒手?
			repeat
				old.damage.ptr:set_dword(5)
				old.explosion.ptr:set_dword(math.random(0, 83))
				util:yield()
			until (not ini["随机效果枪"]:is_enabled() or (WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped()) ~= old.weapon_index))
			old.damage.ptr:set_dword(old.damage.type)
			old.explosion.ptr:set_dword(old.explosion.type)
			-- menu.print("callback")
			old.weapon_index = WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(player.player_ped())
			old.damage.ptr = memory.get_current_weapon():add(memory.weapon.damage)
			old.explosion.ptr = memory.get_current_weapon():add(memory.weapon.explosion)
			old.damage.type = old.damage.ptr:get_dword()
			old.explosion.type = old.explosion.ptr:get_dword()
		end
		util:yield()
	end
end);Alice["Alice->世界杂项"]:add_separator()

Alice["Alice->世界杂项"]:add_text("<载具>")

ini["伪造当前车辆模型"] = menu.add_feature("伪造当前车辆模型", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if player.player_is_in_vehicle(player.player_ped()) then
		if ini["伪造当前车辆模型"]:is_enabled() then
			oldlschash = ENTITY.GET_ENTITY_MODEL(player.player_vehicle())
			memory.get_current_vehicle_model():add(memory.vehicle.model.hash):set_dword(1349725314)
		else
			memory.get_current_vehicle_model():add(memory.vehicle.model.hash):set_dword(oldlschash)
			oldlschash = nil -- 初始化变量,因为是全局变量...
		end
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["移除飞机大炮削弱"] = menu.add_feature("移除战斗机大炮削弱", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	local oldvalue_i, oldvalue_f = plane.get_bullet_type(), plane.get_bullet_speed()
	while ini["移除飞机大炮削弱"]:is_enabled() do
		plane.set_bullet_type(29)
		plane.set_bullet_speed(-1)
		util:yield()
	end
	plane.set_bullet_type(oldvalue_i)
	plane.set_bullet_speed(oldvalue_f)
end);Alice["Alice->世界杂项"]:add_separator()

local jump_flag, rocket_boots_flag, parachute_flag, ramp_flag, deluxo_flag = 0, 0, 0, 0, 0
ini["载具跳跃标志"] = menu.add_feature("载具跳跃标志", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if ini["载具跳跃标志"]:is_enabled() then
		if memory.get_current_vehicle_model():add(memory.vehicle.model.extras):is_valid() then
			jump_flag = 32
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
			repeat util:yield() until not ini["载具跳跃标志"]:is_enabled() or not player.player_is_in_vehicle(player.player_ped())
			ini["载具跳跃标志"]:set_enabled(false)
			jump_flag = 0
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
		end
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["载具喷射标志"] = menu.add_feature("载具喷射标志", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if ini["载具喷射标志"]:is_enabled() then
		if memory.get_current_vehicle_model():add(memory.vehicle.model.extras):is_valid() then
			rocket_boots_flag = 64
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
			repeat util:yield() until not ini["载具喷射标志"]:is_enabled() or not player.player_is_in_vehicle(player.player_ped())
			ini["载具喷射标志"]:set_enabled(false)
			rocket_boots_flag = 0
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
		end
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["载具降落伞标志"] = menu.add_feature("载具降落伞标志", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if ini["载具降落伞标志"]:is_enabled() then
		if memory.get_current_vehicle_model():add(memory.vehicle.model.extras):is_valid() then
			parachute_flag = 256
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
			repeat util:yield() until not ini["载具降落伞标志"]:is_enabled() or not player.player_is_in_vehicle(player.player_ped())
			ini["载具降落伞标志"]:set_enabled(false)
			parachute_flag = 0
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
		end
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["斜面魔宝标志"] = menu.add_feature("斜面魔宝标志", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if ini["斜面魔宝标志"]:is_enabled() then
		if memory.get_current_vehicle_model():add(memory.vehicle.model.extras):is_valid() then
			ramp_flag = 512
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_word(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
			repeat util:yield() until not ini["斜面魔宝标志"]:is_enabled() or not player.player_is_in_vehicle(player.player_ped())
			ini["斜面魔宝标志"]:set_enabled(false)
			ramp_flag = 0
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_word(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
		end
	end
end);Alice["Alice->世界杂项"]:add_sameline()

ini["德罗索轮子标志"] = menu.add_feature("德罗索轮子标志", "toggle", Alice["Alice->世界杂项"], function(util, bool)
	if ini["德罗索轮子标志"]:is_enabled() then
		if memory.get_current_vehicle_model():add(memory.vehicle.model.extras):is_valid() then
			deluxo_flag = 131072
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
			repeat util:yield() until not ini["德罗索轮子标志"]:is_enabled() or not player.player_is_in_vehicle(player.player_ped())
			ini["德罗索轮子标志"]:set_enabled(false)
			deluxo_flag = 0
			memory.get_current_vehicle_model():add(memory.vehicle.model.extras):set_dword(jump_flag + parachute_flag + ramp_flag + rocket_boots_flag + deluxo_flag)
		end
	end
end);Alice["Alice->世界杂项"]:add_separator()

------------------------------------------------------------------------------------------------ 资产选项
Alice["Alice->资产管理"]:add_text("<资产APP>")

menu.add_feature("启动地堡APP", "action", Alice["Alice->资产管理"], function(util)
	script.start_new_script("appBunkerBusiness", 1424)
end);Alice["Alice->资产管理"]:add_sameline()

menu.add_feature("启动恐霸APP", "action", Alice["Alice->资产管理"], function(util)
	script.start_new_script("appHackerTruck", 4592)
end);Alice["Alice->资产管理"]:add_sameline()

menu.add_feature("启动机库APP", "action", Alice["Alice->资产管理"], function(util)
	script.start_new_script("appSmuggler", 4592)
end);Alice["Alice->资产管理"]:add_separator()

Alice["Alice->资产管理"]:add_text("<一键满仓>")

menu.add_feature("CEO板条箱", "action", Alice["Alice->资产管理"], function(util)
	menu.trigger_staff_warehouse_crate(111)
end);Alice["Alice->资产管理"]:add_sameline()

menu.add_feature("机库货物", "action", Alice["Alice->资产管理"], function(util)
	menu.trigger_staff_hangar_cargo(50 - stats.stat_get_int("MPx_HANGAR_CONTRABAND_TOTAL"))
end);Alice["Alice->资产管理"]:add_separator()

Alice["Alice->资产管理"]:add_text("<名钻假日赌场>")

menu.add_feature("幸运轮盘获得奖品载具", "action", Alice["Alice->资产管理"], function(util)
	menu.casino_select_lucky_wheel_slot(18)
end);Alice["Alice->资产管理"]:add_sameline()

ini["老虎机 [100%头彩]"] = menu.add_feature("老虎机 [100%头彩]", "toggle", Alice["Alice->资产管理"], function(util, bool)
	if not ini["老虎机 [100%头彩]"]:is_enabled() then
		menu.casion_rig_slot(bool)
	else
		while ini["老虎机 [100%头彩]"]:is_enabled() do
			menu.casion_rig_slot(bool)
			util:yield()
		end
	end
end);Alice["Alice->资产管理"]:add_sameline()

ini["自动玩老虎机"] = menu.add_feature("自动玩老虎机", "toggle", Alice["Alice->资产管理"], function(util, bool)
	while ini["自动玩老虎机"]:is_enabled() do
		menu.casino_force_slot_transaction()
		util:sleep(100)
	end
end);Alice["Alice->资产管理"]:add_separator()

------------------------------------------------------------------------------------------------ 解锁杂项
Alice["Alice->解锁杂项->线上角色数据"]:add_text("<线上角色数据>")

menu.add_feature("在故事模式中加载线上角色数据", "action", Alice["Alice->解锁杂项->线上角色数据"], function(util)
	stats.stat_load(menu.get_character_index())
	ini["自动云保存"]:set_enabled(true)
end);Alice["Alice->解锁杂项->线上角色数据"]:add_sameline()

ini["自动云保存"] = menu.add_feature("自动云保存", "toggle", Alice["Alice->解锁杂项->线上角色数据"], function(util, bool)
	while ini["自动云保存"]:is_enabled() do
		stats.stat_save()
		util:sleep(10000)
	end
end);Alice["Alice->解锁杂项->线上角色数据"]:add_separator()

Alice["Alice->解锁杂项->DLC解锁"]:add_text("<DLC解锁> 建议在故事模式加载角色数据解锁!")

menu.add_feature("初代DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_before_2016);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("古惑仔跳跳车DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_lowrider);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("炫炮特技DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_cunning_stunts);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("狂野飙客DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_bikers);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("军火霸业DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_gunrunning);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()
menu.add_feature("走私贩大进击DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_smugglers_run);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("末日豪劫DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_the_doomsday_heist);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("不夜城DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_after_hours);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("竞技场之战DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_arena_war);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("名钻假日赌场DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_the_diamond_casino_resort);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()
menu.add_feature("名钻赌场豪劫DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_the_diamond_casino_heist);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("洛圣都夏日特辑DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_los_santos_summer_special);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("佩里科岛DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_the_cayo_perico_heist);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("洛圣都车友会DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_los_santos_tuners);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("合约DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_the_contract);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()
menu.add_feature("阿浩特别工坊DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_gen9);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("犯罪集团DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_criminal_enterprises);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("洛圣都毒品战DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_los_santos_drug_wars);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("圣安地列斯雇佣兵DLC", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_packed_bool_for_san_andreas_mercenaries);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()

Alice["Alice->解锁杂项->DLC解锁"]:add_text("<奖章解锁> 建议在故事模式加载角色数据解锁")

menu.add_feature("胜利奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_victor);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("通用奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_general);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("犯罪奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_crimes);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("载具奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_vehicle);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("作战奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_combat);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()
menu.add_feature("抢劫任务奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_heists);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("不夜城奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_after_hours);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("竞技场奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_arena_war);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("名钻假日赌场奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_the_diamond_casino_resort);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("名钻赌场豪劫奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_the_diamond_casino_heist);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()
menu.add_feature("洛圣都夏日特辑奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_los_santos_summer_special);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("佩里科岛奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_the_cayo_perico_heist);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("洛圣都改装车奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_los_santos_tuners);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("合约奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_the_contract);Alice["Alice->解锁杂项->DLC解锁"]:add_sameline()
menu.add_feature("洛圣都毒品战奖章", "action", Alice["Alice->解锁杂项->DLC解锁"], menu.unlock_stat_awards_for_los_santos_drug_wars);Alice["Alice->解锁杂项->DLC解锁"]:add_separator()


Alice["Alice->解锁杂项->恶意玩家编辑"]:add_text("<恶意玩家编辑>")

menu.add_feature("曾经成为恶意玩家的次数", "auto_input_int", Alice["Alice->解锁杂项->恶意玩家编辑"], function()
	return stats.stat_get_int("mpply_became_badsport_num")
end, function(util, value)
	stats.stat_set_int("mpply_became_badsport_num", value)
end)

menu.add_feature("恶意玩家指数", "auto_input_float", Alice["Alice->解锁杂项->恶意玩家编辑"], function()
	return stats.stat_get_float("mpply_overall_badsport")
end, function(util, value)
	stats.stat_set_float("mpply_overall_badsport", value)
end)

Alice["Alice->解锁杂项->收支编辑"]:add_text("<收支编辑>")

menu.add_feature("总收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpply_total_evc")
end, function(util, value)
	stats.stat_set_int("mpply_total_evc", value)
end)

menu.add_feature("总支出", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpply_total_svc")
end, function(util, value)
	stats.stat_set_int("mpply_total_svc", value)
end)

menu.add_feature("武器和护甲花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_weapon_armor")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_weapon_armor", value)
end)

menu.add_feature("载具和维护花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_veh_maintenance")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_veh_maintenance", value)
end)

menu.add_feature("风格和娱乐花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_style_ent")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_style_ent", value)
end)

menu.add_feature("资产和公用事业花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_property_util")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_property_util", value)
end)

menu.add_feature("差事和公用事业花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_job_activity")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_job_activity", value)
end)

menu.add_feature("联络人服务花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_contact_service")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_contact_service", value)
end)

menu.add_feature("医疗和保释花费", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_healthcare")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_healthcare", value)
end)

menu.add_feature("丢失或被盗现金", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_dropped_stolen")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_dropped_stolen", value)
end)

menu.add_feature("给予他人金额", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_shared")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_shared", value)
end)

menu.add_feature("与他人共享的差事现金金额", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_spent_jobshared")
end, function(util, value)
	stats.stat_set_int("mpx_money_spent_jobshared", value)
end)

menu.add_feature("差事收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_jobs")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_jobs", value)
end)

menu.add_feature("出售载具收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_selling_veh")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_selling_veh", value)
end)

menu.add_feature("赌博收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_betting")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_betting", value)
end)

menu.add_feature("表现良好收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_good_sport")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_good_sport", value)
end)

menu.add_feature("拾取金额收入", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_picked_up")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_picked_up", value)
end)

menu.add_feature("他人给予金额", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_shared")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_shared", value)
end)

menu.add_feature("由他人共享的差事现金金额", "auto_input_int", Alice["Alice->解锁杂项->收支编辑"], function()
	return stats.stat_get_int("mpx_money_earn_jobshared")
end, function(util, value)
	stats.stat_set_int("mpx_money_earn_jobshared", value)
end)

------------------------------------------------------------------------------------------------ 抢劫任务
Alice["Alice->抢劫任务"]:add_text("<任务杂项>")

ini["自动破解任务小游戏"] = menu.add_feature("自动破解任务小游戏", "toggle", Alice["Alice->抢劫任务"], function(util, bool)
	while ini["自动破解任务小游戏"]:is_enabled() do
		menu.instant_mission_minigame_passed()
		util:sleep(100)
	end
end);Alice["Alice->抢劫任务"]:add_sameline()

ini["自动停止过场动画"] = menu.add_feature("自动停止过场动画", "toggle", Alice["Alice->抢劫任务"], function(util, bool)
	while ini["自动停止过场动画"]:is_enabled() do
		if cutscene.is_cutscene_active() or cutscene.is_cutscene_playing() then
			cutscene.stop_cutscene_immediately()
		end
		util:yield()
	end
end);Alice["Alice->抢劫任务"]:add_separator()

------------------------------------------------------------------------------------------------ 公寓抢劫
Alice["Alice->抢劫任务->公寓抢劫"]:add_text("<跳过前置准备任务>")

menu.add_feature("跳过公寓抢劫", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	stats.stat_set_int("mpx_heist_planning_stage", -1)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_separator()

Alice["Alice->抢劫任务->公寓抢劫"]:add_text("<任务控制>")

menu.add_feature("强制玩家准备就绪", "action", Alice["Alice->抢劫任务->公寓抢劫"], menu.apartment_heist_force_player_ready);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller", 999999999)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("自动完成公寓抢劫", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_separator()

Alice["Alice->抢劫任务->公寓抢劫"]:add_text("<奖章挑战>")

menu.add_feature("自动完成全福银行 [奖章挑战]", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_ultimate_award("公寓抢劫", {"全福银行", false})
	menu.set_ultimate_award("公寓抢劫", {"全福银行", true})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("自动完成越狱 [奖章挑战]", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_ultimate_award("公寓抢劫", {"越狱", false})
	menu.set_ultimate_award("公寓抢劫", {"越狱", true})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("自动完成突袭人道实验室 [奖章挑战]", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_ultimate_award("公寓抢劫", {"突袭人道实验室", false})
	menu.set_ultimate_award("公寓抢劫", {"突袭人道实验室", true})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("自动完成首轮募资 [奖章挑战]", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_ultimate_award("公寓抢劫", {"首轮募资", false})
	menu.set_ultimate_award("公寓抢劫", {"首轮募资", true})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_sameline()

menu.add_feature("自动完成太平洋标准银行 [奖章挑战]", "action", Alice["Alice->抢劫任务->公寓抢劫"], function(util)
	menu.set_ultimate_award("公寓抢劫", {"太平洋标准银行", false})
	menu.set_ultimate_award("公寓抢劫", {"太平洋标准银行", true})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->公寓抢劫"]:add_separator()

Alice["Alice->抢劫任务->公寓抢劫"]:add_text("<玩家分红>")

menu.add_feature("本地玩家 [非主持人也生效]", "auto_input_int", Alice["Alice->抢劫任务->公寓抢劫"], function()
	return menu.get_heist_localplayer_cut("apartment")
end, function(util, value)
	menu.set_heist_localplayer_cut("apartment", value)
end)

menu.add_feature("主持玩家", "auto_input_int", Alice["Alice->抢劫任务->公寓抢劫"], function()
	return menu.get_apartment_heist_player_cut(0)
end, function(util, value)
	menu.set_apartment_heist_player_cut(0, value)
end)

menu.add_feature("玩家 2", "auto_input_int", Alice["Alice->抢劫任务->公寓抢劫"], function()
	return menu.get_apartment_heist_player_cut(1)
end, function(util, value)
	menu.set_apartment_heist_player_cut(1, value)
end)

menu.add_feature("玩家 3", "auto_input_int", Alice["Alice->抢劫任务->公寓抢劫"], function()
	return menu.get_apartment_heist_player_cut(2)
end, function(util, value)
	menu.set_apartment_heist_player_cut(2, value)
end)

menu.add_feature("玩家 4", "auto_input_int", Alice["Alice->抢劫任务->公寓抢劫"], function()
	return menu.get_apartment_heist_player_cut(3)
end, function(util, value)
	menu.set_apartment_heist_player_cut(3, value)
end)

------------------------------------------------------------------------------------------------ 末日豪劫
Alice["Alice->抢劫任务->末日豪劫"]:add_text("<跳过前置准备任务>")

menu.add_feature("开启数据泄露", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	stats.stat_set_int("mpx_gangops_heist_status", -229383)
	stats.stat_set_int("mpx_gangops_flow_mission_prog", 65535)
	stats.stat_set_int("mpx_gangops_flow_notifications", 1557)
	menu.restart_facility_board()
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("开启博格丹危机", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	stats.stat_set_int("mpx_gangops_heist_status", -229382)
	stats.stat_set_int("mpx_gangops_flow_mission_prog", 65535)
	stats.stat_set_int("mpx_gangops_flow_notifications", 1557)
	menu.restart_facility_board()
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("开启末日将至", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	stats.stat_set_int("mpx_gangops_heist_status", -229380)
	stats.stat_set_int("mpx_gangops_flow_mission_prog", 65535)
	stats.stat_set_int("mpx_gangops_flow_notifications", 1557)
	menu.restart_facility_board()
end);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

Alice["Alice->抢劫任务->末日豪劫"]:add_text("<设施>")

menu.add_feature("传送到设施策划屏幕", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	TP(player.player_ped(), v3(352.001526, 4873.938965, -61.787357))
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("重启设施策划屏幕", "action", Alice["Alice->抢劫任务->末日豪劫"], menu.restart_facility_board);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

Alice["Alice->抢劫任务->末日豪劫"]:add_text("<任务控制>")

menu.add_feature("强制玩家准备就绪", "action", Alice["Alice->抢劫任务->末日豪劫"], menu.doomsday_heist_force_player_ready);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller", 999999999)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成末日豪劫", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

Alice["Alice->抢劫任务->末日豪劫"]:add_text("<奖章挑战>")

menu.add_feature("自动完成数据泄露 [奖章挑战2]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"数据泄露", false})
	menu.set_ultimate_award("末日豪劫", {"数据泄露", true, 2})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成博格丹危机 [奖章挑战2]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", false})
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", true, 2})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成末日将至 [奖章挑战2]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"末日将至", false})
	menu.set_ultimate_award("末日豪劫", {"末日将至", true, 2})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

menu.add_feature("自动完成数据泄露 [奖章挑战3]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"数据泄露", false})
	menu.set_ultimate_award("末日豪劫", {"数据泄露", true, 3})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成博格丹危机 [奖章挑战3]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", false})
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", true, 3})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成末日将至 [奖章挑战3]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"末日将至", false})
	menu.set_ultimate_award("末日豪劫", {"末日将至", true, 3})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

menu.add_feature("自动完成数据泄露 [奖章挑战4]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"数据泄露", false})
	menu.set_ultimate_award("末日豪劫", {"数据泄露", true, 4})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成博格丹危机 [奖章挑战4]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", false})
	menu.set_ultimate_award("末日豪劫", {"博格丹危机", true, 4})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_sameline()

menu.add_feature("自动完成末日将至 [奖章挑战4]", "action", Alice["Alice->抢劫任务->末日豪劫"], function(util)
	menu.set_ultimate_award("末日豪劫", {"末日将至", false})
	menu.set_ultimate_award("末日豪劫", {"末日将至", true, 4})
	menu.instant_mission_passed("fm_mission_controller", false)
end);Alice["Alice->抢劫任务->末日豪劫"]:add_separator()

Alice["Alice->抢劫任务->末日豪劫"]:add_text("<玩家分红>")

menu.add_feature("本地玩家 [非主持人也生效]", "auto_input_int", Alice["Alice->抢劫任务->末日豪劫"], function()
	return menu.get_heist_localplayer_cut("doomsday")
end, function(util, value)
	menu.set_heist_localplayer_cut("doomsday", value)
end)

menu.add_feature("主持玩家", "auto_input_int", Alice["Alice->抢劫任务->末日豪劫"], function()
	return menu.get_doomsday_heist_player_cut(0)
end, function(util, value)
	menu.set_doomsday_heist_player_cut(0, value)
end)

menu.add_feature("玩家 2", "auto_input_int", Alice["Alice->抢劫任务->末日豪劫"], function()
	return menu.get_doomsday_heist_player_cut(1)
end, function(util, value)
	menu.set_doomsday_heist_player_cut(1, value)
end)

menu.add_feature("玩家 3", "auto_input_int", Alice["Alice->抢劫任务->末日豪劫"], function()
	return menu.get_doomsday_heist_player_cut(2)
end, function(util, value)
	menu.set_doomsday_heist_player_cut(2, value)
end)

menu.add_feature("玩家 4", "auto_input_int", Alice["Alice->抢劫任务->末日豪劫"], function()
	return menu.get_doomsday_heist_player_cut(3)
end, function(util, value)
	menu.set_doomsday_heist_player_cut(3, value)
end)

------------------------------------------------------------------------------------------------ 名钻赌场豪劫
Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_text("<自动配置>")

ini["自动配置名钻赌场豪劫"] = menu.add_feature("自动配置名钻赌场豪劫", "toggle", Alice["Alice->抢劫任务->名钻赌场豪劫"], function(util, bool)
	local h3opt_target, h3opt_crewweap, h3opt_crewdriver, h3opt_weaps, h3opt_vehs, h3opt_disruptship, h3opt_masks = math.random(0, 3), math.random(1, 5), math.random(1, 5), math.random(0, 1), math.random(0, 3), math.random(0, 3), math.random(0, 12)
	while ini["自动配置名钻赌场豪劫"]:is_enabled() do
		if stats.stat_get_int("mpx_cas_heist_flow") < -1610744257 then
			stats.stat_set_int("mpx_cas_heist_flow", -1610744257)
		end
		if stats.stat_get_int("mpx_cas_heist_flow") >= -1610744257 then
			if stats.stat_get_int("mpx_cas_heist_flow") >= -1610743809 then
				if not menu.get_number_to_boolean(menu.get_number_to_binary(stats.stat_get_int("mpx_cas_heist_flow"), 1)) then
					stats.stat_set_int("mpx_cas_heist_flow", -1)
				end
			end
			stats.stat_set_int("mpx_h3opt_accesspoints", 2047)
			stats.stat_set_int("mpx_h3opt_poi", 1023)
			stats.stat_set_int("mpx_h3opt_bitset1", -1)
			stats.stat_set_int("mpx_h3opt_approach", 3)
			stats.stat_set_int("mpx_h3_last_approach", 0)
			stats.stat_set_int("mpx_h3_hard_approach", 3)
			stats.stat_set_int("mpx_h3opt_target", h3opt_target)
			stats.stat_set_int("mpx_h3opt_crewweap", h3opt_crewweap)
			stats.stat_set_int("mpx_h3opt_crewdriver", h3opt_crewdriver)
			stats.stat_set_int("mpx_h3opt_crewhacker", 5)
			stats.stat_set_int("mpx_h3opt_weaps", h3opt_weaps)
			stats.stat_set_int("mpx_h3opt_vehs", h3opt_vehs)
			stats.stat_set_int("mpx_h3opt_keylevels", 2)
			stats.stat_set_int("mpx_h3opt_disruptship", h3opt_disruptship)
			stats.stat_set_int("mpx_h3opt_masks", h3opt_masks)
			stats.stat_set_int("mpx_h3opt_bitset0", -17)
		end
		menu.auto_set_casino_heist_player_cut() -- 自动计算自动分配分红
		if script.script_is_active("timershud") then
			menu.set_instant_mission_take("fm_mission_controller", 10000000)
		end
		util:yield()
	end
end);Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_separator()

Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_text("<任务控制>")

menu.add_feature("强制玩家准备就绪", "action", Alice["Alice->抢劫任务->名钻赌场豪劫"], menu.casino_heist_force_player_ready);Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_sameline()

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->名钻赌场豪劫"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller", 999999999)
end);Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_sameline()

menu.add_feature("自动完成名钻赌场豪劫 [气势汹汹]", "action", Alice["Alice->抢劫任务->名钻赌场豪劫"], function(util)
	menu.instant_mission_passed("fm_mission_controller", true)
end);Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_separator()

menu.add_feature("右下角总收入", "auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_instant_mission_take("fm_mission_controller")
end, function(util, value)
	if script.script_is_active("timershud") then
		menu.set_instant_mission_take("fm_mission_controller", value)
	end
end)

Alice["Alice->抢劫任务->名钻赌场豪劫"]:add_text("<玩家分红>")

menu.add_feature("本地玩家 [非主持人也生效]", "auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_heist_localplayer_cut("casino")
end, function(util, value)
	menu.set_heist_localplayer_cut("casino", value)
end)

menu.add_feature("主持玩家", "auto_auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_casino_heist_player_cut(0)
end, function(util, value)
	menu.set_casino_heist_player_cut(0, value)
end)

menu.add_feature("玩家 2", "auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_casino_heist_player_cut(1)
end, function(util, value)
	menu.set_casino_heist_player_cut(1, value)
end)

menu.add_feature("玩家 3", "auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_casino_heist_player_cut(2)
end, function(util, value)
	menu.set_casino_heist_player_cut(2, value)
end)

menu.add_feature("玩家 4", "auto_input_int", Alice["Alice->抢劫任务->名钻赌场豪劫"], function()
	return menu.get_casino_heist_player_cut(3)
end, function(util, value)
	menu.set_casino_heist_player_cut(3, value)
end)

------------------------------------------------------------------------------------------------ 佩里科岛
Alice["Alice->抢劫任务->佩里科岛"]:add_text("<自动配置>")

ini["自动配置佩里科岛"] = menu.add_feature("自动配置佩里科岛", "toggle", Alice["Alice->抢劫任务->佩里科岛"], function(util, bool)
	menu.restart_kosatka_board()
	local h4_progress, h4cnf_trojan, h4cnf_weapons, h4cnf_target = math.random(0, 1), math.random(1, 5), math.random(1, 5), math.random(0, 5)
	if h4cnf_target == 4 then
		repeat
			h4cnf_target = math.random(0, 5)
		until h4cnf_target ~= 4
	end
	while ini["自动配置佩里科岛"]:is_enabled() do
		if stats.stat_get_int("mpx_h4_playthrough_status") == 0 then
			stats.stat_set_int("mpx_h4_playthrough_status", 1)
		end
		if stats.stat_get_int("mpx_h4_playthrough_status") > 0 then
			if not menu.get_number_to_boolean(h4_progress) then
				stats.stat_set_int("mpx_h4_progress", -4097)
			else
				stats.stat_set_int("mpx_h4_progress", -1)
			end
			stats.stat_set_int("mpx_h4cnf_trojan", h4cnf_trojan)
			stats.stat_set_int("mpx_h4cnf_weapons", h4cnf_weapons)
			stats.stat_set_int("mpx_h4cnf_target", h4cnf_target)
			stats.stat_set_int("mpx_h4cnf_bs_entr", 63)
			stats.stat_set_int("mpx_h4cnf_approach", 65535)
			stats.stat_set_int("mpx_h4cnf_grappel", 5156)
			stats.stat_set_int("mpx_h4cnf_uniform", 5256)
			stats.stat_set_int("mpx_h4cnf_boltcut", 4424)
			stats.stat_set_int("mpx_h4cnf_bs_gen", -1)
			stats.stat_set_int("mpx_h4_missions", 65535)
			stats.stat_set_int("mpx_h4cnf_wep_disrp", 3)
			stats.stat_set_int("mpx_h4cnf_arm_disrp", 3)
			stats.stat_set_int("mpx_h4cnf_hel_disrp", 3)
			stats.stat_set_int("mpx_h4cnf_bs_abil", 63)
			stats.stat_set_int("mpx_h4loot_cash_i_scoped", stats.stat_get_int("mpx_h4loot_cash_i"))
			stats.stat_set_int("mpx_h4loot_cash_c_scoped", stats.stat_get_int("mpx_h4loot_cash_c"))
			stats.stat_set_int("mpx_h4loot_cash_v", stats.stat_get_int("mpx_h4loot_cash_v"))
			stats.stat_set_int("mpx_h4loot_weed_i_scoped", stats.stat_get_int("mpx_h4loot_weed_i"))
			stats.stat_set_int("mpx_h4loot_weed_c_scoped", stats.stat_get_int("mpx_h4loot_weed_c"))
			stats.stat_set_int("mpx_h4loot_weed_v", stats.stat_get_int("mpx_h4loot_weed_v"))
			stats.stat_set_int("mpx_h4loot_coke_i_scoped", stats.stat_get_int("mpx_h4loot_coke_i"))
			stats.stat_set_int("mpx_h4loot_coke_c_scoped", stats.stat_get_int("mpx_h4loot_coke_c"))
			stats.stat_set_int("mpx_h4loot_coke_v", stats.stat_get_int("mpx_h4loot_coke_v"))
			stats.stat_set_int("mpx_h4loot_gold_i_scoped", stats.stat_get_int("mpx_h4loot_gold_i"))
			stats.stat_set_int("mpx_h4loot_gold_c_scoped", stats.stat_get_int("mpx_h4loot_gold_c"))
			stats.stat_set_int("mpx_h4loot_gold_v", stats.stat_get_int("mpx_h4loot_gold_v"))
			stats.stat_set_int("mpx_h4loot_paint_scoped", stats.stat_get_int("mpx_h4loot_paint"))
			stats.stat_set_int("mpx_h4loot_paint_v", stats.stat_get_int("mpx_h4loot_paint_v"))
		end
		menu.auto_set_cayo_heist_player_cut() -- 自动计算自动分配分红
		if script.script_is_active("timershud") then
			menu.set_instant_mission_take("fm_mission_controller_2020", 0)
		end
		util:yield()
	end
end);Alice["Alice->抢劫任务->佩里科岛"]:add_separator()

Alice["Alice->抢劫任务->佩里科岛"]:add_text("<虎鲸>")

menu.add_feature("呼叫虎鲸", "action", Alice["Alice->抢劫任务->佩里科岛"], menu.call_kosatka);Alice["Alice->抢劫任务->佩里科岛"]:add_sameline()

menu.add_feature("传送到虎鲸", "action", Alice["Alice->抢劫任务->佩里科岛"], function(util)
	TP(player.player_ped(), v3(1561.115845, 385.872559, -50.985352))
end);Alice["Alice->抢劫任务->佩里科岛"]:add_sameline()

menu.add_feature("重启虎鲸控制台", "action", Alice["Alice->抢劫任务->佩里科岛"], menu.restart_kosatka_board);Alice["Alice->抢劫任务->佩里科岛"]:add_separator()

Alice["Alice->抢劫任务->佩里科岛"]:add_text("<任务控制>")

menu.add_feature("强制玩家准备就绪", "action", Alice["Alice->抢劫任务->佩里科岛"], menu.cayo_heist_force_player_ready);Alice["Alice->抢劫任务->佩里科岛"]:add_sameline()

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->佩里科岛"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller_2020", 999999999)
end);Alice["Alice->抢劫任务->佩里科岛"]:add_sameline()

menu.add_feature("自动完成佩里科岛", "action", Alice["Alice->抢劫任务->佩里科岛"], function(util)
	menu.instant_mission_passed("fm_mission_controller_2020", true)
end);Alice["Alice->抢劫任务->佩里科岛"]:add_separator()

menu.add_feature("右下角总收入", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_instant_mission_take("fm_mission_controller_2020")
end, function(util, value)
	if script.script_is_active("timershud") then
		menu.set_instant_mission_take("fm_mission_controller_2020", value)
	end
end)

Alice["Alice->抢劫任务->佩里科岛"]:add_text("<玩家分红>")

menu.add_feature("本地玩家 [非主持人也生效]", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_heist_localplayer_cut("cayo")
end, function(util, value)
	menu.set_heist_localplayer_cut("cayo", value)
end)

menu.add_feature("主持玩家", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_cayo_heist_player_cut(0)
end, function(util, value)
	menu.set_cayo_heist_player_cut(0, value)
end)

menu.add_feature("玩家 2", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_cayo_heist_player_cut(1)
end, function(util, value)
	menu.set_cayo_heist_player_cut(1, value)
end)

menu.add_feature("玩家 3", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_cayo_heist_player_cut(2)
end, function(util, value)
	menu.set_cayo_heist_player_cut(2, value)
end)

menu.add_feature("玩家 4", "auto_input_int", Alice["Alice->抢劫任务->佩里科岛"], function()
	return menu.get_cayo_heist_player_cut(3)
end, function(util, value)
	menu.set_cayo_heist_player_cut(3, value)
end)

------------------------------------------------------------------------------------------------ 改装铺合约
Alice["Alice->抢劫任务->改装铺合约"]:add_text("<跳过前置准备任务>")

menu.add_feature("开启联合储蓄", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 0)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启大钞交易", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 1)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启银行合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 2)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启电控单元", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 3)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启监狱合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 4)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启IAA合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 5)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启失落摩托帮合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 6)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("开启数据合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	stats.stat_set_int("mpx_tuner_current", 7)
	stats.stat_set_int("mpx_tuner_gen_bs", 65535)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_separator()

Alice["Alice->抢劫任务->改装铺合约"]:add_text("<任务控制>")

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller_2020", 999999999)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_sameline()

menu.add_feature("自动完成改装铺合约", "action", Alice["Alice->抢劫任务->改装铺合约"], function(util)
	menu.instant_mission_passed("fm_mission_controller_2020", false)
end);Alice["Alice->抢劫任务->改装铺合约"]:add_separator()

Alice["Alice->抢劫任务->改装铺合约"]:add_text("<任务报酬>")

menu.add_feature("联合储蓄", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x30")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x30", value)
end)

menu.add_feature("大钞交易", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x31")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x31", value)
end)

menu.add_feature("银行合约", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x32")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x32", value)
end)

menu.add_feature("电控单元", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x33")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x33", value)
end)

menu.add_feature("监狱合约", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x34")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x34", value)
end)

menu.add_feature("IAA合约", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x35")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x35", value)
end)

menu.add_feature("失落摩托帮合约", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x36")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x36", value)
end)

menu.add_feature("数据合约", "auto_input_int", Alice["Alice->抢劫任务->改装铺合约"], function()
	return tunables.get_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x37")
end, function(util, value)
	tunables.set_int("\x54\x55\x4E\x45\x52\x5F\x52\x4F\x42\x42\x45\x52\x59\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44\x37", value)
end)

------------------------------------------------------------------------------------------------ 事务所合约
Alice["Alice->抢劫任务->事务所合约"]:add_text("<跳过前置准备任务>")

menu.add_feature("开启别惹德瑞", "action", Alice["Alice->抢劫任务->事务所合约"], function(util)
	stats.stat_set_int("mpx_fixer_general_bs", -1)
	stats.stat_set_int("mpx_fixer_story_bs", 4095)
end);Alice["Alice->抢劫任务->事务所合约"]:add_separator()

Alice["Alice->抢劫任务->事务所合约"]:add_text("<任务控制>")

menu.add_feature("无限团队生命数", "action", Alice["Alice->抢劫任务->事务所合约"], function(util)
	menu.set_instant_mission_team_life("fm_mission_controller_2020", 999999999)
end);Alice["Alice->抢劫任务->事务所合约"]:add_sameline()

menu.add_feature("自动完成事务所合约", "action", Alice["Alice->抢劫任务->事务所合约"], function(util)
	menu.instant_mission_passed("fm_mission_controller_2020", false)
end);Alice["Alice->抢劫任务->事务所合约"]:add_separator()

Alice["Alice->抢劫任务->事务所合约"]:add_text("<任务报酬>")

menu.add_feature("别惹德瑞", "auto_input_int", Alice["Alice->抢劫任务->事务所合约"], function()
	return tunables.get_int("\x46\x49\x58\x45\x52\x5F\x46\x49\x4E\x41\x4C\x45\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44")
end, function(util, value)
	tunables.set_int("\x46\x49\x58\x45\x52\x5F\x46\x49\x4E\x41\x4C\x45\x5F\x4C\x45\x41\x44\x45\x52\x5F\x43\x41\x53\x48\x5F\x52\x45\x57\x41\x52\x44", value)
end)

------------------------------------------------------------------------------------------------ 循环线程
script.register_looped("OnScriptLoaded", function(util)
	menu.disable_bounds_death() -- 禁用越界死亡
	menu.show_all_vehicles(true)
	util:yield()
end)

ini["爆炸玩家"] = menu.add_feature("爆炸玩家", "toggle", gui.get_tab(""), function(util, bool)
	local oldplayer_name = player.get_player_name(network.get_selected_player())
	while ini["爆炸玩家"]:is_enabled() do
		if (player.get_player_name(network.get_selected_player()) == oldplayer_name) then
			if menu.get_number_to_boolean(player.get_player_ped(network.get_selected_player())) then
				for i = 0, 31 do
					if network.get_selected_player() ~= player.player_id() then
						fire.add_owned_explosion(player.get_player_ped(network.get_selected_player()), entity.get_entity_coords(player.get_player_ped(network.get_selected_player())), 82)
					end
				end
			end
		else
			ini["爆炸玩家"]:set_enabled(false)
		end
		util:yield()
	end
end);gui.get_tab(""):add_sameline()

ini["颠倒玩家"] = menu.add_feature("颠倒玩家", "toggle", gui.get_tab(""), function(util, bool)
	local oldplayer_name = player.get_player_name(network.get_selected_player())
	while ini["颠倒玩家"]:is_enabled() do
		if (player.get_player_name(network.get_selected_player()) == oldplayer_name) then
			if menu.get_number_to_boolean(player.get_player_ped(network.get_selected_player())) then
				for i = 0, 31 do
					for key, value in pairs(memory.replayinterface_vehicles()) do
						value:add(memory.entity.coords.x):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).x)
						value:add(memory.entity.coords.y):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).y)
						value:add(memory.entity.coords.z):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).z - 1)
						value:add(memory.entity.max_health):set_float(-1)
						value:add(memory.entity.health):set_float(-1)
						value:add(memory.vehicle.gravity):set_float(-100000)
					end
					util:sleep(100)
				end
				for i = 0, 31 do
					for key, value in pairs(memory.replayinterface_vehicles()) do
						value:add(memory.entity.coords.x):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).x)
						value:add(memory.entity.coords.y):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).y)
						value:add(memory.entity.coords.z):set_float(entity.get_entity_coords(player.get_player_ped(network.get_selected_player())).z + 1)
						value:add(memory.entity.max_health):set_float(-1)
						value:add(memory.entity.health):set_float(-1)
						value:add(memory.vehicle.gravity):set_float(100000)
					end
					util:sleep(100)
				end
			end
		else
			ini["颠倒玩家"]:set_enabled(false)
		end
		util:yield()
	end
end)