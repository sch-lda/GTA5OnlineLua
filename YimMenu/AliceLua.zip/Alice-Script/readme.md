# vector function
----------------------------------------------------------------------------------------------------
table                v2(float x，float y)
table                v2(userdata)
table                v3(float x，float y, float z)
table                v3(userdata)

# memory function
----------------------------------------------------------------------------------------------------
pointer              memory.get_current_ped()
pointer              memory.get_player_info(int playerid)
pointer              memory.get_current_vehicle()
pointer              memory.get_current_vehicle_model()
pointer              memory.get_current_weapon()
table                memory.replayinterface_peds()
table                memory.replayinterface_pickups()
table                memory.replayinterface_objects()
table                memory.replayinterface_vehicles()

# audio function
----------------------------------------------------------------------------------------------------
nil                  audio.play_sound_from_coord(int soundid, string audioname, v3pos[], string audioref)

# cutscene function
----------------------------------------------------------------------------------------------------
bool                 cutscene.is_active()
bool                 cutscene.is_playing()
nil                  cutscene.remove()
nil                  cutscene.stop_immediately()

# entity function
----------------------------------------------------------------------------------------------------
bool                 entity.does_exist(int entity)
vector3              entity.get_coords(int entity)
nil                  entity.set_coords(int entity, v3pos[])
number               entity.get_heading(int entity)
nil                  entity.set_heading(int entity, float heading)
nil                  entity.delete(int entity)
nil                  entity.freeze_position(int entity, bool value)
number               entity.get_model(int entity)

# fire function
----------------------------------------------------------------------------------------------------
nil                  fire.add_owned_explosion(int ped, v3pos[], int explosiontype)

# hud function
----------------------------------------------------------------------------------------------------
nil                  hud.add_draw_text(string text, v2pos[], float textsize)
bool                 hud.is_waypoint_active()

# misc function
----------------------------------------------------------------------------------------------------
number               misc.get_hash_key(string hash)

# money function
----------------------------------------------------------------------------------------------------
number               money.get_wallet_balance()
number               money.get_bank_balance()

# netshopping function
----------------------------------------------------------------------------------------------------
number               netshopping.transfer_wallet_to_bank(int value)
number               netshopping.transfer_bank_to_wallet(int value)

# network function
----------------------------------------------------------------------------------------------------
number               network.get_host_of_this_session()
bool                 network.is_host_of_this_session()
number               network.get_host_of_this_script(string scriptname, int instanceid)
bool                 network.is_host_of_this_script(string scriptname, int instanceid)
nil                  network.request_control_of_entity(int entity)
bool                 network.has_control_of_entity(int entity)
nil|only host        network.session_kick_player(int playerid)

# object function
----------------------------------------------------------------------------------------------------
handler              object.create_object(string objecename, v3pos[], bool dynamic)
handler              object.create_object(int objecehash, v3pos[], bool dynamic)

# ped function
----------------------------------------------------------------------------------------------------
handler              ped.create_ped(int type, string pedname, v3pos[])
handler              ped.create_ped(int type, int pedhash, v3pos[])
bool                 ped.get_config_flag(int ped, int flagid)
nil                  ped.set_config_flag(int ped, int flagid, bool value)
bool                 ped.get_reset_flag(int ped, int flagid)
nil                  ped.set_reset_flag(int ped, int flagid, bool value)


# player function
----------------------------------------------------------------------------------------------------
number               player.get_number_of_players()
number               player.player_id()
string               player.get_player_name(int playerid)
number               player.get_player_ped(int ped)
number               player.player_ped()
bool                 player.is_in_vehicle(int ped)
handler              player.get_player_vehicle(int ped)
handler              player.player_vehicle()
number               player.get_player_rockstar_id(int playerid)
nil                  player.set_model(int ped, string modelname)
nil                  player.set_model(int ped, int modelhash)
number               player.get_wanted_level(int playerid)
number               player.set_wanted_level(int playerid, int wantedlevel)
bool                 player.is_godmode(int playerid)

# script function
----------------------------------------------------------------------------------------------------
bool                 script.start_new_script(string scriptname, int stacksize)
bool                 script.start_new_script(int scripthash, int stacksize)
bool                 script.is_active(string scriptname)
bool                 script.is_active(int scripthash)

# stats function
----------------------------------------------------------------------------------------------------
nil                  stats.stat_load(int character)
nil                  stats.stat_save()
number               stats.stat_get_int(string statname)
number               stats.stat_get_int(int stathash)
number               stats.stat_get_float(string statname)
number               stats.stat_get_float(int stathash)
bool                 stats.stat_get_bool(string statname)
bool                 stats.stat_get_bool(int stathash)
string               stats.stat_get_string(string statname)
string               stats.stat_get_string(int stathash)
string               stats.stat_get_user_id(string statname)
string               stats.stat_get_user_id(int stathash)
bool                 stats.get_packed_stat_bool_code(int index)
number               stats.get_packed_stat_int_code(int index)
nil                  stats.stat_set_int(string statname, int value)
nil                  stats.stat_set_int(int stathash, int value)
nil                  stats.stat_set_float(string statname, float value)
nil                  stats.stat_set_float(int stathash, float value)
nil                  stats.stat_set_bool(string statname, bool value)
nil                  stats.stat_set_bool(int stathash, bool value)
nil                  stats.stat_set_string(string statname, string value)
nil                  stats.stat_set_string(int stathash, string value)
nil                  stats.stat_set_user_id(string statname, string value)
nil                  stats.stat_set_user_id(int stathash, string value)
nil                  stats.set_packed_stat_bool_code(int index, bool value)
nil                  stats.set_packed_stat_int_code(int index, int value)

# streaming function
----------------------------------------------------------------------------------------------------
nil                  streaming.request_model(string modelname)
nil                  streaming.request_model(int modelhash)
nil                  streaming.has_model_loaded(string modelname)
nil                  streaming.has_model_loaded(int modelhash)
nil                  streaming.set_model_as_no_longer_needed(string modelname)
nil                  streaming.set_model_as_no_longer_needed(int modelhash)

# vehicle function
----------------------------------------------------------------------------------------------------
handler              vehicle.create_vehicle(string vehiclename, v3pos[], bool mod)
handler              vehicle.create_vehicle(int vehiclehash, v3pos[], bool mod)

# weapon function
----------------------------------------------------------------------------------------------------
handler              weapon.get_ped_weapon_entity(int ped)
nil                  weapon.remove_ped_all_weapons(int ped)
nil                  weapon.remove_ped_weapon(int ped, int hash)
nil                  weapon.remove_ped_weapon(int ped, string weapon)

# zone function
----------------------------------------------------------------------------------------------------
string               zone.get_name_of_zone(v3pos[])

# plane function
----------------------------------------------------------------------------------------------------
number               plane.get_bullet_type()
number               plane.get_bullet_speed()
nil                  plane.set_bullet_type(int value)
nil                  plane.set_bullet_speed(int value)

# tuneables function
----------------------------------------------------------------------------------------------------
bool                 tuneables.get_bool(int hash, int offset)
number               tuneables.get_int(int hash, int offset)
number               tuneables.get_float(int hash, int offset)
bool                 tuneables.get_bool(string hash, int offset)
number               tuneables.get_int(string hash, int offset)
number               tuneables.get_float(string hash, int offset)
nil                  tuneables.set_bool(int hash, int value, int offset)
nil                  tuneables.set_int(int hash, int value, int offset)
nil                  tuneables.set_float(int hash, int value, int offset)
nil                  tuneables.set_bool(string hash, int value, int offset)
nil                  tuneables.set_int(string hash, int value, int offset)
nil                  tuneables.set_float(string hash, int value, int offset)

# menu function
----------------------------------------------------------------------------------------------------
nil                  menu.print(any data, ...)
nil                  menu.notify(string title, string message, string type)
bool                 menu.get_number_is_bit(int value, int bit)
number               menu.set_number_to_bit(int value, int bit, bool bitset)
string               menu.get_number_to_binary(int value)
number               menu.get_binary_to_number(string binary)
bool                 menu.get_number_to_boolean(int value)
number               menu.get_boolean_to_number(bool value)
nil                  menu.create_thread(arg)
handler, handler     menu.add_feature(string name, string menutype, handler tab, arg, ...)
number               menu.get_character_index()
nil                  menu.change_session(int value)
nil                  menu.call_kosatka()
nil                  menu.disable_bounds_death()
bool                 menu.localplayer_is_in_online_session()
nil                  menu.trigger_purchase_supplies(int prop_id)
nil                  menu.trigger_production(string prop) //{ biker, bunker, acid_lab }
nil                  menu.trigger_staff_warehouse_crate(int value)
nil                  menu.trigger_staff_hangar_cargo(int value)
nil                  menu.casino_force_slot_transaction()
nil                  menu.casion_rig_slot(bool value)
nil                  menu.casino_select_lucky_wheel_slot(int value)
nil                  menu.remove_cctvs()
nil                  menu.set_heist_localplayer_cut(string heistname, int value)
number               menu.get_heist_localplayer_cut(string heistname)
nil                  menu.set_apartment_heist_player_cut(int playerid, int value)
number               menu.get_apartment_heist_player_cut(int playerid)
nil                  menu.apartment_heist_force_player_ready()
nil                  menu.set_doomsday_heist_player_cut(int playerid, int value)
number               menu.get_doomsday_heist_player_cut(int playerid)
nil                  menu.doomsday_heist_force_player_ready()
nil                  menu.restart_facility_board()
nil                  menu.auto_set_casino_heist_player_cut()
nil                  menu.set_casino_heist_player_cut(int playerid, int value)
number               menu.get_casino_heist_player_cut(int playerid)
nil                  menu.casino_heist_force_player_ready()
nil                  menu.auto_set_cayo_heist_player_cut()
nil                  menu.set_cayo_heist_player_cut(int playerid, int value)
number               menu.get_cayo_heist_player_cut(int playerid)
nil                  menu.cayo_heist_force_player_ready()
nil                  menu.restart_kosatka_board()
nil                  menu.set_instant_mission_team_life(string scriptname, int value)
number               menu.get_instant_mission_team_life(string scriptname)
nil                  menu.set_instant_mission_take(string scriptname, int value)
number               menu.get_instant_mission_take(string scriptname)
nil                  menu.instant_mission_minigame_passed()
nil                  menu.instant_mission_passed(string scriptname, bool cutscene)
nil                  menu.anti_crash_cam(bool value)
nil                  menu.vehicle_mod_crash(int player)
nil                  menu.vehicle_task_crash(int player)
nil                  menu.object_fragment_crash(int player)
nil                  menu.memory_crash(int player)
nil                  menu.null_crash(int player)
nil                  menu.show_all_vehicles(bool value)