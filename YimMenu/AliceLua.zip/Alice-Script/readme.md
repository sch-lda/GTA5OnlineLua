# vector function
----------------------------------------------------------------------------------------------------
table                v2(float x，float y)
table                v2(userdata)
table                v3(float x，float y, float z)
table                v3(userdata)

# memory function
----------------------------------------------------------------------------------------------------
pointer              memory.get_current_ped()
pointer              memory.get_current_vehicle()
pointer              memory.get_current_vehicle_model()
pointer              memory.get_current_weapon()
pointer              memory.get_current_vehicle_weapon()
pointer              memory.replayinterface_vehicles()
pointer              memory.replayinterface_peds()
pointer              memory.replayinterface_pickups()

# audio function
----------------------------------------------------------------------------------------------------
nil                  audio.play_sound_from_coord(int soundid, string audioname, v3pos[], string audioref)

# cutscene function
----------------------------------------------------------------------------------------------------
bool                 cutscene.is_cutscene_active()
bool                 cutscene.is_cutscene_playing()
nil                  cutscene.remove_cutscene()
nil                  cutscene.stop_cutscene_immediately()

# entity function
----------------------------------------------------------------------------------------------------
vector3              entity.get_entity_coords(int entity)
nil                  entity.set_entity_coords(int entity, v3pos[])
number               entity.get_entity_heading(int entity)
nil                  entity.set_entity_heading(int entity, float heading)
nil                  entity.delete_entity(int entity)

# fire function
----------------------------------------------------------------------------------------------------
nil                  fire.add_owned_explosion(int pedid, v3pos[], int explosiontype)

# hud function
----------------------------------------------------------------------------------------------------
nil                  hud.add_draw_text(string text, v2pos[], float textsize)
bool                 hud.is_waypoint_active()

# misc function
----------------------------------------------------------------------------------------------------
number               misc.get_hash_key(string hash)

# network function
----------------------------------------------------------------------------------------------------
nil|only freemode    network.network_request_to_be_host_of_this_script()
number               network.network_get_host_of_this_script(string scriptname)
bool                 network.network_is_host_of_this_script(string scriptname)
nil                  network.network_request_control_of_entity(int entity)
bool                 network.network_has_control_of_entity(int entity)
number               network.network_get_host_player_id()
bool                 network.network_is_host()
nil                  network.network_session_kick_player(int playerid)

# object function
----------------------------------------------------------------------------------------------------
handler              object.create_object(string objecename, v3pos[], bool dynamic)
handler              object.create_object(int objecehash, v3pos[], bool dynamic)

# ped function
----------------------------------------------------------------------------------------------------
handler              ped.create_ped(int type, string pedname, v3pos[])
handler              ped.create_ped(int type, int pedhash, v3pos[])
bool                 ped.get_ped_config_flag(int pedid, int flagid)
nil                  ped.set_ped_config_flag(int pedid, int flagid, bool value)
bool                 ped.get_ped_reset_flag(int pedid, int flagid)
nil                  ped.set_ped_reset_flag(int pedid, int flagid, bool value)


# player function
----------------------------------------------------------------------------------------------------
number               player.get_number_of_players()
number               player.player_id()
string               player.get_player_name(int playerid)
number               player.get_player_ped(int pedid)
number               player.player_ped()
bool                 player.player_is_in_vehicle(int pedid)
handler              player.get_player_vehicle(int pedid)
handler              player.player_vehicle()
nil                  player.set_player_model(int pedid, string modelname)
nil                  player.set_player_model(int pedid, int modelhash)
number               player.get_player_wanted_level(int playerid)
number               player.set_player_wanted_level(int playerid, int wantedlevel)
bool                 player.get_player_is_godmode(int playerid)

# script function
----------------------------------------------------------------------------------------------------
bool                 script.start_new_script(string scriptname, int stacksize)
bool                 script.start_new_script(int scripthash, int stacksize)
bool                 script.script_is_active(string scriptname)
bool                 script.script_is_active(int scripthash)

# stats function
----------------------------------------------------------------------------------------------------
nil                  stats.stat_clear_slot_for_reload(int character)
nil                  stats.stat_load(int character)
nil                  stats.stat_save()
number               stats.stat_get_int(string statname)
number               stats.stat_get_int(int stathash)
number               stats.stat_get_float(string statname)
number               stats.stat_get_float(int stathash)
bool                 stats.stat_get_bool(string statname)
bool                 stats.stat_get_bool(int stathash)
bool                 stats.get_packed_stat_bool_code(int index)
number               stats.get_packed_stat_int_code(int index)
nil                  stats.stat_set_int(string statname, int value)
nil                  stats.stat_set_int(int stathash, int value)
nil                  stats.stat_set_float(string statname, float value)
nil                  stats.stat_set_float(int stathash, float value)
nil                  stats.stat_set_bool(string statname, bool value)
nil                  stats.stat_set_bool(int stathash, bool value)
nil                  stats.set_packed_stat_bool_code(int index, bool value)
nil                  stats.set_packed_stat_int_code(int index, int value)

# streaming function
----------------------------------------------------------------------------------------------------
nil                  streaming.request_model(string modelname)
nil                  streaming.request_model(int modelhash)

# vehicle function
----------------------------------------------------------------------------------------------------
handler              vehicle.create_vehicle(string vehiclename, v3pos[], bool mod)
handler              vehicle.create_vehicle(int vehiclehash, v3pos[], bool mod)

# zone function
----------------------------------------------------------------------------------------------------
string               zone.get_name_of_zone(v3pos[])

# plane function
----------------------------------------------------------------------------------------------------
number               plane.get_bullet_type()
number               plane.get_bullet_speed()
nil                  plane.set_bullet_type(int value)
nil                  plane.set_bullet_speed(int value)

# tuneables function
----------------------------------------------------------------------------------------------------
bool                 tuneables.get_bool(int hash, int offset)
number               tuneables.get_int(int hash, int offset)
number               tuneables.get_float(int hash, int offset)
bool                 tuneables.get_bool(string hash, int offset)
number               tuneables.get_int(string hash, int offset)
number               tuneables.get_float(string hash, int offset)
nil                  tuneables.set_bool(int hash, int value, int offset)
nil                  tuneables.set_int(int hash, int value, int offset)
nil                  tuneables.set_float(int hash, int value, int offset)
nil                  tuneables.set_bool(string hash, int value, int offset)
nil                  tuneables.set_int(string hash, int value, int offset)
nil                  tuneables.set_float(string hash, int value, int offset)

# menu function
----------------------------------------------------------------------------------------------------
nil                  menu.print(any data, ...)
nil                  menu.notify(string title, string message, string type)
number               menu.get_number_to_binary(int value, int bit)
bool                 menu.get_number_to_boolean(int value)
nil                  menu.create_thread(arg)
handler, handler     menu.add_feature(string name, string menutype, handler tab, arg, ...)
number               menu.get_character_index()
nil                  menu.change_session(int value)
nil                  menu.call_kosatka()
nil                  menu.disable_bounds_death()
bool                 menu.localplayer_is_in_online_session()
nil                  menu.trigger_staff_warehouse_crate(int value)
nil                  menu.trigger_staff_hangar_cargo(int value)
nil                  menu.casino_force_slot_transaction()
nil                  menu.casion_rig_slot(bool value)
nil                  menu.casino_select_lucky_wheel_slot(int value)
nil                  menu.set_heist_localplayer_cut(string heistname, int value)
number               menu.get_heist_localplayer_cut(string heistname)
nil                  menu.set_apartment_heist_player_cut(int playerid, int value)
number               menu.get_apartment_heist_player_cut(int playerid)
nil                  menu.apartment_heist_force_player_ready()
nil                  menu.set_doomsday_heist_player_cut(int playerid, int value)
number               menu.get_doomsday_heist_player_cut(int playerid)
nil                  menu.doomsday_heist_force_player_ready()
nil                  menu.restart_facility_board()
nil                  menu.auto_set_casino_heist_player_cut()
nil                  menu.set_casino_heist_player_cut(int playerid, int value)
number               menu.get_casino_heist_player_cut(int playerid)
nil                  menu.casino_heist_force_player_ready()
nil                  menu.auto_set_cayo_heist_player_cut()
nil                  menu.set_cayo_heist_player_cut(int playerid, int value)
number               menu.get_cayo_heist_player_cut(int playerid)
nil                  menu.cayo_heist_force_player_ready()
nil                  menu.restart_kosatka_board()
nil                  menu.set_instant_mission_team_life(string scriptname, int value)
number               menu.get_instant_mission_team_life(string scriptname)
nil                  menu.set_instant_mission_take(string scriptname, int value)
number               menu.get_instant_mission_take(string scriptname)
nil                  menu.instant_mission_minigame_passed()
nil                  menu.instant_mission_passed(string scriptname, bool cutscene)
nil                  menu.show_all_vehicles(bool value)
nil                  menu.unlock_stat_awards_for_victor()
nil                  menu.unlock_stat_awards_for_general()
nil                  menu.unlock_stat_awards_for_crimes()
nil                  menu.unlock_stat_awards_for_vehicle()
nil                  menu.unlock_stat_awards_for_combat()
nil                  menu.unlock_stat_awards_for_heists()
nil                  menu.unlock_stat_awards_for_after_hours()
nil                  menu.unlock_stat_packed_bool_for_after_hours()
nil                  menu.unlock_stat_awards_for_arena_war()
nil                  menu.unlock_stat_packed_bool_for_arena_war()
nil                  menu.unlock_stat_awards_for_the_diamond_casino_resort()
nil                  menu.unlock_stat_packed_bool_for_the_diamond_casino_resort()
nil                  menu.unlock_stat_awards_for_the_diamond_casino_heist()
nil                  menu.unlock_stat_packed_bool_for_the_diamond_casino_heist()
nil                  menu.unlock_stat_awards_for_los_santos_summer_special()
nil                  menu.unlock_stat_packed_bool_for_los_santos_summer_special()
nil                  menu.unlock_stat_awards_for_the_cayo_perico_heist()
nil                  menu.unlock_stat_packed_bool_for_the_cayo_perico_heist()
nil                  menu.unlock_stat_awards_for_los_santos_tuners()
nil                  menu.unlock_stat_packed_bool_for_los_santos_tuners()
nil                  menu.unlock_stat_awards_for_the_contract()
nil                  menu.unlock_stat_packed_bool_for_the_contract()
nil                  menu.unlock_stat_awards_for_los_santos_drug_wars()
nil                  menu.unlock_stat_packed_bool_for_los_santos_drug_wars()
nil                  menu.unlock_stat_packed_bool_for_before_2016()
nil                  menu.unlock_stat_packed_bool_for_lowrider()
nil                  menu.unlock_stat_packed_bool_for_cunning_stunts()
nil                  menu.unlock_stat_packed_bool_for_bikers()
nil                  menu.unlock_stat_packed_bool_for_gunrunning()
nil                  menu.unlock_stat_packed_bool_for_smugglers_run()
nil                  menu.unlock_stat_packed_bool_for_the_doomsday_heist()
nil                  menu.unlock_stat_packed_bool_for_gen9()
nil                  menu.unlock_stat_packed_bool_for_criminal_enterprises()
nil                  menu.unlock_stat_packed_bool_for_san_andreas_mercenaries()