# base function
----------------------------------------------------------------------------------------------------
`hash`          joaat(`string value`)

`vector2`       v2(`float x，float y`)
`vector2`       v2(`userdata`)

`vector3`       v3(`float x，float y, float z`)
`vector3`       v3(`userdata`)

# util function
----------------------------------------------------------------------------------------------------
`string`        util.string_to_byte(`string value`)

`bool`          util.number_to_boolean(`int value`)

`number`        util.boolean_to_number(`bool value`)

`number`        util.number_to_binary(`int value`)

`this`          util.get_number(`int value`)
`bool`          this:get_bit(`int bit`)
`nil`           this:set_bit(`int bit, bool value`) 

# tuneables function
----------------------------------------------------------------------------------------------------
`bool`          tuneables.get_bool(`int hash, int offset|nil offset`)
`bool`          tuneables.get_bool(`string hash, int offset|nil offset`)

`number`        tuneables.get_int(`int hash, int offset|nil offset`)
`number`        tuneables.get_int(`string hash, int offset|nil offset`)

`number`        tuneables.get_float(`int hash, int offset|nil offset`)
`number`        tuneables.get_float(`string hash, int offset|nil offset`)

`nil`           tuneables.set_bool(`int hash, int value, int offset|nil offset`)
`nil`           tuneables.set_bool(`string hash, int value, int offset|nil offset`)

`nil`           tuneables.set_int(`int hash, int value, int offset|nil offset`)
`nil`           tuneables.set_int(`string hash, int value, int offset|nil offset`)

`nil`           tuneables.set_float(`int hash, int value, int offset|nil offset`)
`nil`           tuneables.set_float(`string hash, int value, int offset|nil offset`)

# script_program
----------------------------------------------------------------------------------------------------
`navret`		src:native_function(...)

`example`	[[
			`将本机函数在指定脚本中执行...`
			local invoke = gui.add_tab("my invoke")
			invoke:add_button("my code", function()
				print( freemode:GET_THIS_SCRIPT_NAME() ) // 将返回这个脚本是什么
				print( freemode:NETWORK_IS_HOST_OF_THIS_SCRIPT() ) // 将返回你是否这个脚本的主机 script_host
				print( freemode:NETWORK_GET_HOST_OF_THIS_SCRIPT() ) // 将返回这个脚本的主机id script_host
			end)
			]]
			
# audio function
----------------------------------------------------------------------------------------------------
`nil`           audio.play_sound_from_coord(`int soundid, string audioname, v3pos[], string audioref`)

# cutscene function
----------------------------------------------------------------------------------------------------
`bool`          cutscene.is_active()

`bool`          cutscene.is_playing()

`nil`           cutscene.remove()

`nil`           cutscene.stop_immediately()


# entity function
----------------------------------------------------------------------------------------------------
`number`        entity.get_distance(`int entity1, int entity2`)

`bool`          entity.does_exist(`int entity`)

`vector3`       entity.get_coords(`int entity`)

`nil`           entity.set_coords(`int entity, v3[]`)

`vector3`       entity.get_rotation(`int entity`)

`nil`           entity.set_rotation(`int entity, v3[]`)

`number`        entity.get_heading(`int entity`)

`nil`           entity.set_heading(`int entity, float heading`)

`nil`           entity.delete(`int entity`)

`nil`           entity.freeze_position(`int entity, bool value`)

`hash`          entity.get_model(`int entity`)

`vector3`       entity.get_forward_vector(`int entity`)


# fire function
----------------------------------------------------------------------------------------------------
`nil`           fire.add_owned_explosion(`int ped, v3[], int explosiontype`)

`nil`           fire.add_explosion(`v3[], int explosiontype`)

# hud function
----------------------------------------------------------------------------------------------------
`nil`           hud.add_draw_text(`string text, v2[], float textsize`)

`bool`          hud.is_waypoint_active()

# money function
----------------------------------------------------------------------------------------------------
`number`        money.get_wallet_balance()

`number`        money.get_bank_balance()

# netshopping function
----------------------------------------------------------------------------------------------------
`nil`           netshopping.transfer_wallet_to_bank(`int value`)

`nil`           netshopping.transfer_bank_to_wallet(`int value`)

# network function
----------------------------------------------------------------------------------------------------
`player`        network.get_host_of_this_session()

`bool`          network.is_host_of_this_session()

`player`        network.get_host_of_this_script(`string hash`)

`bool`          network.is_host_of_this_script(`string hash`)

`nil`           network.request_control_of_entity(`int entity`)

`bool`          network.has_control_of_entity(`int entity`)

`nil`           network.session_kick_player(`int player`)

# object function
----------------------------------------------------------------------------------------------------
`object`        object.create_object(`string hash, v3[], bool dynamic`)
`object`        object.create_object(`int hash, v3[], bool dynamic`)

# ped function
----------------------------------------------------------------------------------------------------
`ped`           ped.create_ped(`int ped_type, string hash, v3[]`)
`ped`           ped.create_ped(`int ped_type, int hash, v3[]`)

`bool`          ped.get_config_flag(`int ped, int flags`)

`nil`           ped.set_config_flag(`int ped, int flags, bool value`)

`bool`          ped.get_reset_flag(`int ped, int flags`)

`nil`           ped.set_reset_flag(`int ped, int flags, bool value`)

`bool`          ped.is_in_vehicle(`int ped`)

`vehicle`       ped.get_ped_vehicle(`int ped`)

# player function
----------------------------------------------------------------------------------------------------
`number`        player.get_number_of_players()

`player`        player.player_id()

`string`        player.get_player_name(`int player`)

`ped`           player.get_player_ped(`int player`)

`ped`           player.player_ped()

`bool`          player.is_in_vehicle(`int player`)

`vehicle`       player.get_player_vehicle(`int player`)

`vehicle`       player.player_vehicle()

`number`        player.get_player_rockstar_id(`int player`)

`nil`           player.set_model(`int player, string hash`)

`nil`           player.set_model(`int player, int hash`)

`number`        player.get_wanted_level(`int player`)

`nil`           player.set_wanted_level(`int player, int wantedlevel`)

`bool`          player.is_godmode(`int player`)

# script function
----------------------------------------------------------------------------------------------------
`navret`		script.special_native(`string scripthash`, function natives, ...)

`nil`           script.start_new_script(`string hash, int stacksize`)
`nil`           script.start_new_script(`int hash, int stacksize`)

`bool`          script.is_active(`string hash`)
`bool`          script.is_active(`int hash`)

# stats function
----------------------------------------------------------------------------------------------------
`nil`           stats.stat_load(`int character`)

`nil`           stats.stat_save()

`number`        stats.get_int64(`string hash`)
`number`        stats.get_int64(`int hash`)

`number`        stats.get_int(`string hash`)
`number`        stats.get_int(`int hash`)

`number`        stats.get_float(`string hash`)
`number`        stats.get_float(`int hash`)

`bool`          stats.get_bool(`string hash`)
`bool`          stats.get_bool(`int hash`)

`string`        stats.get_string(`string hash`)
`string`        stats.get_string(`int hash`)

`string`        stats.get_user_id(`string hash`)
`string`        stats.get_user_id(`int hash`)

`bool`          stats.get_packed_bool(`int index`)
`number`        stats.get_packed_int(`int index`)

`nil`           stats.set_int64(`string hash, int64 value`)
`nil`           stats.set_int64(`int hash, int64 value`)

`nil`           stats.set_int(`string hash, int value`)
`nil`           stats.set_int(`int hash, int value`)

`nil`           stats.set_float(`string hash, float value`)
`nil`           stats.set_float(`int hash, float value`)

`nil`           stats.set_bool(`string hash, bool value`)
`nil`           stats.set_bool(`int hash, bool value`)

`nil`           stats.set_string(`string hash, string value`)
`nil`           stats.set_string(`int hash, string value`)

`nil`           stats.set_user_id(`string hash, string value`)
`nil`           stats.set_user_id(`int hash, string value`)

`nil`           stats.set_packed_bool(`int index, bool value`)
`nil`           stats.set_packed_int(`int index, int value`)

# streaming function
----------------------------------------------------------------------------------------------------
`nil`           streaming.request_model(`string hash`)
`nil`           streaming.request_model(`int hash`)

`bool`          streaming.has_model_loaded(`string hash`)
`bool`          streaming.has_model_loaded(`int hash`)

`nil`           streaming.set_model_as_no_longer_needed(`string hash`)
`nil`           streaming.set_model_as_no_longer_needed(`int hash`)

# vehicle function
----------------------------------------------------------------------------------------------------
`vehicle`       vehicle.create_vehicle(`string hash, v3[], bool max_mods`)
`vehicle`       vehicle.create_vehicle(`int hash, v3[], bool max_mods`)

# weapon function
----------------------------------------------------------------------------------------------------
`entity`        weapon.get_ped_weapon_entity(`int ped`)

`nil`           weapon.remove_ped_all_weapons(`int ped`)

`nil`           weapon.remove_ped_weapon(`int ped, int hash`)
`nil`           weapon.remove_ped_weapon(`int ped, string hash`)

# zone function
----------------------------------------------------------------------------------------------------
`string`        zone.get_name_of_zone(`v3[]`)

# memory function
----------------------------------------------------------------------------------------------------
`vehicle`       memory.get_vehicle(`int vehicle`)

`ped`           memory.get_ped(`int ped`)

`plane`         memory.get_plane_bullet()

`vehicle`       ped:get_current_vehicle()
`weapon`        ped:get_current_weapon()

`number`        vehicle:get_gravity()
`nil`           vehicle:set_gravity(`float value`)
`number`        vehicle:get_boost()
`nil`           vehicle:set_boost(`float value`)
`number`        vehicle:get_model_hash()
`nil`           vehicle:set_model_hash(`int hash`)
`bool`          vehicle:get_model_extras(`int flags`)
`nil`           vehicle:set_model_extras(`int flags, bool value`)

`number`        weapon:get_damage_type()
`nil`           weapon:set_damage_type(`int value`)
`number`        weapon:get_explosion_type()
`nil`           weapon:set_explosion_type(`int value`)
`number`        weapon:get_bullets_in_batch()
`nil`           weapon:set_bullets_in_batch(`int value`)
`number`        weapon:get_batch_spread()
`nil`           weapon:set_batch_spread(`float value`)
`number`        weapon:get_ped_force()
`nil`           weapon:set_ped_force(`float value`)
`number`        weapon:get_vehicle_force()
`nil`           weapon:set_vehicle_force(`float value`)
`number`        weapon:get_heli_force()
`nil`           weapon:set_heli_force(`float value`)

`number`        plane:get_explosion_type()
`nil`           plane:set_explosion_type(`int value`)
`number`        plane:get_shotting_speed()
`nil`           plane:set_shotting_speed(`float value`)

# menu function
----------------------------------------------------------------------------------------------------
`handler`       menu.add_feature(`string name, string menutype, handler tab, arg, ...`)

				```
				local main = menu.add_feature(`"main", "submenu", NULL`)
				local submenu = menu.add_feature(`"> submenu", "submenu", main`)
						
				menu.add_feature(`"test", "text", submenu`)
						
				menu.add_feature(`"test", "action", submenu, function()
					print(`"action"`)
				end`)
                       
				toggles = menu.add_feature(`"test", "toggle", submenu, function(`f`) -- 参数在代码块中使用
					while f.toggle:is_enabled() do -- 始终调用开关的状态
						print(`f.toggle`) -- 返回userdata
						print(`f.value`) -- 返回bool值
						menu.yield()
					end
				end`);toggles:set_enabled(`false`)
                        
                |`input_int`|
                |`input_float`|
                |`input_string`|
                |`auto_input_int`|
                |`auto_input_float`|
                |`auto_input_string`|
				menu.add_feature(`"test", "input_int", submenu, function() -- 第一个arg没有参数
					return globals.get_int(`...`) -- 返回的值将设置当前输入框
				end, function(`value`) -- 参数在代码块中使用
					print(`value`) -- 它是输入框的值
				end`)
				```
						
`nil`           menu.yield()
`nil`           menu.yield(`ms`)

`nil`           menu.create_thread(`arg`)

`nil`           menu.print(`any data, ...`)

`nil`           menu.notify(`string title, string message, string type|nil`)

`nil`           menu.end_cutscene()

`nil`           menu.change_session(`int value`)

`nil`           menu.call_kosatka()

`nil`           menu.disable_bounds_death()

`nil`           menu.trigger_purchase_supplies(`int prop_id`)

`nil`           menu.trigger_production(`int prop_id`)

`nil`           menu.trigger_staff_warehouse_crate(`int value`)

`nil`           menu.trigger_staff_hangar_cargo(`int value`)

`nil`           menu.casino_select_lucky_wheel_slot(`int value`)

`nil`           menu.casino_three_card_poker()

`nil`           menu.casino_three_card_poker_chips(`int value`)

`nil`           menu.casino_blackjack()

`nil`           menu.casino_blackjack_chips(`int value`)

`nil`           menu.casion_rig_slot(`bool value`)

`nil`           menu.casino_force_slot_transaction()

`nil`           menu.remove_cctvs()

`nil`           menu.get_mission_mode()

`nil`           menu.can_be_alone_launcher_mission()

`bool`          menu.get_heist_is_diamond_casino()

`bool`          menu.get_heist_is_cayo_perico()

`mission`       menu.request_apartment_heist()

`mission`       menu.request_doomsday_action()

`mission`       menu.request_diamond_casino()

`mission`       menu.request_cayo_perico()

`number`        mission:get_player_cut(`int player`)
`nil`           mission:set_player_cut(`int player, int value`)
`bool`          mission:get_player_ready(`int player`)
`nil`           mission:set_player_ready(`int player, bool value`)
`number`        mission:get_team_life()
`nil`           mission:set_team_life(`int value`)
`number`        mission:get_take()
`nil`           mission:set_take(`int value`)
`nil`           mission:auto_player_cut()
`nil`           mission:instant_minigame_passed()
`nil`           mission:instant_mission_passed(`bool cutscene`)

`nil`           menu.restart_facility_board()

`nil`           menu.restart_kosatka_board()

`number`		menu.get_warehouse_id()

`nil`			menu.begin_transaction(`category, action, flags, [item_hash, item_value]`)

`number`		menu.anti_instant_mission(`string src_heist_hash`)

`nil`           menu.anti_crash_cam(`bool value`)

`nil`           menu.memory_crash(`int player`)

`nil`           menu.r13_opcode_crash(`int player`)

`nil`           menu.ped_texture_crash(`int player`)

`nil`           menu.object_fragment_crash(`int player`)

`nil`           menu.task_temp_action_crash(`int player`)

`nil`           menu.task_land_plane_crash(`int player`)

`nil`           menu.task_goto_submarine_crash(`int player`)

`nil`           menu.show_all_vehicles(`bool value`)