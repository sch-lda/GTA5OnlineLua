bit32 = {}
function bit32.lshift(num_i, bit_i)
	return math.floor(num_i << bit_i)
end

function bit32.rshift(num_i, bit_i)
	return math.floor(num_i >> bit_i)
end