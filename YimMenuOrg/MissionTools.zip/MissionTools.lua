-- ============================================
-- MISSIONS Tools by L7NEG https://dsc.gg/l7neg
-- ============================================

local function GetActiveMPSlot()
    local PI = stats.get_int("MPPLY_LAST_MP_CHAR")
    if PI == 1 then
        return "MP1_"
    end
    return "MP0_"
end

local MPX = GetActiveMPSlot()

local CSG1 = 1575046
local CSG2 = 1574589
local CSG3 = 1574589 + 2

local sessionSwitchInProgress = false
local pendingPulse = nil

local SESSION_TYPES = {
    { "Public",             0 },
    { "New Public",         1 },
    { "Closed Crew",        2 },
    { "Crew",               3 },
    { "Closed Friend",      4 },
    { "Find Friend",        5 },
    { "Solo",               6 },
    { "Invite Only",        7 },
    { "Join Crew",          8 },
    { "Leave GTA Online",  -1 }
}

local SESSION_COMBO_STR = ""
for _, s in ipairs(SESSION_TYPES) do
    SESSION_COMBO_STR = SESSION_COMBO_STR .. s[1] .. "\0"
end
SESSION_COMBO_STR = SESSION_COMBO_STR .. "\0"

local selectedSessionType = 0

local ULP_MISSIONS = {
    "Intelligence", "Counterintelligence", "Extraction",
    "Asset Seizure", "Operation Paper Trail", "Clean Up"
}
local DOSE_MISSIONS = {
    "Welcome to the Troupe", "Designated Driver", "Fatal Incursion",
    "Uncontrolled Substance", "Make War not Love", "Off the Rails",
    "This is an Intervention", "Unusual Suspects", "Fried Mind",
    "Checking In", "BDKD"
}
local M25_MISSIONS = {
    "Negative Press", "Inside Job", "Tunnel Vision",
    "Trash Talking", "A Clean Break"
}
local LAMAR_MISSIONS = {
    "Community Outreach", "Slow and Low", "It's a G Thing",
    "Funeral Party", "Lowrider Envy", "Point and Shoot",
    "Desperate Times Call For...", "Peace Offerings"
}
local YACHT_MISSIONS = {
    "Overboard", "Salvage", "All Hands",
    "Icebreaker", "Bon Voyage", "D-Day"
}

local ULP_COMBO_STR = table.concat(ULP_MISSIONS, "\0") .. "\0"
local DOSE_COMBO_STR = table.concat(DOSE_MISSIONS, "\0") .. "\0"
local M25_COMBO_STR = table.concat(M25_MISSIONS, "\0") .. "\0"
local LAMAR_COMBO_STR = table.concat(LAMAR_MISSIONS, "\0") .. "\0"
local YACHT_COMBO_STR = table.concat(YACHT_MISSIONS, "\0") .. "\0"

local cache = {
    ulpIndex = 0, doseIndex = 0, m25Index = 0,
    lamarIndex = 0, yachtIndex = 0,
    prevULP = -1, prevDOSE = -1, prevM25 = -1,
    prevLamar = -1, prevYacht = -1
}

local savedState = nil

local editing = { ulp = false, dose = false, m25 = false, lamar = false, yacht = false }

local function Clamp(val, min, max)
    return math.max(min, math.min(max, val))
end

-- === PHASE-BASED PULSE HANDLER ===
script.register_looped("SessionPulseHandler", function()
    if not pendingPulse then return end
    local elapsed = os.clock() - pendingPulse.phaseStart
    if pendingPulse.phase == 1 and elapsed >= 1.0 then
        globals.set_int(CSG2, 1)
        pendingPulse.phase = 2
        pendingPulse.phaseStart = os.clock()
    elseif pendingPulse.phase == 2 and elapsed >= 1.0 then
        globals.set_int(CSG2, 0)
        sessionSwitchInProgress = false
        pendingPulse = nil
    end
end)

-- === COMPLETE LAMAR STAT WRITER (1-BASED) ===
local function WriteLamarStats(luaIndex)
    local statValue = luaIndex + 1
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG", statValue)
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_CALL", statValue)
    local csFlags = {
        "LOW_BEN_INTRO_CS_SEEN", "LOW_FLOW_CS_DRV_SEEN",
        "LOW_FLOW_CS_TRA_SEEN", "LOW_FLOW_CS_FUN_SEEN",
        "LOW_FLOW_CS_PHO_SEEN", "LOW_FLOW_CS_FIN_SEEN"
    }
    for i, flag in ipairs(csFlags) do
        stats.set_bool(MPX .. flag, statValue >= (i + 1))
    end
    stats.set_int(MPX .. "LOWRIDER_FLOW_COMPLETE", math.min(statValue, 4))
    local helpTextMap = { 10, 20, 30, 40, 50, 60, 66, 66 }
    stats.set_int(MPX .. "LOW_FLOW_CS_HELPTEXT", helpTextMap[statValue] or 66)
end

-- === SAFE STAT READER LOOP ===
script.register_looped("MissionCacheUpdater", function()
    -- Now correctly reads stats when combos are closed
    if not editing.ulp then
        cache.ulpIndex = Clamp(stats.get_int(MPX .. "ULP_MISSION_CURRENT") or 0, 0, #ULP_MISSIONS - 1)
    end
    if not editing.dose then
        cache.doseIndex = Clamp(stats.get_int(MPX .. "XM22_CURRENT") or 0, 0, #DOSE_MISSIONS - 1)
    end
    if not editing.m25 then
        cache.m25Index = Clamp(stats.get_int(MPX .. "M25_AVI_MISSION_CURRENT") or 0, 0, #M25_MISSIONS - 1)
    end
    if not editing.lamar then
        local rawLamar = stats.get_int(MPX .. "LOW_FLOW_CURRENT_PROG") or 0
        cache.lamarIndex = Clamp(rawLamar - 1, 0, #LAMAR_MISSIONS - 1)
    end
    if not editing.yacht then
        cache.yachtIndex = Clamp(stats.get_int(MPX .. "YACHT_MISSION_PROG") or 0, 0, #YACHT_MISSIONS - 1)
    end

    local curULP = stats.get_int(MPX .. "ULP_MISSION_CURRENT")
    local curDOSE = stats.get_int(MPX .. "XM22_CURRENT")
    local curM25 = stats.get_int(MPX .. "M25_AVI_MISSION_CURRENT")
    local curLamar = stats.get_int(MPX .. "LOW_FLOW_CURRENT_PROG")
    local curYacht = stats.get_int(MPX .. "YACHT_MISSION_PROG")

    if not editing.ulp and curULP ~= cache.prevULP and curULP >= 0 and curULP < #ULP_MISSIONS and cache.prevULP ~= -1 then
        gui.show_message("ULP Missions", "Looks like your ULP mission just changed to \"" .. ULP_MISSIONS[curULP + 1] .. "\".")
    end
    if not editing.dose and curDOSE ~= cache.prevDOSE and curDOSE >= 0 and curDOSE < #DOSE_MISSIONS and cache.prevDOSE ~= -1 then
        gui.show_message("DOSE Missions", "Your DOSE mission updated to \"" .. DOSE_MISSIONS[curDOSE + 1] .. "\".")
    end
    if not editing.m25 and curM25 ~= cache.prevM25 and curM25 >= 0 and curM25 < #M25_MISSIONS and cache.prevM25 ~= -1 then
        gui.show_message("KnoWay Out", "KnoWay Out mission shifted to \"" .. M25_MISSIONS[curM25 + 1] .. "\".")
    end
    if not editing.lamar and curLamar ~= cache.prevLamar and curLamar >= 1 and curLamar <= #LAMAR_MISSIONS and cache.prevLamar ~= -1 then
        gui.show_message("Lamar Missions", "Lamar mission is now \"" .. LAMAR_MISSIONS[curLamar] .. "\".")
    end
    if not editing.yacht and curYacht ~= cache.prevYacht and curYacht >= 0 and curYacht < #YACHT_MISSIONS and cache.prevYacht ~= -1 then
        gui.show_message("Yacht Missions", "Yacht mission changed to \"" .. YACHT_MISSIONS[curYacht + 1] .. "\".")
    end

    cache.prevULP = curULP; cache.prevDOSE = curDOSE; cache.prevM25 = curM25
    cache.prevLamar = curLamar; cache.prevYacht = curYacht
end)

-- =============================================
-- TAB 1: MISSIONS Mission Tools
-- =============================================
local tab = gui.add_tab("Mission Tools")

local function AddMissionSection(title, label, comboStr, missions, cacheKey, editKey, notifyTitle, needsSession, extraStatFn)
    tab:add_text(title .. ":")
    tab:add_imgui(function()
        ImGui.Text("Select " .. title .. ":")
        ImGui.SetNextItemWidth(300)

        -- Only lock editing while the combo popup is open
        local isOpen = false
        local newIndex, changed = ImGui.Combo(label, cache[cacheKey], comboStr)

        -- Check if combo is currently open by comparing index change or using IsItemActive
        -- Since ImGui.Combo returns changed=true only on selection, we track open state via cache comparison
        editing[editKey] = (newIndex ~= cache[cacheKey]) or changed

        if changed then
            cache[cacheKey] = newIndex
            if extraStatFn then
                extraStatFn(newIndex)
            else
                local statNames = {
                    ulp = "ULP_MISSION_CURRENT", dose = "XM22_CURRENT",
                    m25 = "M25_AVI_MISSION_CURRENT", yacht = "YACHT_MISSION_PROG"
                }
                if statNames[editKey] then
                    stats.set_int(MPX .. statNames[editKey], newIndex)
                end
            end
            local missionName = missions[newIndex + 1]
            local msg = "Set your " .. title .. " to \"" .. missionName .. "\"."
            if needsSession then
                msg = msg .. "\n\nDon't forget to switch sessions below to make it take effect!"
            end
            gui.show_message(notifyTitle, msg)
        end

        local completed = cache[cacheKey] + 1
        if cache[cacheKey] >= 0 and cache[cacheKey] < #missions then
            ImGui.TextColored(0.2, 1.0, 0.2, 1.0,
                string.format("Current: %s | %d/%d Completed", missions[cache[cacheKey]+1], completed, #missions))
        else
            ImGui.TextColored(0.8, 0.5, 0.5, 1.0, "Current: None | 0/" .. #missions .. " Completed")
        end
    end)
    tab:add_separator()
end

local function OnYachtChanged(index)
    local flowMask = 0
    for i = 0, index do flowMask = flowMask | (1 << i) end
    stats.set_int(MPX .. "YACHT_MISSION_FLOW", flowMask)
end

AddMissionSection("ULP Contract", "##ULPMission", ULP_COMBO_STR, ULP_MISSIONS, "ulpIndex", "ulp", "ULP Missions", false, nil)
AddMissionSection("DOSE Mission", "##DOSEMission", DOSE_COMBO_STR, DOSE_MISSIONS, "doseIndex", "dose", "DOSE Missions", false, nil)
AddMissionSection("KnoWay Out (M25)", "##M25Mission", M25_COMBO_STR, M25_MISSIONS, "m25Index", "m25", "KnoWay Out", true, nil)
AddMissionSection("Lamar / Lowrider", "##LamarMission", LAMAR_COMBO_STR, LAMAR_MISSIONS, "lamarIndex", "lamar", "Lamar Missions", true, WriteLamarStats)
AddMissionSection("Yacht Mission", "##YachtMission", YACHT_COMBO_STR, YACHT_MISSIONS, "yachtIndex", "yacht", "Yacht Missions", false, OnYachtChanged)

-- === UNIFIED SESSION SWITCHER ===
tab:add_text("Session Switcher:")
tab:add_imgui(function()
    ImGui.Text("Target Session:")
    ImGui.SetNextItemWidth(300)
    local newIndex, changed = ImGui.Combo("##SessionType", selectedSessionType, SESSION_COMBO_STR)
    if changed then
        selectedSessionType = newIndex
        local sessionName = SESSION_TYPES[newIndex + 1][1]
        local msg = "Target set to \"" .. sessionName .. "\".\nClick Switch Session Now to apply."
        gui.show_message("Session", msg)
    end
end)

tab:add_button("Switch Session Now", function()
    if sessionSwitchInProgress then
        gui.show_message("Session", "Switch already in progress. Please wait.")
        return
    end
    local sessionInfo = SESSION_TYPES[selectedSessionType + 1]
    local sessionName = sessionInfo[1]
    local writeId = sessionInfo[2]
    sessionSwitchInProgress = true
    if writeId == -1 then
        gui.show_message("Session Switch", "Leaving GTA Online...\nThis takes ~2 seconds.")
        globals.set_int(CSG1, -1)
        globals.set_int(CSG3, -1)
    else
        local switchMsg = "Heading to \"" .. sessionName .. "\" now.\nYour selection will load after it finishes."
        gui.show_message("Session Switch", switchMsg)
        globals.set_int(CSG1, writeId)
    end
    pendingPulse = { phase = 1, phaseStart = os.clock() }
end)

tab:add_separator()

tab:add_button("[SAVE] Current Mission State", function()
    savedState = {
        ulp = cache.ulpIndex, dose = cache.doseIndex,
        m25 = cache.m25Index, lamar = cache.lamarIndex,
        yacht = cache.yachtIndex
    }
    local saveMsg = "All done! Your current mission setup has been saved.\n\n"
        .. "ULP: " .. (ULP_MISSIONS[savedState.ulp+1] or "None")
        .. "\nDOSE: " .. (DOSE_MISSIONS[savedState.dose+1] or "None")
        .. "\nKnoWay Out: " .. (M25_MISSIONS[savedState.m25+1] or "None")
        .. "\nLamar: " .. (LAMAR_MISSIONS[savedState.lamar+1] or "None")
        .. "\nYacht: " .. (YACHT_MISSIONS[savedState.yacht+1] or "None")
        .. "\n\nYou can restore this anytime from the Load button."
    gui.show_message("Save State", saveMsg)
end)

tab:add_button("[LOAD] Saved Mission State", function()
    if not savedState then
        gui.show_message("Load State", "Nothing saved yet!\n\nHit the Save button first to capture your current missions.")
        return
    end
    editing.ulp = false; editing.dose = false; editing.m25 = false
    editing.lamar = false; editing.yacht = false
    stats.set_int(MPX .. "ULP_MISSION_CURRENT", savedState.ulp)
    stats.set_int(MPX .. "XM22_CURRENT", savedState.dose)
    stats.set_int(MPX .. "M25_AVI_MISSION_CURRENT", savedState.m25)
    stats.set_int(MPX .. "YACHT_MISSION_PROG", savedState.yacht)
    WriteLamarStats(savedState.lamar)
    local flowMask = 0
    for i = 0, savedState.yacht do flowMask = flowMask | (1 << i) end
    stats.set_int(MPX .. "YACHT_MISSION_FLOW", flowMask)
    cache.ulpIndex = savedState.ulp; cache.doseIndex = savedState.dose
    cache.m25Index = savedState.m25; cache.lamarIndex = savedState.lamar
    cache.yachtIndex = savedState.yacht
    local loadMsg = "Restored your saved missions!\n\n"
        .. "ULP: " .. (ULP_MISSIONS[savedState.ulp+1] or "None")
        .. "\nDOSE: " .. (DOSE_MISSIONS[savedState.dose+1] or "None")
        .. "\nKnoWay Out: " .. (M25_MISSIONS[savedState.m25+1] or "None")
        .. "\nLamar: " .. (LAMAR_MISSIONS[savedState.lamar+1] or "None")
        .. "\nYacht: " .. (YACHT_MISSIONS[savedState.yacht+1] or "None")
        .. "\n\nEverything's back to how you left it."
    gui.show_message("Load State", loadMsg)
end)

-- =============================================
-- TAB 2: MISSION SKIPS
-- =============================================
local skipsTab = tab:add_tab("Mission Skips")

skipsTab:add_text("KnoWay Out Progress:")
skipsTab:add_button("[SKIP] KnoWay Out - Home Sweet Home", function()
    stats.set_int(MPX .. "M25_AVI_MISSION_CURRENT", 4)
    stats.set_int(MPX .. "M25_GENERAL_BS", 63)
    cache.m25Index = 4
    gui.show_message("KnoWay Out Skip", "Skipped to Home Sweet Home.\nM25_GENERAL_BS set to 63.\n\nChange session to apply.")
end)
skipsTab:add_button("[SKIP] KnoWay Out - All Finished", function()
    stats.set_int(MPX .. "M25_AVI_MISSION_CURRENT", 4)
    stats.set_int(MPX .. "M25_GENERAL_BS", 127)
    cache.m25Index = 4
    gui.show_message("KnoWay Out Skip", "Skipped to All Finished.\nM25_GENERAL_BS set to 127.\n\nChange session to apply.")
end)
skipsTab:add_button("[SKIP] KnoWay Out - After Mr. Faber Call", function()
    stats.set_int(MPX .. "M25_AVI_MISSION_CURRENT", 4)
    stats.set_int(MPX .. "M25_GENERAL_BS", 16511)
    cache.m25Index = 4
    gui.show_message("KnoWay Out Skip", "Skipped to After Mr. Faber Call.\nM25_GENERAL_BS set to 16511.\nHome Sweet Home replayable from pause menu.\n\nChange session to apply.")
end)
skipsTab:add_button("[UNDO] KnoWay Out Skip", function()
    stats.set_int(MPX .. "M25_AVI_MISSION_CURRENT", 0)
    stats.set_int(MPX .. "M25_GENERAL_BS", 0)
    cache.m25Index = 0
    gui.show_message("KnoWay Out Undo", "Reset KnoWay Out to Negative Press.\nM25_GENERAL_BS cleared.\n\nChange session to apply.")
end)

skipsTab:add_separator()

skipsTab:add_text("Lamar / Lowrider:")
skipsTab:add_button("[SKIP] Lamar - Complete All Missions", function()
    stats.set_bool(MPX .. "LOW_FLOW_CS_DRV_SEEN", true)
    stats.set_bool(MPX .. "LOW_FLOW_CS_TRA_SEEN", true)
    stats.set_bool(MPX .. "LOW_FLOW_CS_FUN_SEEN", true)
    stats.set_bool(MPX .. "LOW_FLOW_CS_PHO_SEEN", true)
    stats.set_bool(MPX .. "LOW_FLOW_CS_FIN_SEEN", true)
    stats.set_bool(MPX .. "LOW_BEN_INTRO_CS_SEEN", true)
    stats.set_int(MPX .. "LOWRIDER_FLOW_COMPLETE", 4)
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG", 9)
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_CALL", 9)
    stats.set_int(MPX .. "LOW_FLOW_CS_HELPTEXT", 66)
    cache.lamarIndex = Clamp(9 - 1, 0, #LAMAR_MISSIONS - 1)
    gui.show_message("Lamar Skip", "All Lamar missions marked complete.\nFlow, cutscenes, and progress synced.")
end)
skipsTab:add_button("[UNDO] Lamar Skip", function()
    stats.set_bool(MPX .. "LOW_FLOW_CS_DRV_SEEN", false)
    stats.set_bool(MPX .. "LOW_FLOW_CS_TRA_SEEN", false)
    stats.set_bool(MPX .. "LOW_FLOW_CS_FUN_SEEN", false)
    stats.set_bool(MPX .. "LOW_FLOW_CS_PHO_SEEN", false)
    stats.set_bool(MPX .. "LOW_FLOW_CS_FIN_SEEN", false)
    stats.set_bool(MPX .. "LOW_BEN_INTRO_CS_SEEN", false)
    stats.set_int(MPX .. "LOWRIDER_FLOW_COMPLETE", 0)
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_PROG", 0)
    stats.set_int(MPX .. "LOW_FLOW_CURRENT_CALL", 0)
    stats.set_int(MPX .. "LOW_FLOW_CS_HELPTEXT", 0)
    cache.lamarIndex = 0
    gui.show_message("Lamar Undo", "All Lamar progress reset to start.")
end)

skipsTab:add_separator()

skipsTab:add_text("ULP Contract:")
skipsTab:add_button("[SKIP] ULP - Complete All Missions", function()
    stats.set_int(MPX .. "ULP_MISSION_PROGRESS", 127)
    stats.set_int(MPX .. "ULP_MISSION_CURRENT", 0)
    cache.ulpIndex = 0
    gui.show_message("ULP Skip", "ULP progress set to 127 (all complete).\nCurrent mission reset to Intelligence.")
end)
skipsTab:add_button("[UNDO] ULP Skip", function()
    stats.set_int(MPX .. "ULP_MISSION_PROGRESS", 0)
    stats.set_int(MPX .. "ULP_MISSION_CURRENT", 0)
    cache.ulpIndex = 0
    gui.show_message("ULP Undo", "ULP progress cleared.\nBack to Intelligence with no completions.")
end)

skipsTab:add_separator()

skipsTab:add_text("Yacht Missions:")
skipsTab:add_button("[SKIP] Yacht - Unlock All Missions", function()
    stats.set_int(MPX .. "YACHT_MISSION_PROG", 0)
    stats.set_int(MPX .. "YACHT_MISSION_FLOW", 21845)
    stats.set_int(MPX .. "CASINO_DECORATION_GIFT_1", -1)
    cache.yachtIndex = 0
    gui.show_message("Yacht Skip", "All yacht missions unlocked (flow 21845).\nCasino decoration gift reset.")
end)
skipsTab:add_button("[UNDO] Yacht Skip", function()
    stats.set_int(MPX .. "YACHT_MISSION_PROG", 0)
    stats.set_int(MPX .. "YACHT_MISSION_FLOW", 0)
    stats.set_int(MPX .. "CASINO_DECORATION_GIFT_1", 0)
    cache.yachtIndex = 0
    gui.show_message("Yacht Undo", "Yacht progress and flow cleared.\nCasino decoration gift reset.")
end)

-- =============================================
-- TAB 3: COOLDOWN UTILITIES
-- =============================================
local cdTab = tab:add_tab("Cooldown Utilities")

cdTab:add_text("Dax Call Missions:")
cdTab:add_button("[REMOVE] Dax Call Cooldown", function()
    stats.set_int(MPX .. "XM22JUGGALOWORKCDTIMER", -1)
    gui.show_message("Cooldown Removed", "Dax call mission cooldown cleared.\nYou can start a new Dax job immediately.")
end)
cdTab:add_button("[UNDO] Dax Call Cooldown", function()
    stats.set_int(MPX .. "XM22JUGGALOWORKCDTIMER", 0)
    gui.show_message("Cooldown Restored", "Dax call cooldown timer reset to default.")
end)

cdTab:add_separator()

cdTab:add_text("VIP / MC:")
cdTab:add_button("[REMOVE] VIP/MC Cooldown", function()
    stats.set_int("MPPLY_VIPGAMEPLAYDISABLEDTIMER", 0)
    gui.show_message("Cooldown Removed", "VIP/MC gameplay disabled timer cleared.\nYou can register as VIP/MC immediately.")
end)
cdTab:add_button("[UNDO] VIP/MC Cooldown", function()
    stats.set_int("MPPLY_VIPGAMEPLAYDISABLEDTIMER", 300)
    gui.show_message("Cooldown Restored", "VIP/MC cooldown timer restored to 300s default.")
end)