# Update scripts

Run both files from `YimMenu/scripts` directory.
