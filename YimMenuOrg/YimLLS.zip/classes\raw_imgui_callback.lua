---@meta
---Class for representing a raw imgui callback.
---@class raw_imgui_callback: gui_element
raw_imgui_callback = {}
