---@meta
---Class representing a gui button.
---Refer to the tab class documentation for more info (tab:add_button(name, callback))
---@class button: base_text_element
button = {}
