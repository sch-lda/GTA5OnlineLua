---@meta
---Class for ImGui::SameLine() - Puts a sameline between widgets or groups to layout them horizontally.
---Refer to the tab class documentation for more info (tab:add_sameline())
---@class sameline
sameline = {}
