-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local atArray             = require("includes.classes.gta.atArray")
local CCarHandlingData    = require("includes.classes.gta.CCarHandlingData")
local CBikeHandlingData   = require("includes.classes.gta.CBikeHandlingData")
local CEntity             = require("includes.classes.gta.CEntity")
local CFlyingHandlingData = require("includes.classes.gta.CFlyingHandlingData")
local CVehicleDrawData    = require("includes.classes.gta.CVehicleDrawData")
local CWheel              = require("includes.classes.gta.CWheel")
local fMatrix44           = require("includes.classes.gta.fMatrix44")
local phFragInst          = require("includes.classes.gta.phFragInst")


---@class CAdvancedData
---@class CVehicleModelInfo
---@class CVehicleDamage
---@class CHandlingData
---@class CVehicleModelInfoLayout


local SubHandlingCtorMap <const> = {
	[Enums.eHandlingType.CAR]    = function(ptr) return CCarHandlingData.new(ptr) end,
	[Enums.eHandlingType.BIKE]   = function(ptr) return CBikeHandlingData.new(ptr) end,
	[Enums.eHandlingType.FLYING] = function(ptr) return CFlyingHandlingData.new(ptr) end,
}


--------------------------------------
-- Class: CVehicle
--------------------------------------
---@ignore
---@class CVehicle : CEntity
---@field protected m_ptr pointer
---@field public m_physics_fragments phFragInst //0x30 `struct rage::phFragInst`
---@field public m_draw_data CVehicleDrawData
---@field public m_handling_data pointer<CHandlingData>
---@field public m_model_info pointer<CVehicleModelInfo>
---@field public m_vehicle_damage pointer<CVehicleDamage>
---@field public m_sub_handling_data atArray<CBaseSubHandlingData> `rage::atArray`
---@field public m_car_handling_data pointer<CCarHandlingData>?
---@field public m_model_info_layout pointer<CVehicleModelInfoLayout>
---@field public m_can_boost_jump pointer<byte> `bool`
---@field public m_deform_god pointer<uint8_t>
---@field public m_water_damage pointer<uint32_t>
---@field public m_next_gear pointer<int16_t>
---@field public m_current_gear pointer<int16_t>
---@field public m_top_gear pointer<int8_t>
---@field public m_engine_health pointer<float>
---@field public m_steering_input pointer<float> // 0xD4 name might not correctly reflect what this actually is but this seems to store controller input (value is between 0.99 (left) .. -0.99 (right))
---@field public m_current_steering pointer<float> 0xDC // actual wheel steer. Wr'll use it to rewrite last known wheel steer after exiting a vehicle in IV-Style Exit so we'll no longer need to teleport outside or patch CTaskVehicleExit
---@field public m_is_targetable pointer<byte> `bool`
---@field public m_door_lock_status pointer<uint32_t>
---@field public m_model_info_flags pointer<uint32_t>
---@field public m_mass pointer<float> -- 0x000C
---@field public m_initial_drag_coeff pointer<float>
---@field public m_drive_bias_rear pointer<float>
---@field public m_drive_bias_front pointer<float>
---@field public m_acceleration pointer<float>
---@field public m_initial_drive_gears pointer<uint8_t>
---@field public m_initial_drive_force pointer<float>
---@field public m_drive_max_flat_velocity pointer<float>
---@field public m_initial_drive_max_flat_vel pointer<float>
---@field public m_steering_lock pointer<float>
---@field public m_steering_lock_ratio pointer<float>
---@field public m_traction_curve_max pointer<float>
---@field public m_low_speed_traction_loss_mult pointer<float> -- 0x00A8
---@field public m_traction_loss_mult pointer<float> -- 0x00B8
---@field public m_monetary_value pointer<uint32_t>
---@field public m_model_flags pointer<uint32_t>
---@field public m_handling_flags pointer<uint32_t>
---@field public m_damage_flags pointer<uint32_t>
---@field public m_deform_mult pointer<float>
---@field public m_wheel_scale pointer<float>
---@field public m_wheel_scale_rear pointer<float>
---@field public m_throttle pointer<float> // 0x8D8
---@field public m_wheels atArray<CWheel> -- 0xC30
---@field public m_num_wheels number -- 0xC38
---@field public m_ride_height pointer<float>
---@field private DumpFlags fun(self: CVehicle, enum_flags: Enum, get_func: fun(self: CVehicle, flag: integer): boolean): nil
---@overload fun(vehicle: integer): CVehicle|nil
local CVehicle = Class("CVehicle", { parent = CEntity, symbolic_size = 0xC40 })

---@param vehicle handle
---@return CVehicle
function CVehicle:init(vehicle)
	if (not Game.IsScriptHandle(vehicle) or not ENTITY.IS_ENTITY_A_VEHICLE(vehicle)) then
		error("Invalid entity!")
	end

	---@type CVehicle
	---@diagnostic disable-next-line: param-type-mismatch
	local instance = setmetatable({}, CVehicle)
	instance:super().init(instance, vehicle)

	local ptr                               = memory.handle_to_ptr(vehicle)
	instance.m_ptr                          = ptr
	instance.m_model_info                   = ptr:add(0x20):deref()
	instance.m_vehicle_damage               = ptr:add(0x0420)
	instance.m_handling_data                = ptr:add(0x0960):deref()
	instance.m_sub_handling_data            = atArray(instance.m_handling_data:add(0x158), CCarHandlingData)
	instance.m_model_info_layout            = instance.m_model_info:add(0x00B0):deref()
	instance.m_physics_fragments            = phFragInst(ptr:add(0x0030):deref())
	instance.m_draw_data                    = CVehicleDrawData:init(ptr:add(0x0048):deref())
	instance.m_can_boost_jump               = ptr:add(0x03A4)
	instance.m_deform_god                   = ptr:add(0x096C)
	instance.m_is_targetable                = ptr:add(0x0AEE)
	instance.m_door_lock_status             = ptr:add(0x13D0)
	instance.m_water_damage                 = ptr:add(0x00D8)
	instance.m_next_gear                    = ptr:add(0x0880)
	instance.m_current_gear                 = ptr:add(0x0882)
	instance.m_top_gear                     = ptr:add(0x0886)
	instance.m_engine_health                = ptr:add(0x0910)
	instance.m_steering_input               = ptr:add(0x09D4)
	instance.m_current_steering             = ptr:add(0x09DC)
	instance.m_model_info_flags             = instance.m_model_info:add(0x057C)
	instance.m_mass                         = instance.m_handling_data:add(0x000C)
	instance.m_initial_drag_coeff           = instance.m_handling_data:add(0x0010)
	instance.m_drive_bias_rear              = instance.m_handling_data:add(0x0044)
	instance.m_drive_bias_front             = instance.m_handling_data:add(0x0048)
	instance.m_acceleration                 = instance.m_handling_data:add(0x004C)
	instance.m_initial_drive_gears          = instance.m_handling_data:add(0x0050)
	instance.m_initial_drive_force          = instance.m_handling_data:add(0x0060)
	instance.m_drive_max_flat_velocity      = instance.m_handling_data:add(0x0064)
	instance.m_initial_drive_max_flat_vel   = instance.m_handling_data:add(0x0068)
	instance.m_steering_lock                = instance.m_handling_data:add(0x0080)
	instance.m_steering_lock_ratio          = instance.m_handling_data:add(0x0084)
	instance.m_traction_curve_max           = instance.m_handling_data:add(0x0088)
	instance.m_low_speed_traction_loss_mult = instance.m_handling_data:add(0x00A8)
	instance.m_traction_loss_mult           = instance.m_handling_data:add(0x00B8)
	instance.m_deform_mult                  = instance.m_handling_data:add(0x00F8)
	instance.m_monetary_value               = instance.m_handling_data:add(0x0118)
	instance.m_model_flags                  = instance.m_handling_data:add(0x0124)
	instance.m_handling_flags               = instance.m_handling_data:add(0x0128)
	instance.m_damage_flags                 = instance.m_handling_data:add(0x012C)
	instance.m_wheel_scale                  = instance.m_model_info:add(0x048C)
	instance.m_wheel_scale_rear             = instance.m_model_info:add(0x0490)
	instance.m_throttle                     = instance.m_model_info:add(0x08D8)
	instance.m_wheels                       = atArray(ptr:add(0x0C30), CWheel)
	instance.m_num_wheels                   = ptr:add(0x0C38):get_int()
	instance.m_ride_height                  = ptr:add(0x0C30):deref():add(0x07C)

	return instance
end

---@return float
function CVehicle:GetAcceleration()
	return self:__safecall(0, function()
		return self.m_acceleration:get_float()
	end)
end

---@param value float
---@return boolean
function CVehicle:SetAcceleration(value)
	return self:__safecall(false, function()
		self.m_acceleration:set_float(value)
		return true
	end)
end

---@return float
function CVehicle:GetDeformMultiplier()
	return self:__safecall(0, function()
		return self.m_deform_mult:get_float()
	end)
end

---@param value float
---@return boolean
function CVehicle:SetDeformMultiplier(value)
	return self:__safecall(false, function()
		self.m_deform_mult:set_float(value)
		return true
	end)
end

---@param handlingType eHandlingType
---@return CCarHandlingData|CBikeHandlingData|CFlyingHandlingData|any
function CVehicle:GetSubHandlingData(handlingType)
	return self:__safecall(nil, function()
		for _, sub_ptr in self.m_sub_handling_data:Iter() do
			if (sub_ptr:is_valid()) then
				-- local base = CBaseSubHandlingData.new(sub_ptr)
				-- if (base and base:GetHandlingType() == handlingType) then
				local func = SubHandlingCtorMap[handlingType]
				return func and func(sub_ptr) or nil
				-- return func and func(sub_ptr) or base
				-- end
			end
		end
		return nil
	end)
end

---@param flag eVehicleHandlingFlags
---@return boolean
function CVehicle:GetHandlingFlag(flag)
	return self:__safecall(false, function()
		if (type(flag) ~= "number" or self.m_handling_flags:is_null()) then
			return false
		end

		local dword_flags = self.m_handling_flags:get_dword()
		return Bit.IsBitSet(dword_flags, flag)
	end)
end

---@param flag eVehicleHandlingFlags
---@param toggle boolean
function CVehicle:SetHandlingFlag(flag, toggle)
	if (not self:IsValid() or type(flag) ~= "number" or type(toggle) ~= "boolean") then
		return
	end

	if (self.m_handling_flags:is_null()) then
		return
	end

	local dword_flags = self.m_handling_flags:get_dword()
	local Bitwise     = toggle and Bit.Set or Bit.Clear
	local new_flags   = Bitwise(dword_flags, flag)

	self.m_handling_flags:set_dword(new_flags)
end

---@param flag eVehicleModelFlags
---@return boolean
function CVehicle:GetModelFlag(flag)
	return self:__safecall(false, function()
		if (type(flag) ~= "number" or self.m_model_flags:is_null()) then
			return false
		end

		local dword_flags = self.m_model_flags:get_dword()
		return Bit.IsBitSet(dword_flags, flag)
	end)
end

---@param flag eVehicleModelInfoFlags
---@return boolean
function CVehicle:GetModelInfoFlag(flag)
	return self:__safecall(false, function()
		if (not self.m_model_info_flags:is_valid()) then
			return false
		end

		local index    = math.floor(flag / 32)
		local bit_pos  = flag % 32
		local flag_ptr = self.m_model_info_flags:add(index * 4)
		if (flag_ptr:is_null()) then
			return false
		end

		local flag_bits = flag_ptr:get_dword()
		return Bit.IsBitSet(flag_bits, bit_pos)
	end)
end

---@param flag eVehicleModelInfoFlags
---@param toggle boolean
function CVehicle:SetModelInfoFlag(flag, toggle)
	if (not self:IsValid()) then
		return
	end

	local index    = math.floor(flag / 32)
	local bit_pos  = flag % 32
	local flag_ptr = self.m_model_info_flags:add(index * 4)
	if (flag_ptr:is_null()) then
		return
	end

	local flag_bits = flag_ptr:get_dword()
	local Bitwise   = toggle and Bit.Set or Bit.Clear
	local new_bits  = Bitwise(flag_bits, bit_pos)
	flag_ptr:set_dword(new_bits)
end

---@param flag eVehicleAdvancedFlags
---@return boolean
function CVehicle:GetAdvancedFlag(flag)
	return self:__safecall(false, function()
		local cchd = self:GetSubHandlingData(Enums.eHandlingType.CAR)
		if (not cchd or not cchd.m_advanced_flags or cchd.m_advanced_flags:is_null()) then
			return false
		end

		local dword_flags = cchd.m_advanced_flags:get_dword()
		return Bit.IsBitSet(dword_flags, flag)
	end)
end

---@param flag eVehicleAdvancedFlags
---@param toggle boolean
function CVehicle:SetAdvancedFlag(flag, toggle)
	if (not self:IsValid()) then
		return
	end

	---@type CCarHandlingData?
	local cchd = self:GetSubHandlingData(Enums.eHandlingType.CAR)
	if (not cchd or not cchd.m_advanced_flags or cchd.m_advanced_flags:is_null()) then
		return
	end

	local ptr         = cchd.m_advanced_flags
	local dword_flags = ptr:get_dword()
	local Bitwise     = toggle and Bit.Set or Bit.Clear
	local new_flags   = Bitwise(dword_flags, flag)

	ptr:set_dword(new_flags)
end

---@private
---@param enum_flags Enum
---@param get_func fun(self: CVehicle, flag: integer): boolean
function CVehicle:DumpFlags(enum_flags, get_func)
	if (not self:IsValid()) then
		log.warning("Invalid vehicle pointer!")
		return
	end

	---@type array<string>
	local out = {}
	for name, flag in pairs(enum_flags) do
		if (get_func(self, flag)) then
			out[#out + 1] = _F("%s (1 << %d)", name, flag)
		end
	end

	if (#out == 0) then
		out[1] = "No enabled flags."
	end

	print(out)
end

-- Prints all enabled handling flags to console.
function CVehicle:DumpHandlingFlags()
	self:DumpFlags(Enums.eVehicleHandlingFlags, self.GetHandlingFlag)
end

-- Prints all enabled model flags to console.
function CVehicle:DumpModelFlags()
	self:DumpFlags(Enums.eVehicleModelFlags, self.GetModelFlag)
end

-- Prints all enabled model info flags to console.
function CVehicle:DumpModelInfoFlags()
	self:DumpFlags(Enums.eVehicleModelInfoFlags, self.GetModelInfoFlag)
end

-- Prints all enabled advanced flags to console.
function CVehicle:DumpAdvancedFlags()
	self:DumpFlags(Enums.eVehicleAdvancedFlags, self.GetAdvancedFlag)
end

---@param boneIndex integer
---@return fMatrix44
function CVehicle:GetBoneMatrix(boneIndex)
	local ph_frag_inst = self.m_physics_fragments
	if not ph_frag_inst then
		return fMatrix44:zero()
	end

	local ptr = ph_frag_inst:GetMatrixPtr(boneIndex)
	if not (ptr and ptr:is_valid()) then
		return fMatrix44:zero()
	end

	return ptr:get_matrix44()
end

---@param boneIndex integer
---@param matrix fMatrix44
function CVehicle:SetBoneMatrix(boneIndex, matrix)
	local ph_frag_inst = self.m_physics_fragments
	if not ph_frag_inst then
		return
	end

	local ptr = ph_frag_inst:GetMatrixPtr(boneIndex)
	if not (ptr and ptr:is_valid()) then
		return
	end

	ptr:set_matrix44(matrix)
end

---@param boneIndex integer
---@param scalar vec3
function CVehicle:ScaleBoneMatrix(boneIndex, scalar)
	local matrix = self:GetBoneMatrix(boneIndex)
	local new_matrix = fMatrix44:scale(scalar) * matrix
	Backend:debug("new matrix %s", new_matrix)

	self:SetBoneMatrix(boneIndex, new_matrix)
end

---@param boneIndex integer
---@param axis vec3
---@param angle float
function CVehicle:RotateBoneMatrix(boneIndex, axis, angle)
	local matrix = self:GetBoneMatrix(boneIndex)
	local scale = vec3:new(1, 1, 1)
	local new_matrix = fMatrix44:scale(scale) * fMatrix44:rotate(axis, angle) * matrix

	self:SetBoneMatrix(boneIndex, new_matrix)
end

---@param wheelIndex integer
---@return boolean
function CVehicle:IsWheelBrokenOff(wheelIndex)
	-- if (not self:IsValid()) then
	-- 	return false
	-- end

	-- local cwheel = self:GetWheel(wheelIndex)
	-- if (not cwheel) then
	-- 	return false
	-- end

	-- return cwheel:GetDynamicFlag(Enums.eWheelDynamicFlags.BROKEN_OFF)
	return self:__safecall(false, function()
		-- Thanks tupoy-ya
		return (self.m_ptr:add(0xA98):get_dword() >> (wheelIndex & 0x1F) & 1) ~= 0
	end)
end

---@return CWheel?
function CVehicle:GetWheel(index)
	if (not self:IsValid() or index > self.m_num_wheels) then
		return
	end

	local ptr = self.m_wheels:Get(index)
	if (not ptr or ptr:is_null()) then
		return
	end

	return CWheel(ptr)
end

---@return CWheelDrawData
function CVehicle:GetWheelDrawData()
	return self.m_draw_data:GetWheelDrawData()
end

---@return float -- Wheel width or 0.f if invalid
function CVehicle:GetWheelWidth()
	return self.m_draw_data:GetWheelWidth()
end

---@return float -- Wheel size or 0.f if invalid
function CVehicle:GetWheelSize()
	return self.m_draw_data:GetWheelSize()
end

---@param fValue float
function CVehicle:SetWheelWidth(fValue)
	self.m_draw_data:SetWheelWidth(fValue)
end

---@param fValue float
function CVehicle:SetWheelSize(fValue)
	self.m_draw_data:SetWheelSize(fValue)
end

function CVehicle:HasWheelDrawData()
	return self.m_draw_data:GetWheelDrawData():IsValid()
end

---@param fHeight float positive = lower, negative = higher. should use values between `-0.1` and `0.1`
---@return boolean
function CVehicle:SetRideHeight(fHeight)
	return self:__safecall(false, function()
		if (type(fHeight) ~= "number") then
			return false
		end

		self.m_ride_height:set_float(fHeight)
		return true
	end)
end

return CVehicle
