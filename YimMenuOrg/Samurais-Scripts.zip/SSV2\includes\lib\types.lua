-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


---@meta

--#region Generic Containers

---@class array<T> : { [integer]: T }
---@class dict<T> : { [string]: T }
---@class pair<K, V>: { first: K, second: V } -- Not the same as the `Pair` module. This represents a simple table, the other is a module with metamethods.
---@class set<T>: { T: true } -- Not the same as the `Set` module. This represents a simple table, the other is a module with metamethods.
---@class tuple<T1, T2>: { [1]: T1, [2]: T2 }

---@generic V
---@alias ValueOrFunction fun():V|V

---@generic T
---@class GenericClass<T>
---@field m_size uint16_t
GenericClass = setmetatable({}, {
	__index = { m_size = 0x40, __type = "GenericClass" },
	__newindex = function(...)
		error("Attempt to modify read-only Generic Class!")
	end,
	__metatable = false
})

---@alias Obj table|metatable|userdata

---@class Enum
---@field public First fun(self: Enum): integer Returns the first value of the enum.
---@field public Keys fun(self: Enum): string[] Returns an array of all enum keys.
---@field public Values fun(self: Enum): integer[] Returns an array of all enum values.
---@field public NameOf fun(self: Enum, value: integer): string Returns the key name of `value`.
---@field public Has fun(self: Enum, value: integer): boolean Returns whether the enum has `value`
---@field private __sizeof fun(self: Enum): integer Used internally to get the symbolic size of the enum. If it's an enum of joaa_t -> Size = 0x4.
---@field private __enum boolean Used internally to flag this as an enum.
---@field private __data_type? string Optional: "int8_t" | "int16_t" | "int32_t" | "int64_t" | "uint8_t" | "uint16_t" | "uint32_t"| "uint64_t" | "joaat_t" | "float" | "byte" Used internally to define the data type so that SizeOf or the internal __sizeof can immediately lookup the size without invoking integer inference.

--#endregion

--#region Primitives

-- Time in seconds.
---@class seconds: number
-- Time in milliseconds.
---@class milliseconds: number
---@class int8_t: integer
---@class int16_t: integer
---@class int32_t: integer
---@class int64_t: integer
---@class uint8_t: integer
---@class uint16_t: integer
---@class uint32_t: integer
---@class uint64_t: integer
---@class joaat_t: uint32_t
---@class byte: int8_t
---@class float: number
---@class bool: boolean
---@class ID: integer
-- RAGE entity script handle
---@class handle: integer
-- RAGE JOAAT hash
---@class hash: joaat_t
---@class pointer_ref
---@field deref fun(self: pointer): pointer|nullptr

---@alias anyval<T> table|metatable|userdata|lightuserdata|function|string|number|boolean Any Lua value except nil.
---@alias optional<T> T?

--#endregion

--#region Functional Types

---@alias Callback function
---@alias Predicate<P1, P2, P3, P4, P5> fun(p1: P1, p2?: P2, p3?: P3, p4?: P4, p5?: P5): boolean
---@alias Comparator<A, B> fun(a: A, b: B): boolean

---@type boolean
_G.FAKE_YIMAPI = _G.FAKE_YIMAPI or false

--#endregion

do
	---@class nullptr : pointer
	local nullptr <const>     = {}
	local NOP <const>         = function() end -- there's also a global no-op function but it gets defined after we load this file.
	local RET_ZERO <const>    = function() return 0 end
	local RET_NULL <const>    = function() return "" end
	local RET_NULLPTR <const> = function() return nullptr end
	local RET_TRUE <const>    = function() return true end
	local RET_FALSE <const>   = function() return false end
	local THROW <const>       = function() error("Attempt to dereference a null pointer.", 2) end
	local CONST_THROW <const> = function() error("Attempt to modify nullptr", 2) end
	local TOSTRING <const>    = function() return "nullptr" end
	local __null_idx <const>  = {
		is_valid    = RET_FALSE,
		is_null     = RET_TRUE,
		get_address = RET_ZERO,
		set_address = NOP,
		deref       = THROW,
		rip         = RET_NULLPTR,
		add         = RET_NULLPTR,
		sub         = RET_NULLPTR,
		new         = RET_NULLPTR,
	}


	local sol_ptr_mt = getmetatable(memory.pointer)
	if (sol_ptr_mt) then
		for k, v in pairs(sol_ptr_mt) do
			if (type(k) ~= "string" or __null_idx[k] or type(v) ~= "function") then
				goto continue
			end

			local sub = k:sub(1, 3)
			if (sub == "set") then
				__null_idx[k] = NOP
			elseif (sub == "get") then
				__null_idx[k] = (k == "get_string") and RET_NULL or RET_ZERO
			else
				__null_idx[k] = v
			end

			::continue::
		end
	end

	local __null_mt <const> = {
		__index     = __null_idx,
		__newindex  = CONST_THROW,
		__tostring  = TOSTRING,
		__metatable = false
	}; setmetatable(nullptr, __null_mt); _G.nullptr = nullptr
end
