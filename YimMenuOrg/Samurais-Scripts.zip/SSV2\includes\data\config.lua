-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


---@class Config
local Config <const> = {
	backend = {
		debug_mode = false,
		auto_cleanup_entities = false,
		language_index = 1,
		use_game_language = false
	},
	ui = {
		disable_tooltips = false,
		disable_sound_feedback = false,
		moveable = false,
		style = {
			bg_alpha = 0.7,
		},
		window_size = {
			__type = "vec2",
			x = 864,
			y = 864,
		},
		window_pos = {
			__type = "vec2",
			x = 0,
			y = 0,
		},
		last_tab = {
			tab_id = 1,
			array_index = 1,
		}
	},
	commands_console = {
		key = "F4",
		auto_close = false,
	},
	keyboard_keybinds = {
		gui_toggle        = "F5",
		kill_all_enemies  = "F7",
		enemies_flee      = "F8",
		-- missile_defence  = "F9",
		cobra_maneuver    = "X",
		flatbed           = "X",
		laser_sights      = "L",
		nos               = "MOUSE5",
		rolling_launch    = "N",
		panik             = "F12",
		nos_purge         = "X",
		rod               = "X",
		drift_mode        = "SHIFT",
		-- trigger_bot      = "SHIFT",
		veh_mine          = "NUMPAD0",
		stop_anim         = "G",
		shift_up          = "NUMPAD9",
		shift_down        = "NUMPAD3",
		clutch            = "NUMPAD5",
		engine_start_stop = "NUMPAD1",
	},
	gamepad_keybinds = {
		flatbed           = {
			code = 288,
			name = "A"
		},
		laser_sights      = {
			code = 303,
			name = "DPAD UP"
		},
		nos               = {
			code = 289,
			name = "X"
		},
		nos_purge         = {
			code = 288,
			name = "A"
		},
		rod               = {
			code = 288,
			name = "A"
		},
		drift_mode        = {
			code = 288,
			name = "A"
		},
		-- trigger_bot = {
		-- 	code = 0,
		-- 	name = "Unbound"
		-- },
		veh_mine          = {
			code = 0,
			name = "Unbound"
		},
		stop_anim         = {
			code = 0,
			name = "Unbound"
		},
		rolling_launch    = {
			code = 0,
			name = "Unbound"
		},
		shift_up          = {
			code = 0,
			name = "Unbound"
		},
		shift_down        = {
			code = 0,
			name = "Unbound"
		},
		clutch            = {
			code = 0,
			name = "Unbound"
		},
		engine_start_stop = {
			code = 0,
			name = "Unbound"
		},
	},
	features = {
		self = {
			phone_anims = false,
			mc_alt_bike_anims = false,
			sprint_inside_interiors = false,
			jacking_always_lockpick_anim = false,
			disable_action_mode = false,
			allow_headprops_in_vehicles = false,
			stand_on_veh_roof = false,
			no_carjacking = false,
			crouch = false,
			hands_up = false,
			rod = false,
			clumsy = false,
			ragdoll_sound = false,
			autoheal = {
				enabled = false,
				regen_speed = 1
			},
		},
		vehicle = {
			nos = {
				enabled = false,
				power = 50,
				screen_effect = false,
				sound_effect = false,
				purge = false,
				can_damage_engine = false
			},
			drift = {
				enabled = false,
				mode = 0,
				intensity = 1,
				power = 50,
				smoke_fx = {
					enabled = false,
					color = {
						__type = "vec3",
						x = 1,
						y = 1,
						z = 1,
					}
				},
			},
			default_station = {
				enabled = false,
				station_name = "OFF",
				display_name = "Off"
			},
			manual_gearbox = {
				enabled = false,
				disable_stalling = false,
				mode = 0, ---@type eManualGearboxType
			},
			bangs_rpm_max = 9000.0,
			bangs_rpm_min = 4000.0,
			performance_only = false,
			burble_tune = false,
			launch_control = false,
			launch_control_mode = 0,
			abs_lights = false,
			subwoofer = false,
			horn_beams = false,
			fast_vehicles = false,
			fast_vehicles_speed = 10,
			auto_brake_lights = false,
			iv_exit = false,
			no_wheel_recenter = false,
			no_carjacking = false,
			unbreakable_windows = false,
			flappy_doors = false,
			rgb_lights = {
				enabled = false,
				speed = 1,
			},
			mines = {
				enabled = false,
				selected_type_hash = -647126932, -- spike mines default
				name = nil ---@type string?
			},
			missile_defence = false,
			strong_crash = false,
			auto_lock_doors = false,
			cobra_maneuver = false,
			fast_jets = false,
			fast_jets_speed = 150.0,
			no_jet_stall = false,
			no_turbulence = false,
			aircraft_mg = {
				triggerbot = false,
				tiggerbot_range = 200.0,
				manual_aim = false,
				enemies_only = false,
				marker_size = 1.6,
				marker_color = {
					__type = "vec4",
					x = 0,
					y = 1,
					z = 0,
					w = 1,
				}
			},
			flares = false,
			drift_minigame = {
				enabled = false,
				score_sound = false,
				player_best = 0
			},
			no_engine_brake = false,
			kers_boost = false,
			offroad_abilities = false,
			rallye_tyres = false,
			no_traction_control = false,
			low_speed_wheelies = false,
			rocket_boost = false,
			jump_capability = false,
			parachute = false,
			steer_rear_wheels = false,
			steer_handbrake = false,
			stancer = { auto_apply_saved = false, },
		},
		speedometer = {
			enabled = false,
			speed_unit = 0,
			radius = 160,
			pos = {
				__type = "vec2",
				x = 0.0,
				y = 0.0
			},
			colors = {
				circle = 0xFF313195,
				circle_bg = 0x66090909,
				markings = 0xFFC7C7C7,
				text = 0xDDFFFFFF,
				needle = 0xFF3636FF,
				needle_base = 0xFF111111,
			},
		},
		flatbed = {
			enabled = false,
			tow_everything = false,
			show_towing_position = false,
			show_esp = false,
		},
		weapon = {
			magic_bullet = false,
			laser_sights = {
				enabled = false,
				keybind = "L",
				ray_length = 500,
				color = {
					__type = "vec4",
					x = 1,
					y = 0,
					z = 0,
					w = 0.9
				}
			},
			katana = {
				enabled = false,
				model = 0x958A4A8F,
				name = "Baseball Bat"
			},
		},
		world = {
			hide_n_seek = false,
			disable_ocean_waves = false,
			extend_bounds = false,
			disable_flight_music = false,
			disable_wanted_music = false,
			carpool = false,
			public_enemy = false,
			kamikaze_drivers = false,
		},
		dunk = {
			bypass_casino_bans = false,
			force_poker_cards = false,
			set_dealers_poker_cards = false,
			force_roulette_wheel = false,
			rig_slot_machine = false,
			autoplay_slots = false,
			cap_slot_machine_chips = false,
			ch_cart_autograb = false,
			autoplay_slots_delay_random = false,
			slot_machine_cap = 0,
			autoplay_slots_delay = 500,
		},
		yim_heists = {
			cfr_cd = false,
			knoway_cd = false,
			dre_cd = false,
			ogfa_cd = false,
			cayo_cd = false,
			dday_cd = false,
		},
		yrv3 = {
			autofill_delay = 500,
			auto_sell = false,
			hangar_cd = false,
			nc_management_cd = false,
			nc_vip_mission_chance = false,
			security_missions_cd = false,
			ie_vehicle_steal_cd = false,
			ie_vehicle_sell_cd = false,
			ceo_crate_buy_cd = false,
			ceo_crate_sell_cd = false,
			dax_work_cd = false,
			garment_rob_cd = false,
			cwash_legal_work_cd = false,
			cwash_illegal_work_cd = false,
			weedshop_legal_work_cd = false,
			weedshop_illegal_work_cd = false,
			helitours_legal_work_cd = false,
			helitours_illegal_work_cd = false,
			nc_always_popular = false,
			sy_always_max_income = false,
			sy_disable_rob_cd = false,
			sy_disable_rob_weekly_cd = false,
			sy_disable_tow_cd = false,
			unsafe_feats_enabled = false,
			office_clutter = {
				auto_disable = false,
				items = {
					cash             = false,
					Swag_Silver      = false,
					Swag_Pills       = false,
					Swag_Med         = false,
					Swag_JewelWatch  = false,
					Swag_Ivory       = false,
					Swag_Guns        = false,
					Swag_Gems        = false,
					Swag_Furcoats    = false,
					Swag_electronic  = false,
					Swag_DrugStatue  = false,
					Swag_DrugBags    = false,
					Swag_Counterfeit = false,
					Swag_Booze_cigs  = false,
					Swag_Art         = false,
				}
			}
		},
		yim_actions = {
			auto_close_ped_window = false,
			disable_props = false,
			disable_ptfx = false,
			disable_sfx = false,
		},
	},
}

return Config
