---@class CBoatHandlingData : CBaseSubHandlingData
local CBoatHandlingData = {}
CBoatHandlingData.__index = CBoatHandlingData

return CBoatHandlingData
