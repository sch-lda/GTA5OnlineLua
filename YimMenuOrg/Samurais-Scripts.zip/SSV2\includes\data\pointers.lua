-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


PatternScanner = require("includes.services.PatternScanner")

--- A place to store functions returned from `memory.dynamic_call`
---@class DynamicFuncs
---@field BreakOffVehicleWheel? fun(pVehicleDamage: pointer<CVehicleDamage>, wheelIdx: integer, ptfxChance: float, deleteChance: float, burstChance: float, setOnFire: bool, isNetwork: bool)

-- ### A place to store pointers globally.
--
-- You can add new indexes to this global table from any other file
--
-- as long as it's loaded before `GPointers:Init()` is called *(bottom of init.lua)*.
--
-- **NOTE:** Please make sure no modules/files try to use a pointer before the scan is complete.
--
-- You can call `PatternScanner:IsDone()` to double check.
---@class GPointers
---@field ScriptGlobals pointer
---@field GameState pointer<byte>
---@field GameTime pointer<uint32_t>
---@field GameVersion VersionInfo
---@field ScreenResolution vec2
---@field DynamicFuncs DynamicFuncs
local GPointers = {
	Init             = function() PatternScanner:Scan() end,
	Retry            = function() PatternScanner:RetryScan() end,
	ScriptGlobals    = nullptr,
	GameState        = nullptr,
	GameTime         = nullptr,
	GameVersion      = { build = "", online = "" },
	ScreenResolution = vec2:zero(),
}

GPointers.DynamicFuncs = {}


---@class MemoryBatch
---@field m_name string
---@field m_pattern string
---@field m_callback fun(ptr: pointer)
local MemoryBatch <const> = {}
MemoryBatch.__index = MemoryBatch
---@param name string
---@param ida_sig string
---@param callback fun(ptr: pointer)
function MemoryBatch.new(name, ida_sig, callback)
	return {
		m_name     = name,
		m_pattern  = ida_sig,
		m_callback = callback
	}
end

---@type table<eAPIVersion, array<MemoryBatch>>
local mem_batches <const> = {
	[Enums.eAPIVersion.V1] = {
		MemoryBatch.new("ScriptGlobals", "48 8D 15 ? ? ? ? 4C 8B C0 E8 ? ? ? ? 48 85 FF 48 89 1D", function(ptr)
			GPointers.ScriptGlobals = ptr:add(0x3):rip()
		end),
		MemoryBatch.new("GameVersion", "8B C3 33 D2 C6 44 24 20", function(ptr)
			local pGameBuild = ptr:add(0x24):rip()
			local pOnlineVersion = pGameBuild:add(0x20)
			GPointers.GameVersion = {
				build  = pGameBuild:get_string(),
				online = pOnlineVersion:get_string()
			}
		end),
		MemoryBatch.new("GameState", "81 39 5D 6D FF AF 75 20", function(ptr)
			GPointers.GameState = ptr:add(0xA):rip():add(0x1)
		end),
		MemoryBatch.new("GameTime", "8B 05 ? ? ? ? 89 ? 48 8D 4D C8", function(ptr)
			GPointers.GameTime = ptr:add(0x2):rip()
		end),
		MemoryBatch.new("ScreenResolution", "66 0F 6E 0D ? ? ? ? 0F B7 3D", function(ptr)
			GPointers.ScreenResolution = vec2:new(
				ptr:sub(0x4):rip():get_word(),
				ptr:add(0x4):rip():get_word()
			)
		end),

		-- TODO: enable once dynamic calls become stable. For now either the JIT compiler is broken or I'm just outright stupid.
		-- MemoryBatch.new("BreakOffVehicleWheel", "F3 44 0F 11 4C 24 ? E8 ? ? ? ? EB 7A", function(ptr)
		-- 	local func_ptr = ptr:add(0x7)
		-- 	local func_name = memory.dynamic_call(
		-- 		"void",
		-- 		{ "void*", "uint32_t", "float", "float", "float", "bool", "bool" },
		-- 		func_ptr
		-- 	)

		-- 	GPointers.DynamicFuncs.BreakOffVehicleWheel = _G[func_name]
		-- end),
	},
	[Enums.eAPIVersion.V2] = {
		MemoryBatch.new("ScriptGlobals", "48 8B 8E B8 00 00 00 48 8D 15 ? ? ? ? 49 89 D8", function(ptr)
			GPointers.ScriptGlobals = ptr:add(0x7):add(0x3):rip()
		end),
		MemoryBatch.new("GameVersion", "4C 8D 0D ? ? ? ? 48 8D 5C 24 ? 48 89 D9 48 89 FA", function(ptr)
			GPointers.GameVersion = {
				build  = ptr:add(0x3):rip():get_string(),
				online = ptr:add(0x47):add(0x3):rip():get_string()
			}
		end),
		MemoryBatch.new("GameState", "83 3D ? ? ? ? ? 0F 85 ? ? ? ? BA ? 00", function(ptr)
			GPointers.GameState = ptr:add(0x2):rip():add(0x1)
		end),
		MemoryBatch.new("ScreenResolution", "75 39 0F 57 C0 F3 0F 2A 05", function(ptr)
			GPointers.ScreenResolution = vec2:new(
				ptr:add(0x5):add(0x4):rip():get_word(),
				ptr:add(0x1E):add(0x4):rip():get_word()
			)
		end),
	},
	[Enums.eAPIVersion.L54] = { --[[dummy]] },
}

local API_VERSON <const> = Backend:GetAPIVersion()
local batches = mem_batches[API_VERSON]
for _, batch in ipairs(batches) do
	PatternScanner:Add(batch.m_name, batch.m_pattern, batch.m_callback)
end

return GPointers
