-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


return {
	tuneables_global = {
		description = "Tuneables (never changed)",
		file = "tuneables_processing.c",
		LEGACY = {
			value = 262145,
			pattern = [[switch \((Global_\w{6})\.f_\w{4}\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 262145,
			pattern = [[switch \((Global_\w{6})\.f_\w{4}\)]],
			capture_group = 1
		}
	},
	gpbd = {
		description = [[ GlobalPlayerBD
		Used in the project to get the status of Service Vehicles.
		To find bitsets:
		> freemode.c func_15166
		> 	Global_2733138.f_XXX ;; i.e. 613 for Kosatka, 592 for Acid Lab
		> 		func_15202(blah, blah, blah, THIS_NUMBER_IS_YOUR_BITSET_OFFSET);

		Scrolling through offsets for Vectors has revealed that this has the coords of:
		- Super Yacht @ offset -48
		- Kosatka/Terrorbyte/MOC @ offset +13
		- Acid Lab @ offset +75	
		]],
		file = "freemode.c",
		LEGACY = {
			value = 2658293,
			pattern = [[MISC::SET_BIT\(&\(Global_(\d{7})\[PLAYER::PLAYER_ID\(\) /\*(\d{3})\*/\]\.(f_\d{3})\.f_\d{1}\), 31\);]],
			capture_group = 1,
			offsets = {
				{
					value = 468,
					capture_group = 2,
					description = "playerID read size."
				},
				{
					value = 325,
					capture_group = 3
				}
			}
		},
		ENHANCED = {
			value = 2658296,
			pattern = [[MISC::SET_BIT\(&\(Global_(\d{7})\[PLAYER::PLAYER_ID\(\) /\*(\d{3})\*/\]\.(f_\d{3})\.f_\d{1}\), 31\);]],
			capture_group = 1,
			offsets = {
				{
					value = 468,
					capture_group = 2,
					description = "playerID read size."
				},
				{
					value = 325,
					capture_group = 3
				}
			}
		}
	},
	gpbd_fm_3 = {
		description = "GPBD_FM_3",
		file = "freemode.c",
		LEGACY = {
			value = 1892925,
			pattern = [[\w+\(&\(Global_(\d{7})\[.*?/\*(\d+)\*/\]\.f_10\.f_343\), \w+, 64\);]],
			capture_group = 1,
			offsets = {
				{
					value = 615,
					capture_group = 2,
					description = "player id size"
				}
			}
		},
		ENHANCED = {
			value = 1893070,
			pattern = [[\w+\(&\(Global_(\d{7})\[.*?/\*(\d+)\*/\]\.f_10\.f_343\), \w+, 64\);]],
			capture_group = 1,
			offsets = {
				{
					value = 615,
					capture_group = 2,
					description = "player id size"
				}
			}
		}
	},
	freemode_business_global = {
		description = "Freemode Business Global",
		file = "freemode.c",
		LEGACY = {
			value = 1673813,
			pattern = [[if.*?Global_\d{7}\[.*?\] != 0 && func_\w+\(.*?\) && \w+\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1673820,
			pattern = [[if.*?Global_\d{7}\[.*?\] != 0 && func_\w+\(.*?\) && \w+\)]],
			capture_group = 1
		}
	},
	personal_vehicle_global = {
		description = "Personal Vehicle Global",
		file = "freemode.c",
		LEGACY = {
			value = 1572199,
			pattern = [[if \(VEHICLE::GET_IS_VEHICLE_ENGINE_RUNNING\((Global_\w{7})\)\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1572199,
			pattern = [[if \(VEHICLE::GET_IS_VEHICLE_ENGINE_RUNNING\((Global_\w{7})\)\)]],
			capture_group = 1
		}
	},
	arcade_bhub_global_1 = {
		description = "Arcade Business Hub Global 1",
		file = "apparcadebusinesshub.c",
		LEGACY = {
			value = 1950557,
			pattern = [[else if \(Global_\w{7}\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1951071,
			pattern = [[else if \(Global_\w{7}\)]],
			capture_group = 1
		}
	},
	arcade_bhub_global_2 = {
		description = "Arcade Business Hub Global 2",
		file = "apparcadebusinesshub.c",
		LEGACY = {
			value = 1970624,
			pattern = [[if \(MISC::IS_STRING_NULL_OR_EMPTY\(\w+\) \|\| (Global_\w{7}) ==.*?\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1971195,
			pattern = [[if \(MISC::IS_STRING_NULL_OR_EMPTY\(\w+\) \|\| (Global_\w{7}) ==.*?\)]],
			capture_group = 1
		}
	},
	mp_business_stuff = {
		description = "Business stuff",
		file = "freemode.c",
		LEGACY = {
			value = 1845298,
			pattern = [[Global_(\d{7})\[.*? /\*(\d+)\*/\]\.(f_\d{3}).f_\d{3}\[.*? /\*\d+\*/\].f_9 = .*?;]],
			capture_group = 1,
			offsets = {
				{
					value = 881,
					capture_group = 2,
					description = "playerID read size."
				},
				{
					value = 260,
					capture_group = 3
				}
			}
		},
		ENHANCED = {
			value = 1845347,
			pattern = [[Global_(\d{7})\[.*? /\*(\d+)\*/\]\.(f_\d{3}).f_\d{3}\[.*? /\*\d+\*/\].f_9 = .*?;]],
			capture_group = 1,
			offsets = {
				{
					value = 884,
					capture_group = 2,
					description = "playerID read size."
				},
				{
					value = 260,
					capture_group = 3
				}
			}
		}
	},
	bhub_prod_time_global = {
		description = "Business Hub time left to produce.",
		file = "freemode.c",
		LEGACY = {
			value = 2709062,
			pattern = [[Global_(\d{7})\[.*?\] =.*?Global_\d{7}\[.*?\] +.*?Global_(\d{7})\.(f_1)\[.*?\] - .*?;]],
			capture_group = 1
		},
		ENHANCED = {
			value = 2709197,
			pattern = [[Global_(\d{7})\[.*?\] =.*?Global_\d{7}\[.*?\] +.*?Global_(\d{7})\.(f_1)\[.*?\] - .*?;]],
			capture_group = 1
		}
	},
	bhub_prod_bool_global = {
		description = "Business Hub some production bool. Flips back after production is triggered.",
		file = "freemode.c",
		LEGACY = {
			value = 2709073,
			pattern = [[Global_(\d{7})\[.*?\] =.*?Global_\d{7}\[.*?\] +.*?Global_(\d{7})\.(f_1)\[.*?\] - .*?;]],
			capture_group = 2,
			offsets = {
				{
					value = 1,
					capture_group = 3,
					description = "some int value indexed by hub slot. can't be bothered -_-"
				}
			}
		},
		ENHANCED = {
			value = 2709208,
			pattern = [[Global_(\d{7})\[.*?\] = Global_\d{7}\[.*?\] +.*?Global_(\d{7})\.(f_1)\[.*?\] - .*?;]],
			capture_group = 2,
			offsets = {
				{
					value = 1,
					capture_group = 3,
					description = "some int value indexed by hub slot. can't be bothered -_-"
				}
			}
		}
	},
	car_wash_safe_global = {
		description = "car wash safe global",
		file = "freemode.c",
		LEGACY = {
			value = 1882652,
			pattern = [[Global_(\d{7})\[.*?/\*(\d{3})\*/\]\.f_(\d{3})\.f_27\.f_2 = \w+0;]],
			capture_group = 1,
			offsets = {
				{
					value = 321,
					capture_group = 2,
					description = "player id read size"
				},
				{
					value = 158,
					capture_group = 3,
					description = "car wash entry?"
				}
			}
		},
		ENHANCED = {
			value = 1882797,
			pattern = [[Global_(\d{7})\[.*?/\*(\d{3})\*/\]\.f_(\d{3})\.f_27\.f_2 = \w+0;]],
			capture_group = 1,
			offsets = {
				{
					value = 321,
					capture_group = 2,
					description = "player id read size"
				},
				{
					value = 158,
					capture_group = 3,
					description = "car wash entry?"
				}
			}
		}
	},
	gb_contraband_buy_local_1 = {
		description = "Contraband Buy Local 1",
		file = "gb_contraband_buy.c",
		LEGACY = {
			value = 632,
			pattern = [[switch \(.*?Local_(\d{3})\.f_5]],
			capture_group = 1
		},
		ENHANCED = {
			value = 634,
			pattern = [[switch \(.*?Local_(\d{3})\.f_5]],
			capture_group = 1
		}
	},
	gb_contraband_buy_local_2 = {
		description = "Contraband Buy Local 2",
		file = "fm_content_cargo.c",
		LEGACY = {
			value = 6030,
			pattern = [[Position.*?0x21F25C[^\r\n]*\r?\n\s*\{\r?\n\s*return\s+func.*?Local_(\d{4}),\s*\w+0\);]],
			capture_group = 1
		},
		ENHANCED = {
			value = 6068,
			pattern = [[Position.*?0x22F3DC[^\r\n]*\r?\n\s*\{\r?\n\s*return\s+func.*?Local_(\d{4}),\s*\w+0\);]],
			capture_group = 1
		}
	},
	gb_contraband_buy_local_3 = {
		description = "Contraband Buy Local 3",
		file = "fm_content_cargo.c",
		LEGACY = {
			value = 6149,
			pattern = [[if \(.*?(Local_6\d{3})\.(f_1\d{3}) == 0]],
			capture_group = 1,
			offsets = {
				{
					value = 1180,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 6151,
			pattern = [[if \(.*?(Local_6\d{3})\.(f_1\d{3}) == 0]],
			capture_group = 1,
			offsets = {
				{
					value = 1180,
					capture_group = 2
				}
			}
		}
	},
	gb_contraband_sell_local = {
		description = "Contraband Sell Local",
		file = "gb_contraband_sell.c",
		LEGACY = {
			value = 574,
			pattern = [[MISC::CLEAR_BIT\(&\(.*?Local_(\d{3})\.f_\d{1,2}\), \w+0]],
			capture_group = 1
		},
		ENHANCED = {
			value = 576,
			pattern = [[MISC::CLEAR_BIT\(&\(.*?Local_(\d{3})\.f_\d{1,2}\), \w+0]],
			capture_group = 1
		}
	},
	biker_required_deliveries_local = {
		description = "Biker Contraband Sell Local",
		file = "gb_biker_contraband_sell.c",
		LEGACY = {
			value = 736,
			pattern = [[.*?Local_(\d{3})\.f_(\d{3}) = func_\w+\(-1\);]],
			capture_group = 1,
			offsets = {
				{
					value = 174,
					capture_group = 2,
					description = "expected deliveries."
				}
			}
		},
		ENHANCED = {
			value = 738,
			pattern = [[.*?Local_(\d{3})\.f_(\d{3}) = func_\w+\(-1\);]],
			capture_group = 1,
			offsets = {
				{
					value = 174,
					capture_group = 2,
					description = "expected deliveries."
				}
			}
		}
	},
	biker_deliveries_local = {
		description = "Biker Contraband Sell Local",
		file = "gb_biker_contraband_sell.c",
		LEGACY = {
			value = 736,
			pattern = [[else if \(!func_\w+\(.*?\) &&.*?(Local_\d{3})(\.f_\d{3}) > 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 122,
					capture_group = 2,
					description = "number of deliveries made"
				}
			}
		},
		ENHANCED = {
			value = 738,
			pattern = [[else if \(!func_\w+\(.*?\) &&.*?(Local_\d{3})(\.f_\d{3}) > 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 122,
					capture_group = 2,
					description = "number of deliveries made"
				}
			}
		}
	},
	gb_smuggler_sell_air_local_1 = {
		description = "Hangar Sell Local 1 (air)",
		file = "gb_smuggler.c",
		LEGACY = {
			value = 1996,
			pattern = [[for \(i = 0; i < func_\w{2}\(func_\w{4}\(\), func_\w{2}\(\), .*?(Local_\d{4})\.(f_\d{4}), -1\); i = i \+ 1\)]],
			capture_group = 1,
			offsets = {
				{
					value = 1035,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 1998,
			pattern = [[for \(i = 0; i < func_\w{2}\(func_\w{4}\(\), func_\w{2}\(\), .*?(Local_\d{4})\.(f_\d{4}), -1\); i = i \+ 1\)]],
			capture_group = 1,
			offsets = {
				{
					value = 1035,
					capture_group = 2
				}
			}
		}
	},
	gb_smuggler_sell_air_local_2 = {
		description = "Hangar Sell Local 2 (air)",
		file = "gb_smuggler.c",
		LEGACY = {
			value = 1996,
			pattern = [[if .*?(Local_\d{4})\.(f_\d{4}) > 0 && func_.*?&.*?Local_\d{4}\.f_\d{4}\), 30000, \w+]],
			capture_group = 1,
			offsets = {
				{
					value = 1078,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 1998,
			pattern = [[if .*?(Local_\d{4})\.(f_\d{4}) > 0 && func_.*?&.*?Local_\d{4}\.f_\d{4}\), 30000, \w+]],
			capture_group = 1,
			offsets = {
				{
					value = 1078,
					capture_group = 2
				}
			}
		}
	},
	gb_gunrunning_sell_local = {
		description = "Bunker Sell Local 1",
		file = "gb_gunrunning.c",
		LEGACY = {
			value = 1273,
			pattern = [[Local_1\d{3}\.f_\d{3} = func_\w+\(func_\w+\(\),.*?(Local_1\d{3})\.(f_\d{3}), \w+, -1\);]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1275,
			pattern = [[Local_1\d{3}\.f_\d{3} = func_\w+\(func_\w+\(\),.*?(Local_1\d{3})\.(f_\d{3}), \w+, -1\);]],
			capture_group = 1
		}
	},
	bunker_sell_amt_delivered = {
		description = "Amount delivered.",
		file = "gb_gunrunning.c",
		LEGACY = {
			value = 1273,
			pattern = [[func_\w+\(.*?Local_(\d{4})\.f_(\d{3}), \w+, "GR_HUD_TOT".*?, 255, 0\);]],
			capture_group = 1,
			offsets = {
				{
					value = 816,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 1275,
			pattern = [[func_\w+\(.*?Local_(\d{4})\.f_(\d{3}), \w+, "GR_HUD_TOT".*?, 255, 0\);]],
			capture_group = 1,
			offsets = {
				{
					value = 816,
					capture_group = 2
				}
			}
		}
	},
	bunker_sell_num_vehs = {
		description = "Number of delivery vehicles.",
		file = "gb_gunrunning.c",
		LEGACY = {
			value = 1273,
			pattern = [[for \(i = 0; i < func_\w+\(func_\w+\(\), func_\w+\(\),.*?(Local_\d{4})(\.f_\d{3}),.*?Local_\d{4}\.f_\d{3}\); i = i \+ 1\)]],
			capture_group = 1,
			offsets = {
				{
					value = 774,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 1275,
			pattern = [[for \(i = 0; i < func_\w+\(func_\w+\(\), func_\w+\(\),.*?(Local_\d{4})(\.f_\d{3}),.*?Local_\d{4}\.f_\d{3}\); i = i \+ 1\)]],
			capture_group = 1,
			offsets = {
				{
					value = 774,
					capture_group = 2
				}
			}
		}
	},
	acid_lab_sell_deliveries_local = {
		description = "Acid Lab Deliveries. This shit is pissing me off and my dumbass doesn't know how to use scrDBG without creating a bazillion GB log file.",
		file = "fm_content_acid_lab_sell.c",
		LEGACY = {
			value = 151,
			pattern = [[if \(.*?Local_(\d{3})\.f_(\d{1}) !=.*?Local_\d{3}\.f_\d{4}\[0 /\*6\*/\]\.f_2\)]],
			capture_group = 1,
			offsets = {
				{
					value = 9,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 153,
			pattern = [[if \(.*?Local_(\d{3})\.f_(\d{1}) !=.*?Local_\d{3}\.f_\d{4}\[0 /\*6\*/\]\.f_2\)]],
			capture_group = 1,
			offsets = {
				{
					value = 9,
					capture_group = 2
				}
			}
		}
	},
	acid_lab_sell_mission_state_local = {
		description = "Acid Lab Mission State",
		file = "fm_content_acid_lab_sell.c",
		LEGACY = {
			value = 5758,
			pattern = [[if \(.*?Local_(5\d{3})(\.f_\d{4}) == 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 1339,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 5760,
			pattern = [[if \(.*?Local_(5\d{3})(\.f_\d{4}) == 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 1339,
					capture_group = 2
				}
			}
		}
	},
	acid_lab_sell_gen_bs = {
		description = "Acid Lab Sell Generic Bitset",
		file = "fm_content_acid_lab_sell.c",
		LEGACY = {
			value = 5632,
			pattern = [[func_\w{3}\(&.?(Local_5\d+), \w+\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 5634,
			pattern = [[func_\w{3}\(&.?(Local_5\d+), \w+\)]],
			capture_group = 1
		}
	},
	three_card_poker_table = {
		description = "Three Card Poker Table Local",
		file = "three_card_poker.c",
		LEGACY = {
			value = 778,
			pattern = [[if \(.*?Local_(\d{3})\[.*? /\*(\d+)\*/\]\.f_\d+ ==.*?&&.*?Local_\d{3}\[.*?\]\.f_\d+ > 0 \|\| .*?Local_\d{3}\[.*?\]\.f_\d+ > 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 9,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 780,
			pattern = [[if \(.*?Local_(\d{3})\[.*? /\*(\d+)\*/\]\.f_\d+ ==.*?&&.*?Local_\d{3}\[.*?\]\.f_\d+ > 0 \|\| .*?Local_\d{3}\[.*?\]\.f_\d+ > 0\)]],
			capture_group = 1,
			offsets = {
				{
					value = 9,
					capture_group = 2
				}
			}
		}
	},
	three_card_poker_cards = {
		description = "Three Card Poker Cards Local",
		file = "three_card_poker.c",
		LEGACY = {
			value = 145,
			pattern = [[STREAMING::REQUEST_MODEL\(func_\d+\(.*?Local_(\d{3})(\.f_\d{3})\[.*?\]\.f_\d+\[.*?\], .*?Local_\d{4}\.f_\d+\)\);]],
			capture_group = 1,
			offsets = {
				{
					value = 168,
					capture_group = 2,
					description = "current deck"
				}
			}
		},
		ENHANCED = {
			value = 147,
			pattern = [[STREAMING::REQUEST_MODEL\(func_\d+\(.*?Local_(\d{3})(\.f_\d{3})\[.*?\]\.f_\d+\[.*?\], .*?Local_\d{4}\.f_\d+\)\);]],
			capture_group = 1,
			offsets = {
				{
					value = 168,
					capture_group = 2,
					description = "current deck"
				}
			}
		}
	},
	three_card_poker_deck_size = {
		description = "Three Card Poker Deck Size",
		file = "three_card_poker.c",
		LEGACY = {
			value = 55,
			pattern = [[if \(!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID\(.*?Local_\d{3}(\.f_\d{2})\[\w+\(\w+, 0\)\]\)\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 55,
			pattern = [[if \(!NETWORK::NETWORK_HAS_CONTROL_OF_NETWORK_ID\(.*?Local_\d{3}(\.f_\d{2})\[\w+\(\w+, 0\)\]\)\)]],
			capture_group = 1
		}
	},
	three_card_poker_anti_cheat = {
		description = "Three Card Poker Anti Cheat",
		file = "three_card_poker.c",
		LEGACY = {
			value = 1067,
			pattern = [[if \(.*?(Local_\d{4})(\.f_\d{3})\.f_\d+\[.*?\] !=.*?Local_\d{3}\.f_\d+\[PLAYER::PLAYER_ID\(\) .*?\]\.f_1\[.*?\]\)]],
			capture_group = 1,
			offsets = {
				{
					value = 856,
					capture_group = 2,
					description = "anti cheat deck"
				}
			}
		},
		ENHANCED = {
			value = 1069,
			pattern = [[if \(.*?(Local_\d{4})(\.f_\d{3})\.f_\d+\[.*?\] !=.*?Local_\d{3}\.f_\d+\[PLAYER::PLAYER_ID\(\) .*?\]\.f_1\[.*?\]\)]],
			capture_group = 1,
			offsets = {
				{
					value = 856,
					capture_group = 2,
					description = "anti cheat deck"
				}
			}
		}
	},
	blackjack_table_players = {
		description = "Blackjack Table Players Local",
		file = "blackjack.c",
		LEGACY = {
			value = 1805,
			pattern = [[if \(.*?Local_\d{4}\[.*?/\*(\d+)\*/\]\.f_\d+ == \w+ && \w+\(.*?Local_\d{4}\[.*?\], \d+\)\)]],
			capture_group = 2,
			offsets = {
				{
					value = 8,
					capture_group = 1
				}
			}
		},
		ENHANCED = {
			value = 1807,
			pattern = [[if \(.*?Local_\d{4}\[.*?/\*(\d+)\*/\]\.f_\d+ == \w+ && \w+\(.*?Local_\d{4}\[.*?\], \d+\)\)]],
			capture_group = 2,
			offsets = {
				{
					value = 8,
					capture_group = 1
				}
			}
		}
	},
	blackjack_cards = {
		description = "Blackjack Cards Local",
		file = "blackjack.c",
		LEGACY = {
			value = 145,
			pattern = [[if \(func_\w+\(.*?(Local_\d{3})(\.f_\d{3})\[.*?\]\) == 10 \|\| func_\d+\(.*?Local_\d{3}\.f_\d{3}\[.*?\]\) == 11\)]],
			capture_group = 1,
			offsets = {
				{
					value = 846,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 147,
			pattern = [[if \(func_\w+\(.*?(Local_\d{3})(\.f_\d{3})\[.*?\]\) == 10 \|\| func_\d+\(.*?Local_\d{3}\.f_\d{3}\[.*?\]\) == 11\)]],
			capture_group = 1,
			offsets = {
				{
					value = 846,
					capture_group = 2
				}
			}
		}
	},
	roulette_master_table = {
		description = "Roulette Master Table Local",
		file = "casinoroulette.c",
		LEGACY = {
			value = 153,
			pattern = [[NETWORK::NETWORK_REGISTER_HOST_BROADCAST_VARIABLES\(&\(.*?(Local_\d{3})(\.f_\d{4})\), 295, 0\);]],
			capture_group = 1,
			offsets = {
				{
					value = 1357,
					capture_group = 2,
					description = "roulette outcomes table"
				}
			}
		},
		ENHANCED = {
			value = 155,
			pattern = [[NETWORK::NETWORK_REGISTER_HOST_BROADCAST_VARIABLES\(&\(.*?(Local_\d{3})(\.f_\d{4})\), 295, 0\);]],
			capture_group = 1,
			offsets = {
				{
					value = 1357,
					capture_group = 2,
					description = "roulette outcomes table"
				}
			}
		}
	},
	roulette_ball_table_offset = {
		description = "Roulette Ball Table Offset",
		file = "casinoroulette.c",
		LEGACY = {
			value = 153,
			pattern = [[\w+\.f_1 = \w+->f_\d{4}(\.f_\d{3})\[.*?\];]],
			capture_group = 1
		},
		ENHANCED = {
			value = 153,
			pattern = [[\w+\.f_1 = \w+->f_\d{4}(\.f_\d{3})\[.*?\];]],
			capture_group = 1
		}
	},
	slots_random_result_table = {
		description = "Slots Random Results Table Local",
		file = "casino_slots.c",
		LEGACY = {
			value = 1379,
			pattern = [[\w+ = func_\d+\(.*?(Local_\d{4})\.f_1\[.*?\]\[.*?Local_\d+\[0\]\], .*?Local_\d+?\.f_1\[.*?\]\[.*?Local_\d+\[1\]\], .*?Local_\d{4}\.f_1\[.*?\]\[.*?Local_\d+\[2\]\]\);]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1381,
			pattern = [[\w+ = func_\d+\(.*?(Local_\d{4})\.f_1\[.*?\]\[.*?Local_\d+\[0\]\], .*?Local_\d+?\.f_1\[.*?\]\[.*?Local_\d+\[1\]\], .*?Local_\d{4}\.f_1\[.*?\]\[.*?Local_\d+\[2\]\]\);]],
			capture_group = 1
		}
	},
	slots_slot_machine_state = {
		description = "Slots Slot Machine State",
		file = "casino_slots.c",
		LEGACY = {
			value = 1669,
			pattern = [[MISC::CLEAR_BIT\(&.*?(Local_\d{4}), 18\)]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1671,
			pattern = [[MISC::CLEAR_BIT\(&.*?(Local_\d{4}), 18\)]],
			capture_group = 1
		}
	},
	prize_wheel_win_state = {
		description = "Prize Wheel Win State Local",
		file = "casino_lucky_wheel.c",
		LEGACY = {
			value = 309,
			pattern = [[(Local_\d{3})(\.f_\d{2}) =.*?Local_\d{3}\.f_\d{2} % 20]],
			capture_group = 1,
			offsets = {
				{
					value = 14,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 311,
			pattern = [[(Local_\d{3})(\.f_\d{2}) =.*?Local_\d{3}\.f_\d{2} % 20]],
			capture_group = 1,
			offsets = {
				{
					value = 14,
					capture_group = 2
				}
			}
		}
	},
	prize_wheel_prize_state = {
		description = "Prize Wheel Prize State Offset",
		file = "casino_lucky_wheel.c",
		LEGACY = {
			value = 309,
			pattern = [[if \(.?(Local_\d{3})(\.f_..) >= 5 && .?Local_\d{3}\.f_\d{2} <= 12\)]],
			capture_group = 1,
			offsets = {
				{
					value = 45,
					capture_group = 2
				}
			}
		},
		ENHANCED = {
			value = 311,
			pattern = [[if \(.?(Local_\d{3})(\.f_..) >= 5 && .?Local_\d{3}\.f_\d{2} <= 12\)]],
			capture_group = 1,
			offsets = {
				{
					value = 45,
					capture_group = 2
				}
			}
		}
	},
	gb_casino_heist_planning = {
		description = "Casino Heist Planning Global",
		file = "gb_casino_heist_planning.c",
		LEGACY = {
			value = 1972483,
			pattern = [[!NETWORK::NETWORK_IS_PLAYER_ACTIVE\(Global_\d{7}\.f_\d{4}]],
			capture_group = 1
		},
		ENHANCED = {
			value = 1973762,
			pattern = [[!NETWORK::NETWORK_IS_PLAYER_ACTIVE\(Global_\d{7}\.f_\d{4}]],
			capture_group = 1
		}
	},
	gb_casino_heist_planning_cut_offset = {
		description = "Casino Heist Planning Cut Offset",
		file = "gb_casino_heist_planning.c",
		LEGACY = {
			value = 1497,
			pattern = [[\w+->(f_\d{4})(\.f_\d{3})(\.f_\d{2})\[4\] > 0]],
			capture_group = 1,
			offsets = {
				{
					value = 736,
					capture_group = 2
				},
				{
					value = 92,
					capture_group = 3
				}
			}
		},
		ENHANCED = {
			value = 1497,
			pattern = [[\w+->(f_\d{4})(\.f_\d{3})(\.f_\d{2})\[4\] > 0]],
			capture_group = 1,
			offsets = {
				{
					value = 736,
					capture_group = 2
				},
				{
					value = 92,
					capture_group = 3
				}
			}
		}
	},
	fm_mission_controller_cart_grab = {
		description = "FM Mission Controller Cart Grab Local",
		file = "fm_mission_controller.c",
		LEGACY = {
			value = 10311,
			pattern = [[PED::SET_SYNCHRONIZED_SCENE_RATE\(NETWORK::NETWORK_GET_LOCAL_SCENE_FROM_NETWORK_ID\(.?Local_\d{5}\.f_\d+\), .?(Local_\d{5})(\.f_\d+\))]],
			capture_group = 1,
			offsets = {
				{
					value = 14,
					capture_group = 2,
					description = "scene rate"
				}
			}
		},
		ENHANCED = {
			value = 10713,
			pattern = [[PED::SET_SYNCHRONIZED_SCENE_RATE\(NETWORK::NETWORK_GET_LOCAL_SCENE_FROM_NETWORK_ID\(.?Local_\d{5}\.f_\d+\), .?(Local_\d{5})(\.f_\d+\))]],
			capture_group = 1,
			offsets = {
				{
					value = 14,
					capture_group = 2,
					description = "scene rate"
				}
			}
		}
	},
	ie_objective_local = {
		description = "Import/Export steal auto complete mission.",
		file = "gb_vehicle_export.c",
		LEGACY = {
			value = 887,
			pattern = [[.*?Local_(\d{3})\.f_(459)\s+=\s+\w+;]],
			capture_group = 1,
			offsets = {
				{
					value = 459,
					capture_group = 2,
					description = "Current objective. This hasn't changed in years, hence the reason it's hardcoded in the regex pattern."
				}
			}
		},
		ENHANCED = {
			value = 889,
			pattern = [[.*?Local_(\d{3})\.f_(459)\s+=\s+\w+;]],
			capture_group = 1,
			offsets = {
				{
					value = 459,
					capture_group = 2
				}
			}
		}
	},
	ie_bitset_1 = {
		description = "Import/Export some other array of bits. Hardcoded as well because it hasn't changed either.",
		file = "gb_vehicle_export.c",
		LEGACY = {
			value = 453,
			pattern = [[.*?Local_\d{3}\.f_(453)\.*?]],
			capture_group = 1
		},
		ENHANCED = {
			value = 453,
			pattern = [[.*?Local_\d{3}\.f_(453)\.*?]],
			capture_group = 1
		}
	},
	ie_num_vehs = {
		description = "Import/Export steal number of vehicles.",
		file = "gb_vehicle_export.c",
		LEGACY = {
			value = 650,
			pattern = [[Local_\d{3}\.(f_\d{3})\s+=\s+func_\w+\(func_\w+\(\),.*?Local_\d{3}\.f_\d{3},\s+func_\w+\(func_\d{3}\(\)\)\);]],
			capture_group = 1
		},
		ENHANCED = {
			value = 650,
			pattern = [[Local_\d{3}\.(f_\d{3})\s+=\s+func_\w+\(func_\w+\(\),.*?Local_\d{3}\.f_\d{3},\s+func_\w+\(func_\d{3}\(\)\)\);]],
			capture_group = 1
		}
	},
	ie_steal_bitset = {
		description = [[This stores indices of bitsets??
		It's indexed by the number of targets (size 2, idx from 1 to 4) which is stored in Local_880.f_650.
		Still haven't figured out which bits we need to set.
		Attempts made:
		- Use Arthur's scrDbg to log calls to func_9 and func_140
			- Result: 1.7GB log file that broke my text editor (skill issue on my part).
		- Log the final value after finishing the mission normally and try to directly set it. Feels wrong, bad, and weird but does (kida) work.
			- Result: Mission passes but vehicle won't be stored in our garage.
		]],
		file = "gb_vehicle_export.c",
		LEGACY = {
			value = 48,
			pattern = [[.*?Local_\d{3}\.f_(\d{2})\[.*?/\*(\d+)\*/\]\[\w+\], \w+\);]],
			capture_group = 1,
			offsets = {
				{
					value = 2,
					capture_group = 2,
					description = "read size."
				}
			}
		},
		ENHANCED = {
			value = 48,
			pattern = [[.*?Local_\d{3}\.f_(\d{2})\[.*?/\*(\d+)\*/\]\[\w+\], \w+\);]],
			capture_group = 1,
			offsets = {
				{
					value = 2,
					capture_group = 2,
					description = "read size."
				}
			}
		}
	},
	bb_sell_local = {
		description = "business battles sell local",
		file = "business_battles_sell.c",
		LEGACY = {
			value = 2393,
			pattern = [[if.*?Local_(\d{4})\.f_(\d{3}) -.*?Local_\d{4}\.f_(\d{3}) <= 1 && func_\d+\(28\)]],
			capture_group = 1,
			offsets = {
				{
					value = 203,
					capture_group = 2,
					description = "required deliveries"
				},
				{
					value = 202,
					capture_group = 3,
					description = "deliveries made"
				}
			}
		},
		ENHANCED = {
			value = 2395,
			pattern = [[if.*?Local_(\d{4})\.f_(\d{3}) -.*?Local_\d{4}\.f_(\d{3}) <= 1 && func_\d+\(28\)]],
			capture_group = 1,
			offsets = {
				{
					value = 205,
					capture_group = 2,
					description = "required deliveries"
				},
				{
					value = 204,
					capture_group = 3,
					description = "deliveries made"
				}
			}
		}
	},
	bb_sell_mission_state_offset = {
		description = "business battles sell mission state local",
		file = "business_battles_sell.c",
		LEGACY = {
			value = 25,
			pattern = [[.*?Local_\d{4}\.f_(\d{2})\s*=\s*\w+0;]],
			capture_group = 1
		},
		ENHANCED = {
			value = 27,
			pattern = [[.*?Local_\d{4}\.f_(\d{2})\s*=\s*\w+0;]],
			capture_group = 1
		}
	},
	bb_sell_vehicle_array_offset = {
		description = "business battles sell mission vehicle array",
		file = "business_battles_sell.c",
		LEGACY = {
			value = 32,
			pattern = [[Local_\d{4}\.f_(\d{2})\[i /\*42\*/\]\.f_30 = func_\d{3}\(\);]],
			capture_group = 1
		},
		ENHANCED = {
			value = 34,
			pattern = [[Local_\d{4}\.f_(\d{2})\[i /\*42\*/\]\.f_30 = func_\d{3}\(\);]],
			capture_group = 1
		}
	},
	request_services_global = {
		description = "Request Services Global. Only used for Kosatka atm, same global for all services.",
		file = "am_mp_submarine.c",
		LEGACY = {
			value = 2733190,
			pattern = [[return Global_(\d{7})\.f_371;]],
			capture_group = 1
		},
		ENHANCED = {
			value = 2733326,
			pattern = [[return Global_(\d{7})\.f_371;]],
			capture_group = 1
		}
	}
}
