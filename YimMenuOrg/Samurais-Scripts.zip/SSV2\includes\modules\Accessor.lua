-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


---@enum eAccessorType
Enums.eAccessorType = {
	GLOBAL = 0,
	LOCAL = 1
}

-- Wrapper around native API script global and local accessors but with ease of use and debug-friendliness in mind.
---@class Accessor: ClassMeta<Accessor>
---@field private m_index integer
---@field private m_type eAccessorType
---@field m_script? string
---@field m_path integer[] -- offset chain
---@overload fun(addr: integer, m_type: integer, script?: string): Accessor
local Accessor = Class("Accessor")

--#region Internal

local AccessorDispatch = {
	[Enums.eAccessorType.GLOBAL] = function(self, method, args)
		local callback = globals[method]
		if not callback then
			log.warning(("Attempt to call an unsupported function: globals.%s"):format(method))
			return
		end

		table.insert(args, 1, self:GetIndex())
		return callback(table.unpack(args))
	end,
	[Enums.eAccessorType.LOCAL] = function(self, method, args)
		local callback = locals[method]
		if not callback then
			log.warning(("Attempt to call an unsupported function: locals.%s"):format(method))
			return
		end

		table.insert(args, 1, self:GetIndex())
		table.insert(args, 1, self.m_script)
		return callback(table.unpack(args))
	end,
}

---@param self Accessor
---@param method string
---@param ... any
---@return any
local function Call(self, method, ...)
	if not self:CanAccess() then
		log.warning("Cannot access globals & locals at the moment.")
		return -1
	end

	local args = { ... }
	local dispatcher = AccessorDispatch[self:GetType()]
	if not dispatcher then
		log.warning("Unsupported accessor type")
		return -1
	end
	return dispatcher(self, method, args)
end

---@param base number
---@param accessor_type eAccessorType
---@param script_name? string
---@param path? table
---@return Accessor
function Accessor.new(base, accessor_type, script_name, path)
	assert(type(base) == "number" and base > 0, "Invalid base address!")
	return setmetatable({
			m_index = base,
			m_type = accessor_type or 0,
			m_script = script_name,
			m_path = path or {}
		},
		---@diagnostic disable-next-line
		Accessor
	)
end

---@return boolean
function Accessor:CanAccess()
	return self:GetPointer():is_valid()
end

---@return eAccessorType
function Accessor:GetType()
	return self.m_type
end

---@return uint64_t
function Accessor:GetAddress()
	return self:GetPointer():get_address()
end

---@return integer
function Accessor:GetIndex()
	local addr = self.m_index

	for _, offset in ipairs(self.m_path or {}) do
		addr = addr + offset
	end

	return addr
end

---@param offset integer
---@param size? integer
function Accessor:At(offset, size)
	local newPath = { table.unpack(self.m_path or {}) }
	if (size) then
		offset = 1 + (offset * size)
	end

	table.insert(newPath, offset)
	return Accessor.new(self.m_index, self.m_type, self.m_script, newPath)
end

function Accessor:__tostring()
	local prefix = self.m_type == Enums.eAccessorType.GLOBAL and "Global" or "Local"
	local chain, suffix = "", ""

	for _, offset in ipairs(self.m_path or {}) do
		chain = chain .. ".f_" .. offset
	end

	if (self.m_type == Enums.eAccessorType.LOCAL) and (self.m_script and #self.m_script > 0) then
		suffix = ":" .. self.m_script
	end

	return _F("<%s_%d%s%s>", prefix, self.m_index, chain, suffix)
end

-- Reminder: Keep R/W explicit.
-- Stop trying to be fancy.
-----------------------------
---------- Read -------------
-----------------------------

---@return integer
function Accessor:ReadInt()
	---@type integer
	return Call(self, "get_int")
end

---@return float
function Accessor:ReadFloat()
	---@type float
	return Call(self, "get_float")
end

---@return number -- unsigned integer
function Accessor:ReadUint()
	---@type number
	return Call(self, "get_uint")
end

---@return vec3
function Accessor:ReadVec3()
	---@type vec3
	return Call(self, "get_vec3")
end

---@return string
function Accessor:ReadString()
	---@type string
	return Call(self, "get_string")
end

---@return pointer
function Accessor:GetPointer()
	if self.m_type == Enums.eAccessorType.GLOBAL then
		return globals.get_pointer(self:GetIndex())
	elseif self.m_type == Enums.eAccessorType.LOCAL then
		return locals.get_pointer(self.m_script, self:GetIndex())
	end

	return nullptr
end

---------------------------
---------- Write ----------
---------------------------

---@param value number
function Accessor:WriteInt(value)
	Call(self, "set_int", value)
end

---@param value float
function Accessor:WriteFloat(value)
	Call(self, "set_float", value)
end

---@param value number
function Accessor:WriteUint(value)
	Call(self, "set_uint", value)
end

---@param value vec3
function Accessor:WriteVec3(value)
	Call(self, "set_vec3", value)
end

-- If `maxLen` is provided, writes a fixed-length string.
---@param value string
---@param maxLen? integer
function Accessor:WriteString(value, maxLen)
	if (maxLen) then
		self:GetPointer():set_fixed_string(value, maxLen)
	else
		Call(self, "set_string", value)
	end
end

---------------------------
--------- Bitwise ---------
---------------------------

---@param pos integer
---@return integer
function Accessor:GetBit(pos)
	return self:ReadInt() & (1 << pos)
end

---@param pos integer
function Accessor:SetBit(pos)
	local v = self:ReadInt()
	self:WriteInt(Bit.Set(v, pos))
end

---@param pos integer
function Accessor:ClearBit(pos)
	local v = self:ReadInt()
	self:WriteInt(Bit.Clear(v, pos))
end

---@param bits array<integer> -- bit positions to set
function Accessor:SetBits(bits)
	local v = self:ReadInt()
	for _, pos in ipairs(bits) do
		v = Bit.Set(v, pos)
	end
	self:WriteInt(v)
end

---@param bits array<integer> -- bit positions to clear
function Accessor:ClearBits(bits)
	local v = self:ReadInt()
	for _, pos in ipairs(bits) do
		v = Bit.Clear(v, pos)
	end
	self:WriteInt(v)
end

---@param offset integer
---@param index integer
---@return self, integer
function Accessor:AtPackedBit(offset, index)
	local bucket = index // 32
	local bitPos = index % 32
	return self:At(offset, bucket), bitPos
end

---@param offset integer
---@param bit integer
---@return integer
function Accessor:GetPackedBit(offset, bit)
	local instance, bitPos = self:AtPackedBit(offset, bit)
	return instance:GetBit(bitPos)
end

---@param offset integer
---@param bit integer
function Accessor:SetPackedBit(offset, bit)
	local instance, bitPos = self:AtPackedBit(offset, bit)
	instance:SetBit(bitPos)
end

---@param offset integer
---@param bit integer
function Accessor:ClearPackedBit(offset, bit)
	local instance, bitPos = self:AtPackedBit(offset, bit)
	instance:ClearBit(bitPos)
end

--------------------------------------------------------
--------------------------------------------------------
--------------------------------------------------------
--#endregion


---@class ScriptGlobal : Accessor
---@field At fun(self: ScriptGlobal, offset: integer, size?: integer): ScriptGlobal
---@field __type "ScriptGlobal"
---@overload fun(address: integer): ScriptGlobal
ScriptGlobal = Class("ScriptGlobal", { parent = Accessor })

---@param address integer Global address
---@return ScriptGlobal
function ScriptGlobal.new(address)
	local instance = Accessor.new(address, Enums.eAccessorType.GLOBAL)
	---@diagnostic disable: undefined-field
	instance.__index.__type = "ScriptGlobal"
	---@diagnostic disable-next-line
	return setmetatable(instance, ScriptGlobal)
end

---@class ScriptLocal : Accessor
---@field At fun(self: ScriptLocal, offset: integer, size?: integer): ScriptLocal
---@field ReadString nil
---@field WriteString nil
---@field WriteUint nil
---@field __type "ScriptLocal"
---@overload fun(address: integer, scr: string): ScriptLocal
ScriptLocal = Class("ScriptLocal", { parent = Accessor })
---@diagnostic disable-next-line
setmetatable(ScriptLocal, {
	__call = function(_, addr, scr)
		return ScriptLocal.new(addr, scr)
	end,
	__index = Accessor
})

---@param address integer
---@param script_name string
---@return ScriptLocal
function ScriptLocal.new(address, script_name)
	assert(string.isvalid(script_name), "Invalid script name for ScriptLocal!")
	local instance               = Accessor.new(address, Enums.eAccessorType.LOCAL, script_name)
	---@diagnostic disable: undefined-field
	instance.__index.ReadString  = nil
	instance.__index.WriteString = nil
	instance.__index.WriteUint   = nil
	instance.__index.__type      = "ScriptLocal"

	---@diagnostic disable-next-line
	return setmetatable(instance, ScriptLocal)
end
