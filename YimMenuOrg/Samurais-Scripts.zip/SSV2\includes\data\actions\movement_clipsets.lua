-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


return {
	{ Name = "Arrogant (Female)",  mvmt = "move_f@arrogant@a",                      wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Bodybuilder",        mvmt = "move_m@muscle@a",                        wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Businessman",        mvmt = "move_m@business@a",                      wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Ballistic",          mvmt = "anim_group_move_ballistic",              wmvmt = "anim_group_move_ballistic", strf = "move_strafe@ballistic",                    wanim = "Ballistic" },
	{ Name = "Cop",                mvmt = "move_m@intimidation@cop@unarmed",        wmvmt = nil,                         strf = "move_strafe@cop",                          wanim = "Default" },
	{ Name = "Depressed (Male)",   mvmt = "move_m@depressed@a",                     wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Depressed (Female)", mvmt = "move_f@depressed@a",                     wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Drunk",              mvmt = "move_m@drunk@verydrunk",                 wmvmt = "move_m@drunk@verydrunk",    strf = "move_strafe@first_person@drunk",           wanim = "Hillbilly" },
	{ Name = "Fatass (Male)",      mvmt = "move_m@fat@a",                           wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Fatass (Female)",    mvmt = "move_f@fat@a",                           wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Franklin",           mvmt = "move_p_m_one",                           wmvmt = nil,                         strf = nil,                                        wanim = "Franklin" },
	{ Name = "Gansta",             mvmt = "move_m@gangster@ng",                     wmvmt = nil,                         strf = "move_strafe@gang",                         wanim = "Gang1H" },
	{ Name = "Heels 01",           mvmt = "move_f@heels@c",                         wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Heels 02",           mvmt = "move_f@heels@d",                         wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Hiker (Male)",       mvmt = "move_m@hiking",                          wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Hiker (Female)",     mvmt = "move_f@hiking",                          wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Hipster",            mvmt = "move_m@hipster@a",                       wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "HOBO",               mvmt = "move_m@hobo@a",                          wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Hoe",                mvmt = "move_f@maneater",                        wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Injured (Male)",     mvmt = "move_m@injured",                         wmvmt = nil,                         strf = "move_strafe@injured",                      wanim = "Default" },
	{ Name = "Injured (Female)",   mvmt = "move_f@injured",                         wmvmt = nil,                         strf = "move_strafe@injured",                      wanim = "Female" },
	{ Name = "Jimmy",              mvmt = "move_characters@jimmy@slow@",            wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Lamar",              mvmt = "ANIM_GROUP_MOVE_LEMAR_ALLEY",            wmvmt = nil,                         strf = nil,                                        wanim = "Gang1H" },
	{ Name = "Lester",             mvmt = "move_heist_lester",                      wmvmt = nil,                         strf = nil,                                        wanim = "Hillbilly" },
	{ Name = "Michael",            mvmt = "move_p_m_zero",                          wmvmt = nil,                         strf = nil,                                        wanim = "Michael" },
	{ Name = "Sad",                mvmt = "move_m@sad@a",                           wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Sexy",               mvmt = "move_f@sexy@a",                          wmvmt = nil,                         strf = nil,                                        wanim = "Female" },
	{ Name = "Swag",               mvmt = "move_m@swagger",                         wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Tough",              mvmt = "move_m@tough_guy@",                      wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Trevor",             mvmt = "move_p_m_two",                           wmvmt = nil,                         strf = nil,                                        wanim = "Trevor" },
	{ Name = "Upper Class",        mvmt = "move_m@posh@",                           wmvmt = nil,                         strf = nil,                                        wanim = "Default" },
	{ Name = "Zombie",             mvmt = "clipset@anim@ingame@move_m@zombie@core", wmvmt = nil,                         strf = "clipset@anim@ingame@move_m@zombie@strafe", wanim = "ZOMBIE" },
}
