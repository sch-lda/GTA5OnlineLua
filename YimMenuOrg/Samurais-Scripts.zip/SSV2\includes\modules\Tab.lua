-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local GridRenderer  = require("includes.services.GridRenderer")
local Keybind       = require("includes.structs.Keybind")
local DefaultConfig = Serializer:GetDefaultConfig()

---@class BoolCommandParams
---@field gvar_key string -- A key to insert into GVars (global variables)
---@field on_enable? function
---@field on_disable? function
---@field meta? CommandMeta
---@field register_command? boolean -- register with CommandExecutor
---@field translate_label? boolean If you want to pass a translator key as the label, provide it as is without the `_T` function and set this to true.
---@field global_table? table a table where the bool variable lives (defaults to GVars if available or _G); a local table works as well.
---@field ctx_data? { callback: function, condition?: fun(): boolean } -- adds a gui callback to the small "options" button next to the command's widget

---@class LoopedCommandParams : BoolCommandParams
---@field callback function -- tick function


--------------------------------------
-- Class: Tab
--------------------------------------
---@ignore
---@class Tab : Callable<Tab>
---@field private m_name string
---@field private m_id joaat_t
---@field private m_selected_tab_name string
---@field private m_callback? GuiCallback
---@field private m_subtabs? table<string, Tab>
---@field private m_grid_layout? GridRenderer
---@field private m_has_error boolean
---@field private m_traceback string
---@field public m_has_translator_label boolean
---@overload fun(name: string, callback?: GuiCallback, subtabs?: Tab[], isTranslatorLabel?: boolean) : Tab
local Tab = Callable("Tab")

---@param name string
---@param callback? GuiCallback
---@param subtabs? Tab[]
---@param isTranslatorLabel? boolean If you want to pass a translator key as the label, provide it as is without the `_T` function and set this to true.
---@return Tab
function Tab.new(name, callback, subtabs, isTranslatorLabel)
	subtabs = subtabs or {}
	return setmetatable({
		m_name                 = name,
		m_id                   = _J(_F("%s%s", name, subtabs)),
		m_callback             = callback,
		m_subtabs              = subtabs,
		m_has_error            = false,
		m_has_translator_label = isTranslatorLabel or false
		---@diagnostic disable-next-line
	}, Tab)
end

---@param name string
---@param callback? GuiCallback
---@param subtabs? Tab[]
---@param isTranslatorLabel? boolean If you want to pass a translator key as the label, provide it as is without the `_T` function and set this to true.
---@return Tab
function Tab:RegisterSubtab(name, callback, subtabs, isTranslatorLabel)
	assert(string.isvalid(name), "Attempt to register a new tab with no name.")
	local subtab         = Tab(name, callback, subtabs, isTranslatorLabel)
	self.m_subtabs[name] = subtab
	return subtab
end

---@param callback GuiCallback
function Tab:RegisterGUI(callback)
	if (type(callback) ~= "function") then
		return
	end

	if (self:HasGUI()) then
		log.fwarning("Tab %s already had a GUI callback. Did you mean to overwrite it?", self:GetName())
	end

	self.m_callback = callback
end

---@return boolean
function Tab:HasGUI()
	return (type(self.m_callback) == "function")
end

---@return boolean
function Tab:HasSubtabs()
	return next(self.m_subtabs) ~= nil
end

---@return boolean
function Tab:HasGridLayout()
	return self.m_grid_layout ~= nil
end

---@return number
function Tab:GetTabCount()
	return table.getlen(self.m_subtabs)
end

---@param name string
---@return Tab?
function Tab:GetSubtab(name)
	return self.m_subtabs[name]
end

---@return string
function Tab:GetName()
	return self.m_has_translator_label and _T(self.m_name) or self.m_name
end

---@return joaat_t
function Tab:GetID()
	if (not self.m_id) then
		self.m_id = _J(_F("%s%s", self.m_name, self.m_subtabs))
	end

	return self.m_id
end

---@return GuiCallback
function Tab:GetGUICallback()
	return self.m_callback
end

---@return table<string, Tab>
function Tab:GetSubtabs()
	return self.m_subtabs
end

---@return GridRenderer|nil
function Tab:GetGridRenderer()
	return self.m_grid_layout
end

---@param columns? number
---@param padding_x? number
---@param padding_y? number
---@return GridRenderer
function Tab:GetOrCreateGrid(columns, padding_x, padding_y)
	if (not self.m_grid_layout) then
		local spacing = ImGui.GetStyle().ItemSpacing
		self.m_grid_layout = GridRenderer(
			columns or 1,
			padding_x or spacing.x,
			padding_y or spacing.y
		)
	end

	return self.m_grid_layout
end

function Tab:RemoveGrid()
	self.m_grid_layout = nil
end

function Tab:RemoveGUI()
	self.m_callback = nil
end

---@private
---@param label string
---@param callback function
function Tab:RegisterKeybind(label, callback)
	local saved_keybinds   = GVars.quick_toggle_keybinds
	local default_keybinds = DefaultConfig.quick_toggle_keybinds
	local toggle_keybind   = saved_keybinds[label] or default_keybinds[label]

	if (not toggle_keybind or Keybind.IsRawTable(toggle_keybind)) then
		toggle_keybind        = Keybind.MakeDummy(label)
		saved_keybinds[label] = toggle_keybind
	end

	KeyManager:RegisterKeybind(toggle_keybind, callback)
end

---@param label string
---@param opts BoolCommandParams
function Tab:AddBoolCommand(label, opts)
	opts           = opts or {}
	local gvar_key = opts.gvar_key
	local g_table  = opts.global_table or GVars or _G
	if (type(label) ~= "string" or type(gvar_key) ~= "string") then
		error(_F("[%s]: AddBoolCommand requires a label and global variable key string.", label))
	end

	local function onClick(value)
		if (type(value) ~= "boolean") then
			return
		end

		local onEnable, onDisable = opts.on_enable, opts.on_disable
		if (value and type(onEnable) == "function") then
			onEnable()
		elseif (not value and type(onDisable) == "function") then
			onDisable()
		end
	end

	local meta = opts.meta or {}
	self:GetOrCreateGrid():AddCheckbox(
		label,
		gvar_key,
		{
			persistent        = true,
			tooltip           = meta.description,
			isTranslatorLabel = opts.translate_label,
			contextData       = opts.ctx_data,
			onClick           = function()
				local v = table.get_nested_value(g_table, gvar_key)
				onClick(v)
			end,
		}
	)

	local function toggle()
		local v = table.get_nested_value(g_table, gvar_key)
		v = not v
		table.set_nested_value(g_table, gvar_key, v)
		onClick(v)

		local name = opts.translate_label and _T(label) or label
		Notifier:ShowMessage(name, _F("%s.", v and "Enabled" or "Disabled"))
	end

	if (type(table.get_nested_value(g_table, gvar_key)) ~= "boolean") then
		return
	end

	if (CommandExecutor and opts.register_command) then
		local command_name = label:lower():gsub("%s+", "_")
		CommandExecutor:RegisterCommand(command_name, toggle, meta)
	end

	self:RegisterKeybind(label, toggle)
end

---@param label string
---@param opts LoopedCommandParams
function Tab:AddLoopedCommand(label, opts)
	opts           = opts or {}
	local gvar_key = opts.gvar_key
	local g_table  = opts.global_table or GVars or _G
	if (type(label) ~= "string" or type(gvar_key) ~= "string") then
		error(_F("[%s] AddBoolCommand requires a label and global variable key string.", label))
	end

	local meta             = opts.meta or {}
	local command_name     = label:lower():gsub("%s+", ""):trim()
	local config_value     = table.get_nested_value(g_table, gvar_key)
	local suspended_thread = not config_value
	local thread           = ThreadManager:RegisterLooped(_F("SS_%s", command_name:upper()), opts.callback, { suspended = suspended_thread })

	local function onClick()
		local v = table.get_nested_value(g_table, gvar_key)
		local onDisable = opts.on_disable
		if (v) then
			if thread then thread:Resume() end
		else
			if thread then thread:Suspend() end
			if onDisable then onDisable() end
		end

		local name = opts.translate_label and _T(label) or label
		Notifier:ShowMessage(name, _F("%s.", v and "Enabled" or "Disabled"))
	end

	self:GetOrCreateGrid():AddCheckbox(
		label,
		gvar_key,
		{
			persistent        = true,
			tooltip           = meta.description,
			isTranslatorLabel = opts.translate_label,
			onClick           = onClick,
			contextData       = opts.ctx_data
		}
	)

	local function toggle()
		local v = table.get_nested_value(g_table, gvar_key)
		table.set_nested_value(g_table, gvar_key, not v)
		onClick()
	end

	if (type(table.get_nested_value(g_table, gvar_key)) ~= "boolean") then
		return
	end

	if (opts.register_command and CommandExecutor) then
		CommandExecutor:RegisterCommand(command_name, toggle, meta)
	end

	self:RegisterKeybind(label, toggle)
end

function Tab:Notify(fmt, ...)
	local msg = (... ~= nil) and _F(fmt, ...) or fmt
	Notifier:ShowMessage(self:GetName(), msg, false, 5)
end

---@parivate
function Tab:__DrawImpl()
	if (not self.m_callback) then
		return
	end

	if (self.m_has_error) then
		ImGui.TextColored(0.8, 0.8, 0, 1, _F("Tab '%s' encountered an error. Please contact a developer.", self:GetName()))
		local trace = self.m_traceback
		if (trace) then
			ImGui.Spacing()
			ImGui.BulletText("Traceback most recent call:") -- not an actual trace because Lua's debug is disabled in this sandbox
			ImGui.Indent()
			ImGui.PushTextWrapPos()
			ImGui.TextColored(1, 0, 0, 1, trace)
			ImGui.PopTextWrapPos()
			ImGui.Unindent()
			if (ImGui.Button("Copy Trace")) then
				ImGui.SetClipboardText(trace)
			end
		end
		return
	end

	local ok, err = pcall(self.m_callback)
	if (not ok) then
		log.fwarning("[%s]: Callback error: %s", self:GetName(), err)
		self.m_has_error = true
		self.m_traceback = err
	end
end

function Tab:Draw()
	if (not self:HasSubtabs()) then
		self:__DrawImpl()
		return
	end

	local __next = nil
	if (ImGui.BeginTabBar("##ss_tabs")) then
		local label = _F("%s##%d", self:GetName(), self:GetID())
		if (ImGui.BeginTabItem(label)) then
			self:__DrawImpl()
			ImGui.EndTabItem()
		end

		for _, tab in pairs(self.m_subtabs) do
			local sub_label = _F("%s##%d", tab:GetName(), tab:GetID())
			if (ImGui.BeginTabItem(sub_label)) then
				if (tab:HasSubtabs()) then
					__next = tab
				else
					tab:__DrawImpl()
				end
				ImGui.EndTabItem()
			end
		end
		ImGui.EndTabBar()
	end

	if (__next) then
		__next:Draw()
	end
end

return Tab
