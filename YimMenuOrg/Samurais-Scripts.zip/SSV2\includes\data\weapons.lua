---@diagnostic disable

t_AllWeapons    = {}
t_MeleeWeapons  = {}
t_Handguns      = {}
t_SMG           = {}
t_Shotguns      = {}
t_AssaultRifles = {}
t_MachineGuns   = {}
t_SniperRifles  = {}
t_HeavyWeapons  = {}
t_Throwables    = {}
t_MiscWeapons   = {}
