# /Scripts

A place for helper scripts like doc and translation generators, offset updaters, minifiers, etc...

Usually written in a different language other than Lua but not necessarily.
