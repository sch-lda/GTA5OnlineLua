<!-- markdownlint-disable MD033 -->

# Features

SSV2 includes polished versions of your favorite features from previous versions before the rework plus some new additions.

<details>
  <summary>Table of Contents</summary>
  <ol>
    <li><a href="#self">Self</a></li>
    <li>
      <a href="#vehicle">Vehicle</a>
      <ul>
        <li><a href="#general">General</a></li>
        <li><a href="#aircraft">Aircraft</a></li>
        <li><a href="#stancer">Stancer</a></li>
        <li><a href="#engine-swap">Engine Swap</a></li>
        <li><a href="#handling-editor">Handling Editor</a></li>
        <li><a href="#custom-paint-jobs">Custom Paint Jobs</a></li>
        <li><a href="#flatbed-script">Flatbed Script</a></li>
      </ul>
    </li>
    <li><a href="#world">World</a></li>
    <li>
      <a href="#online">Online</a>
      <ul>
        <li><a href="#yimresupplierv3">YimResupplierV3</a></li>
        <li><a href="#casinopacino">CasinoPacino</a></li>
        <li><a href="#mastermind">Mastermind</a></li>
      </ul>
    </li>
    <li>
      <a href="#extra">Extra</a>
      <ul>
        <li><a href="#yimactionsv3">YimActionsV3</a></li>
        <li><a href="#entityforge">EntityForge</a></li>
        <li><a href="#billionaire-services">Billionaire Services</a></li>
      </ul>
    </li>
  </ol>
</details>

## Self

_Player-centric features affecting movement, combat, and animations._

- **Auto-Heal**

  Constantly refills your health and armor.

- **Enable Phone Animations**

  Restores mobile phone animations in Online mode.

- **MC Riding Style**

  Enables alternate bike riding animations.

  _Usage:_ Automatically applies when riding a motorcycle at low speed.

- **Disable Action Mode**

  Disables the player's forced stance when in combat or wanted by the police.

- **Allow Head Props In Vehicles**

  Allows you to keep your headgear (hats, helmets, masks, etc.) inside vehicles.

- **Stand On Vehicles**

  Prevents you from ragdolling when standing on top of a moving vehicle.

- **No Carjacking**

  Prevents NPCs from carjacking you. Enemies will not try to open your vehicle's door and force you out.

- **Crouch**

  Allows you to crouch.

  _Usage:_ Toggle by pressing **[Left Control]**.

- **Hands Up**

  Allows you to put your hands up _(surrender)_. This replaces the **"Point At"** action in Online.

  _Usage:_ Toggle by pressing **[B]**.

- **Sprint Inside Interiors**

  Allows you to sprint at full speed inside _most_ interiors.

- **Lockpick Animation**

  Increases the chance of using a lock picking animation when stealing vehicles instead of smashing the window.

- **Ragdoll On Demand**

  Allows you to ragdoll at any time.

  _Usage:_ Triggered via keybind _(default: **[X]**)_.

- **Clumsy**

  Makes you stumble and fall whenever you bump into anything; including sidewalks.

- **Magic Bullet**

  Shoots the last ped you aimed at in the head as soon as you fire your weapon.

- **Laser Sights**

  Adds a visible laser beam to supported firearms.

  _Usage:_ Toggle via keybind while aiming, same as weapon flashlight _(default: **[L]**)_.

- **Katana**

  Replaces a selected melee weapon with a katana for close-quarters combat.

  _Usage:_ Choose base weapon in settings, then equip normally.

<p align="right">[<a href="#features">🔝</a>]</p>

## Vehicle

_Vehicle-centric features extending the capabilities of vanilla vehicles._

### General

- **Speedometer**

  Draws a custom speedometer that switches modes between vehicles and aircraft.

- **Brake Force Display**

  Flashes your brake lights when you apply the brakes from high speed.

- **Fast Vehicles**

  Greatly increases the acceleration and top speed of any land vehicle you drive.

- **NOS**

  Allows you to use a custom NOS boost.

  _Usage:_ Triggered via keybind while driving _(default: **[Mouse 5]**)_.

- **NOS Purge**

  Allows you to perform a NOS purge [à la 2 Fast 2 Furious](https://www.youtube.com/watch?v=aBRCDqabqTE)

  _Usage:_ Triggered via keybind while driving _(default: **[X]**)_.

- **Pops & Bangs**

  Enables extremely loud exhaust pops that scare nearby NPCs.

  _Usage:_ Triggered automatically when you release the accelerator from high RPM.

- **Drift Mode**

  Introduces new arcade-style drift mechanics.

  _Usage:_ Triggered via keybind while driving _(default: **[Left Shift]**)_.

- **Big Subwoofer**

  Makes your vehicle's radio sound louder from the outside.

- **High Beams On Horn**

  Flashes your high beams when you use the horn.

- **Auto Brake Lights**

  Turns on your brake lights when you come to a complete stop.

- **Unbreakable Windows**

  Prevents your vehicle's windows from breaking.

- **Stronger Crashes**

  Makes car crashes more dangerous by increasing deformation, introducing engine damage, screen effects, and potential loss of life.

- **RGB Headlights**

  Starts an RGB loop on your vehicle's headlights.

- **Auto Lock**

  Automatically locks your vehicle when you walk away from it.

- **Launch Control**

  Simulates launch control by making your vehicle accelerate faster from a standstill and decreasing wheel spin.

- **IV-Style Exit**

  Re-introduces GTA IV's vehicle exit style.

  _Usage:_ Hold **[F]** to turn the engine off before exiting or press and release normally to keep it running.

- **Keep Wheels Turned**

  Preserves the last angle your wheels were steered at before exiting.

- **Vehicle Mines**

  Allows you to deploy all types of mines from any land vehicle.

  _Usage:_ Choose a type then press the assigned keybind _(default: **[Numpad 0]**)_.

- **Drift Minigame**

  Score points by drifting around Los Santos. You can bank your points for cash in Single Player.

- **Ram _(AKA Shunt)_**

  Gives you the ability to ram other vehicles, peds, or objects in 3 directions.

  _Usage:_ Triggered via keybinds while moving forward in a vehicle. **[Numpad4]**: Left | **[Numpad8]**: Forward | **[Numpad6]**: Right.

### Aircraft

- **Fast Planes**

  Increases the top speed of any plane you fly to ±560 km/h as long as the plane can reach 250 km/h on its own.

- **Disable Engine Stalling**

  Prevents your plane engine(s) from stalling when you hold the brake button mid-air.

- **Disable Air Turbulence _(Experimental)_**

  Disables air turbulence for some aircraft.

- **Flare Countermeasures**

  Allows you to deploy flares from any aircraft.

  _Usage:_ Triggered via default countermeasures keybind.

- **Cobra Maneuver**

  Allows you to perform a [cobra maneuver](https://www.youtube.com/shorts/H0X7D3Ga4mo).

  _Usage:_ Triggered via keybind while flying _(default: **[X]**)_.

- **Machine Gun Triggerbot**

  Automatically fires your aircraft's machine gun.

  _Usage:_ Get in a weaponized aircraft and equip the machine gun.

- **Machine Gun Manual Aim**

  Allows you to manually aim your aircraft's machine gun.

- **Autopilot**

  Automatically flies your aircraft to the selected destination.

  _Usage:_ Sit in the pilot's seat and select a destination from the menu _(Objective, Waypoint, or Random)_.

### Stancer

_VStancer's Carthaginian cousin._

Allows advanced stance tuning, including:

- **Per-axle _(affects handling)_**

  Camber, suspension height, track width.

- **Global _(visual only)_**

  Wheel size, wheel width, ride height.

Additional features:

- Air suspension controls.
- Bounce mode _(SUVs only)_.

### Engine Swap

Changes your current vehicle's engine sound and power.

### Handling Editor

A comprehensive vehicle flag editor and preset system that exposes all currently reversed `advanced`, `handling`, `model`, and `model info` vehicle flags.

- **Features:**

  - Real-time editing of vehicle flags directly from memory.
  - Dynamic filtering and sorting for easier flag management.
  - Generate custom presets from currently mutated flags.
  - Default and user-generated presets can be:
    - Enabled/disabled manually.
    - Auto-applied automatically _(On vehicle enter/switch)_.
    - Exported/imported via clipboard _(User-generated only since defaults are the same for everyone)_.
  - Presets avoid redundant edits by only storing non-default mutations.
  - Active presets protect owned flags from manual edits.
  - Optional user-defined callback files allow user-generated presets to execute custom logic when enabled or disabled.
  - Defensive runtime protections block faulty or expensive custom callbacks automatically.

- **Custom Callbacks:**

Users can define custom logic to be executed when their custom handling preset is enabled, disabled, or both, following these steps:

- Create a new **uniquely-named** Lua source file _(ex: `my_custom_preset_callbacks.lua`)_
- Place it in the project's source inside the `includes` folder _(Preferably under `includes/data/`)_.
- In the file, return a table containing a table key that's exactly your target custom preset's name. The table must contain one or both of these two functions with these exact names: `onEnable` and `onDisable`.
- If a custom definitions file already exists, you can simply edit that file instead by adding your custom preset callback to the table.
- Both `onEnable` and `onDisable` provide a reference to the HandlingEditor instance.
- **IMPORTANT:** Both functions **MUST** return `true` on completion **(even early exits must return true)**. Failure to do so may trigger timeout protection and blacklist the callback _(this is required to catch and prevent deadlocks)_.
- Example:

    ```Lua
    return {
      ["My Custom Handling Preset"] = { -- This key MUST be exactly your target user-generated preset's name.
          onEnable = function(editor)
              -- your code goes here (call natives, another SSV2 feature, etc.)
              -- you can call HandlingEditor methods too (ex: editor:Reset() to reset all flags and presets before applying your custom preset)
              return true -- This is very important. You must return true when done.
          end,
          onDisable = function(editor)
              -- your code goes here (cleanup logic, etc.)
              -- you can call HandlingEditor methods too (ex: editor:ApplyPresets() to re-apply all automatic presets after disabling your custom preset)
              return true -- This is very important. You must return true when done.
          end,
      }
    }
    ```

  > [!Note]
  > This process is necessary because both of Lua's default `load` and `loadstring` functions do not exist in YimMenu's Lua sandbox.
  >
  > Basic Lua programming knowledge and familiarity with both YimMenu's Lua API and the SSV2 API are required for this.

### Custom Paint Jobs

Choose from a list of over 300 hand-picked real-life paint jobs and apply them to your current vehicle.

### Flatbed Script

A script that allows you to use the [MTL Flatbed](https://gta.fandom.com/wiki/Flatbed) truck to tow vehicles. You can either spawn a truck yourself or find one in the open world.

_Usage:_ Sit in the driver's seat of a flatbed truck then approach any vehicle and press the assigned keybind _(default: **[X]**)_ to tow it.

<p align="right">[<a href="#features">🔝</a>]</p>

## World

- **Disable Ocean Waves**

  Completely removes waves from the ocean.

- **Extend World Boundaries**

  Allows you to travel further in any direction without dying.

- **Disable Flight Music**

  Disables the ambient music that automatically plays when you're flying an aircraft.

- **Disable Wanted Music**

  Disables the ambient music that automatically plays when you have a wanted level higher than 2 stars.

- **Hide & Seek**

  Allows you to hide in several places (car trunks, trash bins, inside vehicles). Also makes it easier to lose a wanted level.

- **Carpool**

  Allows you to get in any NPC vehicle as a passenger. Works for police vehicles too but they won't be happy.

- **Public Enemy #1**

  All nearby NPCs attack you.

- **Kill All Enemies**

  Kills all nearby enemies.

  _Usage:_ Triggered via a button in the UI or a keybind _(default: **[F7]**)_.

- **Scare All Enemies**

  Forces all nearby enemies to flee _(except NOOSE)_.

  _Usage:_ Triggered via a button in the UI or a keybind _(default: **[F8]**)_.

<p align="right">[<a href="#features">🔝</a>]</p>

## Online

### YimResupplierV3

A business manager that supports auto-fill and auto-sell for several businesses, offers instant production triggers for biker businesses, bunker, acid lab, nightclub controls some job cooldowns, and integrates with CommandExecutor. Includes a SalvageYard script by [@szalikdev](https://github.com/szalikdev).

### CasinoPacino

An updated and slightly refactored version of [Casino Pacino](https://github.com/YimMenu-Lua/Casino-Pacino).

### Mastermind

A heist editor added by [@How-Bout-No](https://github.com/How-Bout-No) [WIP].

Contains the following modules:

- **Basic**

  Options for Teleport, Set Waypoint, Skip Preps, and Disable Cooldowns on:
  - Cluckin Bell
  - KnoWay
  - Dr Dre Contract
  - Oscar Guzman

- **Cayo Perico**

  Options for Teleport, Set Waypoint, and Request Submarine.

  Ability to change Primary Target, all Secondary Targets on the island and inside the compound, Weapon Loadout, Hard Mode, Unlock All Heist Options _(Approach Vehicles, Disruptions, etc)_, Disable Cooldown

- **Doomsday**

  Options for Teleport and Set Waypoint to Facility.

  Skip all Preps/Setups and Disable Cooldowns on all 3 Acts (your choice):
  1. The Data Breaches
  2. The Bogdan Problem
  3. The Doomsday Scenario

## Extra

### YimActionsV3

All-in-one animations script.

### EntityForge

An experimental script that allows you to attach, merge, and create things using peds, objects and vehicles and share them with friends.

### Billionaire Services

Offers exclusive bodyguard, escort, jet, heli, and limousine services.

<p align="right">[<a href="#features">🔝</a>]</p>
