-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


-- `CVehicle::ModelInfoFlags`
---@enum eVehicleModelInfoFlags
local eVehicleModelInfoFlags <const> = {
	HAS_LIVERY                                  = 7,
	SPORTS                                      = 9,
	DONT_ROTATE_TAIL_ROTOR                      = 26,
	PARKING_SENSORS                             = 27,
	PEDS_CAN_STAND_ON_TOP                       = 28,
	LAW_ENFORCEMENT                             = 31,
	EMERGENCY_SERVICE                           = 32,
	RICH_CAR                                    = 36,
	AVERAGE_CAR                                 = 37,
	POOR_CAR                                    = 38,
	ALLOWS_RAPPEL                               = 39,
	IS_ELECTRIC                                 = 43,
	CANNOT_BE_MODDED                            = 54,
	HAS_NO_ROOF                                 = 64,
	HAS_BULLETPROOF_GLASS                       = 76,
	CANNOT_BE_PICKUP_BY_CARGOBOB                = 95,
	DISABLE_BUSTING                             = 112,
	ALLOW_HATS_NO_ROOF                          = 117,
	HAS_LOWRIDER_HYDRAULICS                     = 119,
	HAS_BULLET_RESISTANT_GLASS                  = 120,
	HAS_INCREASED_RAMMING_FORCE                 = 121,
	HAS_LOWRIDER_DONK_HYDRAULICS                = 123,
	JUMPING_CAR                                 = 125,
	HAS_ROCKET_BOOST                            = 126,
	RAMMING_SCOOP                               = 127,
	HAS_PARACHUTE                               = 128,
	HAS_RAMP                                    = 129,
	FRONT_BOOT                                  = 131,
	DONT_HOLD_LOW_GEARS_WHEN_ENGINE_UNDER_LOAD  = 136,
	HAS_GLIDER                                  = 137,
	INCREASE_LOW_SPEED_TORQUE                   = 138,
	EQUIP_UNARMED_ON_ENTER                      = 152,
	HAS_VERTICAL_FLIGHT_MODE                    = 154,
	DROP_SUSPENSION_WHEN_STOPPED                = 157,
	HAS_VERTICAL_ROCKET_BOOST                   = 161,
	NO_HEAVY_BRAKE_ANIMATION                    = 168,
	HAS_INCREASED_RAMMING_FORCE_VS_ALL_VEHICLES = 172,
	HAS_NITROUS_MOD                             = 174,
	HAS_JUMP_MOD                                = 175,
	HAS_RAMMING_SCOOP_MOD                       = 176,
	HAS_SUPER_BRAKES_MOD                        = 177,
	CRUSHES_OTHER_VEHICLES                      = 178,
	RAMP_MOD                                    = 182,
	HAS_SIDE_SHUNT                              = 184,
	HAS_SUPERCHARGER                            = 188,
	SPOILER_MOD_DOESNT_INCREASE_GRIP            = 194,
	NO_REVERSING_ANIMATION                      = 195,
	IS_FORMULA_VEHICLE                          = 197,
}

return eVehicleModelInfoFlags
