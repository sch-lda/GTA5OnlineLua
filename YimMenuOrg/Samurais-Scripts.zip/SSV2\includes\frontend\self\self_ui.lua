-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local drawPlayerAbilities            = require("includes.frontend.self.player_abilities")
local selfTab                        = GUI:RegisterNewTab(Enums.eTabID.TAB_SELF, "Self")
local showAbilities                  = false

local katana_replace_weapons <const> = {
	2508868239,
	1141786504,
	3713923289,
	2484171525,
}

local function laserOptions()
	local cfg = GVars.features.weapon.laser_sights
	ImGui.ColorEditVec4(_T("SELF_LASER_SIGHTS_COL"), cfg.color)
	cfg.ray_length = ImGui.SliderInt(_T("SELF_LASER_SIGHTS_LENGTH"), cfg.ray_length, 100, 1000)
end

local function ragdollOptions()
	GVars.features.self.ragdoll_sound = GUI:CustomToggle(_T("SELF_RAGDOLL_SOUND"),
		GVars.features.self.ragdoll_sound,
		{ tooltip = _T("SELF_RAGDOLL_SOUND_TT") }
	)
end

local function katanaOptions()
	if (ImGui.BeginCombo(_T("SELF_KATANA_REPLACE_MODEL"), GVars.features.weapon.katana.name)) then
		for _, hash in ipairs(katana_replace_weapons) do
			local is_selected = GVars.features.weapon.katana.model == hash
			local name = Game.GetWeaponDisplayName(hash)
			if (ImGui.Selectable(name, is_selected)) then
				GVars.features.weapon.katana.name = name
				GVars.features.weapon.katana.model = hash
			end

			if (ImGui.IsItemClicked(0)) then
				ThreadManager:Run(function()
					if not (LocalPlayer:IsOnFoot() and LocalPlayer:IsOutside()) then
						return
					end

					local handle = LocalPlayer:GetHandle()
					if (WEAPON.IS_PED_ARMED(handle, 7)) then
						WEAPON.SET_CURRENT_PED_WEAPON(handle, 0xA2719263, true)
					end

					if (WEAPON.HAS_PED_GOT_WEAPON(handle, hash, false)) then
						sleep(300)
						WEAPON.SET_CURRENT_PED_WEAPON(handle, hash, true)
					end
				end)
			end
		end
		ImGui.EndCombo()
	end
end

local function CheckIfRagdollBlocked()
	ThreadManager:Run(function()
		if (LocalPlayer:IsOnFoot() and not LocalPlayer:IsRagdoll() and not LocalPlayer:CanRagdoll()) then
			Notifier:ShowWarning("Samurais Scripts", _T("SELF_RAGDOLL_BLOCK_INFO"))
		end
	end)
end

selfTab:AddBoolCommand("SELF_AUTOHEAL",
	{
		gvar_key        = "features.self.autoheal.enabled",
		translate_label = true,
		meta            = { description = "SELF_AUTOHEAL_TT" },
		ctx_data        = {
			callback = function()
				GVars.features.self.autoheal.regen_speed = ImGui.SliderInt(
					_T("SELF_REGEN_SPEED"),
					GVars.features.self.autoheal.regen_speed,
					1, 100
				)
			end
		}
	}
)
selfTab:AddBoolCommand("SELF_PHONE_ANIMS",
	{
		gvar_key        = "features.self.phone_anims",
		translate_label = true,
		meta            = { description = "SELF_PHONE_ANIMS_TT" },
	}
)
selfTab:AddBoolCommand("SELF_MC_BIKE_ANIMS",
	{
		gvar_key        = "features.self.mc_alt_bike_anims",
		translate_label = true,
		meta            = { description = "SELF_MC_BIKE_ANIMS_TT" },
	}
)
selfTab:AddBoolCommand("SELF_ACTION_MODE",
	{
		gvar_key        = "features.self.disable_action_mode",
		translate_label = true,
		meta            = { description = "SELF_ACTION_MODE_TT" },
	}
)
selfTab:AddBoolCommand("SELF_HEADPROPS",
	{
		gvar_key        = "features.self.allow_headprops_in_vehicles",
		translate_label = true,
		meta            = { description = "SELF_HEADPROPS_TT" },
	}
)
selfTab:AddBoolCommand("SELF_STAND_ON_VEHS",
	{
		gvar_key        = "features.self.stand_on_veh_roof",
		translate_label = true,
		meta            = { description = "SELF_STAND_ON_VEHS_TT" },
	}
)
selfTab:AddBoolCommand("SELF_NO_CARJACKING",
	{
		gvar_key        = "features.self.no_carjacking",
		translate_label = true,
		meta            = { description = "SELF_NO_CARJACKING_TT" },
	}
)
selfTab:AddBoolCommand("SELF_CROUCH",
	{
		gvar_key        = "features.self.crouch",
		translate_label = true,
		meta            = { description = "SELF_CROUCH_TT" },
		on_disable      = function() Backend:RemoveDisabledControl(36) end,
	}
)
selfTab:AddBoolCommand("SELF_HANDS_UP",
	{
		gvar_key        = "features.self.hands_up",
		translate_label = true,
		meta            = { description = "SELF_HANDS_UP_TT" },
		on_disable      = function() Backend:RemoveDisabledControl(29) end,
	}
)
selfTab:AddBoolCommand("SELF_SPRINT_INSIDE",
	{
		gvar_key        = "features.self.sprint_inside_interiors",
		translate_label = true,
		meta            = { description = "SELF_SPRINT_INSIDE_TT" },
	}
)
selfTab:AddBoolCommand("SELF_LOCKPICK_ANIM",
	{
		gvar_key        = "features.self.jacking_always_lockpick_anim",
		translate_label = true,
		meta            = { description = "SELF_LOCKPICK_ANIM_TT" },
	}
)
selfTab:AddBoolCommand("SELF_ROD",
	{
		gvar_key        = "features.self.rod",
		translate_label = true,
		meta            = { description = "SELF_ROD_TT" },
		on_enable       = function()
			GVars.features.self.clumsy = false
			CheckIfRagdollBlocked()
		end,
		ctx_data        = { callback = ragdollOptions }
	}
)
selfTab:AddBoolCommand("SELF_CLUMSY",
	{
		gvar_key        = "features.self.clumsy",
		translate_label = true,
		meta            = { description = "SELF_CLUMSY_TT" },
		on_enable       = function()
			GVars.features.self.rod = false
			CheckIfRagdollBlocked()
		end,
		ctx_data        = { callback = ragdollOptions }
	}
)
selfTab:AddBoolCommand("SELF_MAGIC_BULLET",
	{
		gvar_key        = "features.weapon.magic_bullet",
		translate_label = true,
		meta            = { description = "SELF_MAGIC_BULLET_TT" },
	}
)
selfTab:AddBoolCommand("SELF_LASER_SIGHTS",
	{
		gvar_key        = "features.weapon.laser_sights.enabled",
		translate_label = true,
		meta            = { description = "SELF_LASER_SIGHTS_TT" },
		ctx_data        = { callback = laserOptions }
	}
)
selfTab:AddBoolCommand("SELF_KATANA",
	{
		gvar_key        = "features.weapon.katana.enabled",
		translate_label = true,
		meta            = { description = "SELF_KATANA_TT" },
		ctx_data        = { callback = katanaOptions }
	}
)

selfTab:RegisterGUI(function()
	ImGui.SeparatorText(_T("GENERIC_GENERAL_LABEL"))
	selfTab:GetGridRenderer():Draw()

	if (Game.IsOnline()) then
		ImGui.Spacing()
		ImGui.SeparatorText(_T("SELF_ABILITY_EDITOR"))
		showAbilities = GUI:CustomToggle(_T("GENERIC_ENABLE"), showAbilities)

		if (showAbilities) then
			ImGui.Spacing()
			drawPlayerAbilities()
		end
	end
end)
