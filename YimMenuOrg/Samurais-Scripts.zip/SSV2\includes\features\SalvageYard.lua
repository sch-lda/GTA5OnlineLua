-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local robbery_types <const> = {
	{
		name = "The Cargo Ship",
		fm_prog = 126,
		scope_bs = 1,
		disrupt = 3,
	},
	{
		name = "The Gangbanger",
		fm_prog = 126,
		scope_bs = 3,
		disrupt = 3,
	},
	{
		name = "The Duggan",
		fm_prog = 126,
		scope_bs = 4,
		disrupt = 3,
	},
	{
		name = "The Podium",
		fm_prog = 126,
		scope_bs = 8,
		disrupt = 3,
	},
	{
		name = "The McTony",
		fm_prog = 126,
		scope_bs = 16,
		disrupt = 3,
	},
}

local robbery_status_tostring <const> = { "Available", "In Progress", "Completed" }

---@class SalvageYard
local SalvageYard = {}
SalvageYard.__index = SalvageYard

---@return boolean
function SalvageYard:OwnsSalvageYard()
	return stats.get_int("MPX_SALVAGE_YARD_OWNED") ~= 0
end

---@param slot integer
---@return string|nil
function SalvageYard:CheckWeeklyRobberyStatus(slot)
	local statName = _F("MPX_SALV23_VEHROB_STATUS%d", slot)
	local status   = stats.get_int(statName)
	return robbery_status_tostring[status + 1]
end

---@param slot integer
---@return boolean
function SalvageYard:IsLiftTaken(slot)
	local statName = _F("MPX_MPSV_MODEL_SALVAGE_LIFT%d", slot)
	return stats.get_int(statName) ~= 0
end

---@param slot integer
function SalvageYard:InstantSalvage(slot)
	if (not self:IsLiftTaken(slot)) then
		return
	end

	local statName = _F("MPX_SALVAGING_POSIX_LIFT%d", slot)
	stats.set_int(statName, stats.get_int(statName) - 7200) -- takes 48 minutes with upgrades and 96 minutes without
end

function SalvageYard:IsRobberyActive()
	return self:GetRobberyType() >= 0
end

---@return string
function SalvageYard:GetCooldownString()
	local cd = stats.get_int("MPX_SALV23_VEHROB_CD")
	return cd <= 0 and _T("SY_CD_NONE") or _T("SY_CD_ACTIVE")
end

function SalvageYard:DisableCooldown()
	stats.set_int("MPX_SALV23_VEHROB_CD", 0)
end

function SalvageYard:DisableWeeklyCooldown()
	local week = stats.get_int("MPX_SALV23_WEEK_SYNC")
	tunables.set_int(488207018, week + 1)
	Notifier:ShowSuccess("Salvage Yard", "Weekly cooldown skipped.")
end

---@param slot integer
---@return string
function SalvageYard:GetCarFromSlot(slot)
	local enum = stats.get_int(_F("%s%d", "MPX_MPSV_MODEL_SALVAGE_VEH", slot))
	local modelName = self.RobberyTargets[enum]
	if (not modelName) then
		return "Unknown"
	end

	return vehicles.get_vehicle_display_name(modelName)
end

---@return string
function SalvageYard:GetRobberyTypeName()
	local id = stats.get_int("MPX_SALV23_VEH_ROB")
	local stringtype = robbery_types[id + 1]
	return stringtype and stringtype.name or "None"
end

function SalvageYard:GetRobberyType()
	return stats.get_int("MPX_SALV23_VEH_ROB")
end

function SalvageYard:GetRobberyValue()
	return stats.get_int("MPX_SALV23_SALE_VAL")
end

function SalvageYard:GetRobberyKeepState()
	return stats.get_bool("MPX_SALV23_CAN_KEEP")
end

function SalvageYard:CompletePreparation()
	local current = self:GetRobberyType()
	local info = robbery_types[current + 1]
	if (not info) then
		Notifier:ShowError("Salvage Yard", "Failed to get current robbery. Are you sure you started one?")
		return
	end

	stats.set_int("MPX_SALV23_FM_PROG", info.fm_prog)
	stats.set_int("MPX_SALV23_SCOPE_BS", info.scope_bs)
	stats.set_int("MPX_SALV23_DISRUPT", info.disrupt)
	Notifier:ShowSuccess("Salvage Yard", _T("SY_PREP_SKIP"))
end

---@return boolean
function SalvageYard:ArePrepsCompleted()
	return Bit.is_set(stats.get_int("MPX_SALV23_GEN_BS"), 0)
end

function SalvageYard:DoubleCarWorth()
	local current_worth = stats.get_int("MPX_SALV23_SALE_VAL")
	stats.set_int("MPX_SALV23_SALE_VAL", current_worth * 2)
end

---@return string
function SalvageYard:GetCarNameFromHash(hash)
	return VEHICLE.GET_DISPLAY_NAME_FROM_VEHICLE_MODEL(hash)
end

SalvageYard.RobberyTargets = {
	"lm87",
	"cinquemila",
	"autarch",
	"tigon",
	"champion",
	"tenf",
	"sm722",
	"omnisegt",
	"growler",
	"deity",
	"italirsx",
	"coquette4",
	"jubilee",
	"astron",
	"comet7",
	"torero",
	"cheetah2",
	"turismo2",
	"infernus2",
	"stafford",
	"gt500",
	"viseris",
	"mamba",
	"coquette3",
	"stingergt",
	"ztype",
	"broadway",
	"vigero2",
	"buffalo4",
	"ruston",
	"gauntlet4",
	"dominator8",
	"btype3",
	"swinger",
	"feltzer3",
	"omnis",
	"tropos",
	"jugular",
	"patriot3",
	"toros",
	"caracara2",
	"sentinel3",
	"weevil",
	"kanjo",
	"eudora",
	"kamacho",
	"hellion",
	"ellie",
	"hermes",
	"hustler",
	"turismo3",
	"buffalo5",
	"stingertt",
	"virtue",
	"ignus",
	"zentorno",
	"neon",
	"furia",
	"zorrusso",
	"thrax",
	"vagner",
	"panthere",
	"italigto",
	"s80",
	"tyrant",
	"entity3",
	"torero2",
	"neo",
	"corsita",
	"paragon",
	"btype2",
	"comet4",
	"fr36",
	"everon2",
	"komoda",
	"tailgater2",
	"jester3",
	"jester4",
	"euros",
	"zr350",
	"cypher",
	"dominator7",
	"baller8",
	"casco",
	"yosemite2",
	"everon",
	"penumbra2",
	"vstr",
	"dominator9",
	"schlagen",
	"cavalcade3",
	"clique",
	"boor",
	"sugoi",
	"greenwood",
	"brigham",
	"issi8",
	"seminole2",
	"kanjosj",
	"previon",
	"lm87",
	"cinquemila",
	"autarch",
	"tigon",
	"champion",
	"tenf",
	"sm722",
	"omnisegt",
	"growler",
	"deity",
	"italirsx",
	"coquette4",
	"jubilee",
	"astron",
	"comet7",
	"torero",
	"cheetah2",
	"turismo2",
	"infernus2",
	"stafford",
	"gt500",
	"viseris",
	"mamba",
	"coquette3",
	"stingergt",
	"ztype",
	"broadway",
	"vigero2",
	"buffalo4",
	"ruston",
	"gauntlet4",
	"dominator8",
	"btype3",
	"swinger",
	"feltzer3",
	"omnis",
	"tropos",
	"jugular",
	"patriot3",
	"toros",
	"caracara2",
	"sentinel3",
	"weevil",
	"kanjo",
	"eudora",
	"kamacho",
	"hellion",
	"ellie",
	"hermes",
	"hustler",
	"turismo3",
	"buffalo5",
	"stingertt",
	"virtue",
	"ignus",
	"zentorno",
	"neon",
	"furia",
	"zorrusso",
	"thrax",
	"vagner",
	"panthere",
	"italigto",
	"s80",
	"tyrant",
	"entity3",
	"torero2",
	"neo",
	"corsita",
	"paragon",
	"btype2",
	"comet4",
	"fr36",
	"everon2",
	"komoda",
	"tailgater2",
	"jester3",
	"jester4",
	"euros",
	"zr350",
	"cypher",
	"dominator7",
	"baller8",
	"casco",
	"yosemite2",
	"everon",
	"penumbra2",
	"vstr",
	"dominator9",
	"schlagen",
	"cavalcade3",
	"clique",
	"boor",
	"sugoi",
	"greenwood",
	"brigham",
	"issi8",
	"seminole2",
	"kanjosj",
	"previon",
	"lm87",
	"cinquemila",
	"autarch",
	"tigon",
	"champion",
	"tenf",
	"sm722",
	"omnisegt",
	"growler",
	"deity",
	"italirsx",
	"coquette4",
	"jubilee",
	"astron",
	"comet7",
	"torero",
	"cheetah2",
	"turismo2",
	"infernus2",
	"stafford",
	"gt500",
	"viseris",
	"mamba",
	"coquette3",
	"stingergt",
	"ztype",
	"broadway",
	"vigero2",
	"buffalo4",
	"ruston",
	"gauntlet4",
	"dominator8",
	"btype3",
	"swinger",
	"feltzer3",
	"omnis",
	"tropos",
	"jugular",
	"patriot3",
	"toros",
	"caracara2",
	"sentinel3",
	"weevil",
	"kanjo",
	"eudora",
	"kamacho",
	"hellion",
	"ellie",
	"hermes",
	"hustler",
	"turismo3",
	"buffalo5",
	"stingertt",
	"virtue",
	"ignus",
	"zentorno",
	"neon",
	"furia",
	"zorrusso",
	"thrax",
	"vagner",
	"panthere",
	"italigto",
	"s80",
	"tyrant",
	"entity3",
	"torero2",
	"neo",
	"corsita",
	"paragon",
	"btype2",
	"comet4",
	"fr36",
	"everon2",
	"komoda",
	"tailgater2",
	"jester3",
	"jester4",
	"euros",
	"zr350",
	"cypher",
	"dominator7",
	"baller8",
	"casco",
	"yosemite2",
	"everon",
	"penumbra2",
	"vstr",
	"dominator9",
	"schlagen",
	"cavalcade3",
	"clique",
	"boor",
	"sugoi",
	"greenwood",
	"brigham",
	"issi8",
	"seminole2",
	"kanjosj",
	"previon",
	"lm87",
	"cinquemila",
	"autarch",
	"tigon",
	"champion",
	"tenf",
	"sm722",
	"omnisegt",
	"growler",
	"deity",
	"italirsx",
	"coquette4",
	"jubilee",
	"astron",
	"comet7",
	"torero",
	"cheetah2",
	"turismo2",
	"infernus2",
	"stafford",
	"gt500",
	"viseris",
	"mamba",
	"coquette3",
	"stingergt",
	"ztype",
	"broadway",
	"vigero2",
	"buffalo4",
	"ruston",
	"gauntlet4",
	"dominator8",
	"btype3",
	"swinger",
	"feltzer3",
	"omnis",
	"tropos",
	"jugular",
	"patriot3",
	"toros",
	"caracara2",
	"sentinel3",
	"weevil",
	"kanjo",
	"eudora",
	"kamacho",
	"hellion",
	"ellie",
	"hermes",
	"hustler",
	"turismo3",
	"buffalo5",
	"stingertt",
	"virtue",
	"ignus",
	"zentorno",
	"neon",
	"furia",
	"zorrusso",
	"thrax",
	"vagner",
	"panthere",
	"italigto",
	"s80",
	"tyrant",
	"entity3",
	"torero2",
	"neo",
	"corsita",
	"paragon",
	"btype2",
	"comet4",
	"fr36",
	"everon2",
	"komoda",
	"tailgater2",
	"jester3",
	"jester4",
	"euros",
	"zr350",
	"cypher",
	"dominator7",
	"baller8",
	"casco",
	"yosemite2",
	"everon",
	"penumbra2",
	"vstr",
	"dominator9",
	"schlagen",
	"cavalcade3",
	"clique",
	"boor",
	"sugoi",
	"greenwood",
	"brigham",
	"issi8",
	"seminole2",
	"kanjosj",
	"previon",
	"lm87",
	"cinquemila",
	"autarch",
	"tigon",
	"champion",
	"tenf",
	"sm722",
	"omnisegt",
	"growler",
	"deity",
	"italirsx",
	"coquette4",
	"jubilee",
	"astron",
	"comet7",
	"torero",
	"cheetah2",
	"turismo2",
	"infernus2",
	"stafford",
	"gt500",
	"viseris",
	"mamba",
	"coquette3",
	"stingergt",
	"ztype",
	"broadway",
	"vigero2",
	"buffalo4",
	"ruston",
	"gauntlet4",
	"dominator8",
	"btype3",
	"swinger",
	"feltzer3",
	"omnis",
	"tropos",
	"jugular",
	"patriot3",
	"toros",
	"caracara2",
	"sentinel3",
	"weevil",
	"kanjo",
	"eudora",
	"kamacho",
	"hellion",
	"ellie",
	"hermes",
	"hustler",
	"turismo3",
	"buffalo5",
	"stingertt",
	"virtue",
	"ignus",
	"zentorno",
	"neon",
	"furia",
	"zorrusso",
	"thrax",
	"vagner",
	"panthere",
	"italigto",
	"s80",
	"tyrant",
	"entity3",
	"torero2",
	"neo",
	"corsita",
	"paragon",
	"btype2",
	"comet4",
	"fr36",
	"everon2",
	"komoda",
	"tailgater2",
	"jester3",
	"jester4",
	"euros",
	"zr350",
	"cypher",
	"dominator7",
	"baller8",
	"casco",
	"yosemite2",
	"everon",
	"penumbra2",
	"vstr",
	"dominator9",
	"schlagen",
	"cavalcade3",
	"clique",
	"boor",
	"sugoi",
	"greenwood",
	"brigham",
	"issi8",
	"seminole2",
	"kanjosj",
	"previon"
}

return SalvageYard
