---@enum ePedGender
local ePedGender <const> = {
	MALE   = 0,
	FEMALE = 1,
	UNK    = 2
}

return ePedGender
