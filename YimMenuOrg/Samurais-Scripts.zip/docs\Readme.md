# Documentation

In version 1.7.3, the script was updated using [this template repository](https://github.com/xesdoog/SmallBase). For more information, please refer to the [SmallBase docs](https://github.com/xesdoog/SmallBase/tree/main/docs)
