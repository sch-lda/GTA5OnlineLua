-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


---@enum eAnimFlags
local eAnimFlags <const> = {
	LOOPING                          = 0,
	HOLD_LAST_FRAME                  = 1,
	REPOSITION_WHEN_FINISHED         = 2,
	NOT_INTERRUPTABLE                = 3,
	UPPERBODY                        = 4,
	SECONDARY                        = 5,
	REORIENT_WHEN_FINISHED           = 6,
	ABORT_ON_PED_MOVEMENT            = 7,
	ADDITIVE                         = 8,
	TURN_OFF_COLLISION               = 9,
	OVERRIDE_PHYSICS                 = 10,
	IGNORE_GRAVITY                   = 11,
	EXTRACT_INITIAL_OFFSET           = 12,
	EXIT_AFTER_INTERRUPTED           = 13,
	TAG_SYNC_IN                      = 14,
	TAG_SYNC_OUT                     = 15,
	TAG_SYNC_CONTINUOUS              = 16,
	FORCE_START                      = 17,
	USE_KINEMATIC_PHYSICS            = 18,
	USE_MOVER_EXTRACTION             = 19,
	HIDE_WEAPON                      = 20,
	ENDS_IN_DEAD_POSE                = 21,
	ACTIVATE_RAGDOLL_ON_COLLISION    = 22,
	DONT_EXIT_ON_DEATH               = 23,
	ABORT_ON_WEAPON_DAMAGE           = 24,
	DISABLE_FORCED_PHYSICS_UPDATE    = 25,
	PROCESS_ATTACHMENTS_ON_START     = 26,
	EXPAND_PED_CAPSULE_FROM_SKELETON = 27,
	USE_ALTERNATIVE_FP_ANIM          = 28,
	BLENDOUT_WRT_LAST_FRAME          = 29,
	USE_FULL_BLENDING                = 30,
}

return eAnimFlags
