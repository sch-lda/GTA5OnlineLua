-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


require "includes.modules.Entity"

--------------------------------------
-- Class: Ped
--------------------------------------
-- **Global.**
--
-- **Parent:** `Entity`.
--
-- Class representing a GTA V Ped.
---@class Ped : Entity
---@field private m_internal CPed
---@field Resolve fun() : CPed
---@field Create fun(_, modelHash: hash, entityType: eEntityType, pos?: vec3, heading?: number, isNetwork?: boolean, isScriptHostPed?: boolean): Ped
---@overload fun(handle: handle): Ped
Ped = Class("Ped", Entity)

---@return boolean
function Ped:IsValid()
	return self:Exists() and ENTITY.IS_ENTITY_A_PED(self:GetHandle())
end

---@return boolean
function Ped:IsPlayer()
	local cplayerinfo = self:Resolve().m_player_info
	return cplayerinfo and cplayerinfo:IsValid() or false
end

---@return boolean
function Ped:IsLocalPlayer()
	return self == LocalPlayer
end

---@return boolean
function Ped:IsAlive()
	return self:IsValid() and not ENTITY.IS_ENTITY_DEAD(self:GetHandle(), false)
end

---@return boolean
function Ped:IsDead()
	return ENTITY.IS_ENTITY_DEAD(self:GetHandle(), false)
end

---@return boolean
function Ped:IsOnFoot()
	return self:IsValid() and PED.IS_PED_ON_FOOT(self:GetHandle())
end

---@return boolean
function Ped:IsRagdoll()
	return PED.IS_PED_RAGDOLL(self:GetHandle())
end

---@param radius? number
---@return boolean
function Ped:IsInCombat(radius)
	if not self:IsValid() or not self:IsAlive() then
		return false
	end

	local handle = self:GetHandle()
	local pos = self:GetPos()

	return PED.IS_PED_IN_COMBAT(handle, 0)
		or PED.COUNT_PEDS_IN_COMBAT_WITH_TARGET_WITHIN_RADIUS(
			handle,
			pos.x,
			pos.y,
			pos.z,
			radius or 100
		) > 0
end

---@return boolean
function Ped:IsInWater()
	return self:IsValid() and ENTITY.IS_ENTITY_IN_WATER(self:GetHandle())
end

---@return boolean
function Ped:IsSwimming()
	if not self:IsValid() then
		return false
	end

	local handle = self:GetHandle()
	return PED.IS_PED_SWIMMING(handle) or PED.IS_PED_SWIMMING_UNDER_WATER(handle)
end

---@return boolean
function Ped:IsMoving()
	return self:IsValid() and not PED.IS_PED_STOPPED(self:GetHandle())
end

---@return boolean
function Ped:IsFalling()
	return self:IsValid() and PED.IS_PED_FALLING(self:GetHandle())
end

---@return boolean
function Ped:IsDriving()
	local veh = self:GetVehicleNative()
	if (veh == 0) then
		return false
	end

	return (VEHICLE.GET_PED_IN_VEHICLE_SEAT(veh, -1, false) == self:GetHandle())
end

---@param pedHandle handle
---@return boolean
function Ped:IsPedMyEnemy(pedHandle)
	if (not self:IsValid()) then
		return false
	end

	local this = self:GetHandle()
	if (this == pedHandle) then
		return false
	end

	local rel1 = PED.GET_RELATIONSHIP_BETWEEN_PEDS(this, pedHandle)
	local rel2 = PED.GET_RELATIONSHIP_BETWEEN_PEDS(pedHandle, this)
	local pos  = self:GetPos(true)

	return (
		PED.IS_PED_IN_COMBAT(pedHandle, this)
		or PED.IS_PED_IN_COMBAT(this, pedHandle)
		or math.is_inrange(rel1, 3, 5)
		or math.is_inrange(rel2, 3, 5)
		or PED.IS_ANY_HOSTILE_PED_NEAR_POINT(
			pedHandle,
			pos.x,
			pos.y,
			pos.z,
			1
		)
	)
end

---@return hash -- weapon hash or 0.
function Ped:GetCurrentWeaponHash()
	if not self:IsValid() then
		return 0
	end

	local armed, weapon = false, 0
	armed, weapon = WEAPON.GET_CURRENT_PED_WEAPON(self:GetHandle(), weapon, false)
	return armed and weapon or 0
end

---@return handle -- weapon entity index or 0.
function Ped:GetCurrentWeaponIndex()
	if not self:IsValid() then
		return 0
	end

	return WEAPON.GET_CURRENT_PED_WEAPON_ENTITY_INDEX(self:GetHandle(), 0)
end

-- Bypasses `Vehicle` instance creation and directly returns the handle of the ped's vehicle or 0.
---@return handle
function Ped:GetVehicleNative()
	return PED.GET_VEHICLE_PED_IS_USING(self:GetHandle())
end

---@return Vehicle|nil -- A `Vehicle` instance or `nil`, not a vehicle handle.
function Ped:GetVehicle()
	if not self:IsValid() or self:IsOnFoot() then
		return
	end

	return Vehicle(self:GetVehicleNative())
end

---@return handle -- vehicle handle or 0
function Ped:GetVehicleTryingToEnter()
	return PED.GET_VEHICLE_PED_IS_TRYING_TO_ENTER(self:GetHandle())
end

---@return hash -- weapon hash or 0.
function Ped:GetVehicleWeapon()
	if not self:IsValid() or self:IsOnFoot() then
		return 0
	end

	local weapon = 0
	_, weapon = WEAPON.GET_CURRENT_PED_VEHICLE_WEAPON(self:GetHandle(), weapon)
	return weapon
end

---@return number
function Ped:GetRelationshipGroupHash()
	return self:IsValid() and PED.GET_PED_RELATIONSHIP_GROUP_HASH(self:GetHandle()) or 0
end

function Ped:GetGroupIndex()
	return self:IsValid() and PED.GET_PED_GROUP_INDEX(self:GetHandle()) or 0
end

---@return integer
function Ped:GetArmour()
	return self:IsValid() and PED.GET_PED_ARMOUR(self:GetHandle()) or 0
end

---@param cloneSpawnPos? vec3
---@param isNetwork? boolean
---@param isScriptHost? boolean
---@param copyHeadBlend? boolean
---@return Ped?
function Ped:Clone(cloneSpawnPos, isNetwork, isScriptHost, copyHeadBlend)
	if not self:IsValid() then
		return
	end

	if (isNetwork == nil) then
		isNetwork = Game.IsOnline()
	end

	if (isScriptHost == nil) then
		isScriptHost = false
	end

	if (copyHeadBlend == nil) then
		copyHeadBlend = true
	end

	cloneSpawnPos = cloneSpawnPos or self:GetOffsetInWorldCoords(math.random(-2, 2), math.random(2, 5), 0.1)
	local clone = Ped(PED.CLONE_PED(self:GetHandle(), isNetwork, isScriptHost, copyHeadBlend))
	Ped:SetCoords(cloneSpawnPos)

	return clone
end

---@param targetPed number
function Ped:CloneToTarget(targetPed)
	if not self:IsValid() then
		return
	end

	PED.CLONE_PED_TO_TARGET(self:GetHandle(), targetPed)
end

---@param boneID number
function Ped:GetBoneIndex(boneID)
	if not self:IsValid() then
		return
	end

	return Game.GetPedBoneIndex(self:GetHandle(), boneID)
end

---@param boneID number
function Ped:GetBoneCoords(boneID)
	if not self:IsValid() then
		return vec3:zero()
	end

	return Game.GetPedBoneCoords(self:GetHandle(), boneID)
end

---@return number|nil
function Ped:GetVehicleSeat()
	if (not self:IsValid() or not self:IsAlive() or self:IsOnFoot()) then
		return
	end

	return Game.GetPedVehicleSeat(self:GetHandle())
end

---@return table
function Ped:GetComponentVariations()
	if not self:IsValid() then
		return {}
	end

	return Game.GetPedComponents(self:GetHandle())
end

---@param components? table
function Ped:SetComponenVariations(components)
	components = components or self:GetComponentVariations()
	Game.ApplyPedComponents(self:GetHandle(), components)
end

---@param vehicle_handle handle
---@param seatIndex? number
function Ped:WarpIntoVehicle(vehicle_handle, seatIndex)
	if not (self:IsValid() or self:IsAlive() or ENTITY.DOES_ENTITY_EXIST(vehicle_handle)) then
		return
	end

	seatIndex = seatIndex or -1
	if not VEHICLE.IS_VEHICLE_SEAT_FREE(vehicle_handle, seatIndex, true) then
		seatIndex = -2
	end

	PED.SET_PED_INTO_VEHICLE(self:GetHandle(), vehicle_handle, seatIndex)
end

function Ped:Clean()
	if not (self:IsValid() and self:IsAlive()) then
		return
	end

	local hndl = self:GetHandle()

	PED.CLEAR_PED_BLOOD_DAMAGE(hndl)
	PED.CLEAR_PED_WETNESS(hndl)
	PED.CLEAR_PED_ENV_DIRT(hndl)
	PED.RESET_PED_VISIBLE_DAMAGE(hndl)

	for i = 0, 5, 1 do
		PED.CLEAR_PED_DAMAGE_DECAL_BY_ZONE(hndl, i, "ALL")
	end
end

---@param flag_id ePedConfigFlags
---@param pBoolParam? boolean
---@return boolean
function Ped:GetConfigFlag(flag_id, pBoolParam)
	return PED.GET_PED_CONFIG_FLAG(self:GetHandle(), flag_id, pBoolParam or true)
end

---@param flag_id ePedConfigFlags
---@param value boolean
function Ped:SetConfigFlag(flag_id, value)
	PED.SET_PED_CONFIG_FLAG(self:GetHandle(), flag_id, value)
end

---@param flag_id ePedResetFlags
---@return boolean
function Ped:GetPedResetFlag(flag_id)
	return PED.GET_PED_RESET_FLAG(self:GetHandle(), flag_id)
end

---@param flag_id ePedResetFlags
---@param value boolean
function Ped:SetPedResetFlag(flag_id, value)
	PED.SET_PED_RESET_FLAG(self:GetHandle(), flag_id, value)
end

function Ped:ClearTasks()
	TASK.CLEAR_PED_TASKS(self:GetHandle())
end

function Ped:ClearTasksImmediately()
	TASK.CLEAR_PED_TASKS_IMMEDIATELY(self:GetHandle())
end

function Ped:ClearSecondaryTask()
	TASK.CLEAR_PED_SECONDARY_TASK(self:GetHandle())
end

function Ped:ClearDefaultPrimaryTask()
	TASK.CLEAR_DEFAULT_PRIMARY_TASK(self:GetHandle())
end

---@param coords vec3
function Ped:SetCoordsKeepVehicle(coords)
	PED.SET_PED_COORDS_KEEP_VEHICLE(self:GetHandle(), coords.x, coords.y, coords.z)
end

-- Teleports the ped to the provided coordinates.
--
-- You can pass an entity handle, a blip sprite number, or a vec3 as the coordinates param.
---@param where integer|vec3 -- [blip ID](https://wiki.rage.mp/wiki/Blips), entity handle, or vector3 coordinates.
---@param keep_vehicle? boolean
---@param loadGround? boolean
function Ped:Teleport(where, keep_vehicle, loadGround)
	ThreadManager:Run(function()
		if (self:IsLocalPlayer() and not self:IsOutside()) then
			Notifier:ShowError(_T("GENERIC_TELEPORT"), _T("GENERIC_TP_INTERIOR_ERR"))
			return
		end

		local coords = Game.Ensure3DCoords(where)
		if (not coords or coords:is_zero()) then
			Notifier:ShowError(_T("GENERIC_TELEPORT"), _T("GENERIC_TP_INVALID_COORDS_ERR"))
			return
		end

		if (loadGround) then
			TaskWait(Game.LoadGroundAtCoord, { coords }, 500)
		end

		if (not keep_vehicle and not self:IsOnFoot()) then
			self:ClearTasksImmediately()
			sleep(50)
		end

		local dir     = self:GetPos() - coords
		local heading = MISC.GET_HEADING_FROM_VECTOR_2D(dir.x, dir.y)
		self:SetHeading(heading)
		self:SetCoordsKeepVehicle(coords)
	end)
end

-- ---@return array<handle>
-- function Ped:GetNearbyPeds()
-- 	local out    = {}
-- 	local size   = 0x8
-- 	local buffer = memory.allocate(size * 0x4)

-- 	buffer:set_int(size)
-- 	local count = PED.GET_PED_NEARBY_PEDS( -- stupid ass native (skill issue, I know)
-- 		self:GetHandle(),
-- 		---@diagnostic disable-next-line
-- 		buffer,
-- 		-1
-- 	)

-- 	Backend:debug(count)
-- 	if buffer:is_valid() then
-- 		Backend:debug(buffer:add(0):get_int())
-- 		Backend:debug(buffer:add(1):get_int())
-- 		for i = 1, count do
-- 			local ped = buffer:add(i * 4):get_int()
-- 			if (ped ~= 0) then
-- 				table.insert(out, ped)
-- 			end
-- 		end
-- 	end

-- 	return out
-- end
