-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local BusinessMgr           = require("includes.features.online.business_mgr.BusinessManager")
local drawRenamePopup       = require("includes.frontend.business_mgr.helpers.front_rename_popup")
local measureBulletWidths   = require("includes.frontend.helpers.measure_text_width")
local drawNamePlate         = require("includes.frontend.business_mgr.nameplate_ui")
local drawFactory           = require("includes.frontend.business_mgr.factory_ui")

---@type array<integer>
local bulletWidths          = {}
local newNameBuff           = { value = "" }
local renamePopupLabel      = "##renameMC"
local shouldDrawRenamePopup = false

local function contextCallback()
	if (ImGui.MenuItem(_T("GENERIC_RENAME"))) then
		shouldDrawRenamePopup = true
		ImGui.CloseCurrentPopup()
	end
end

return function()
	local clubhouse = BusinessMgr:GetClubhouse()
	if (not clubhouse) then
		ImGui.Text(_T("YRV3_CLUBHOUSE_NOT_OWNED"))
		return
	end

	local customName = clubhouse:GetCustomName()
	drawNamePlate(clubhouse, {
		customName          = customName,
		contextMenuCallback = contextCallback
	})
	ImGui.Spacing()

	local lang_index  = GVars.backend.language_index
	local bulletWidth = bulletWidths[lang_index]
	if (not bulletWidth) then
		bulletWidth = measureBulletWidths({
			_T("YRV3_CASH_SAFE"),
			_T("YRV3_MC_CLIENT_BIKE_LABEL"),
		}, 60.0)

		bulletWidths[lang_index] = bulletWidth
	end

	local cashSafe  = clubhouse:GetCashSafe()
	local cashValue = cashSafe:GetCashValue()
	local maxCash   = cashSafe:GetCapacity()

	ImGui.BulletText(_T("YRV3_CASH_SAFE"))
	ImGui.SameLine(bulletWidth)
	ImGui.ProgressBar(
		cashValue / maxCash,
		-1,
		25,
		string.formatmoney(cashValue)
	)

	ImGui.BulletText(_T("YRV3_MC_CLIENT_BIKE_LABEL"))
	ImGui.SameLine(bulletWidth)
	ImGui.Text(clubhouse:GetClientBikeName())

	ImGui.BeginDisabled(not GVars.features.unsafe_feats_enabled)
	if (cashSafe:CanInstaFill()) then
		ImGui.BeginDisabled(cashValue == maxCash)
		if (GUI:Button(_T("YRV3_CASH_FILL"))) then
			cashSafe:FillNow()
		end
		ImGui.EndDisabled()
		GUI:HelpMarker(_T("YRV3_CASH_FILL_TT"))
	end

	if (cashSafe:CanLoop()) then
		ImGui.BeginDisabled(cashValue >= maxCash)
		cashSafe.cash_loop_enabled = GUI:CustomToggle(_T("YRV3_CASH_LOOP"), cashSafe.cash_loop_enabled)
		ImGui.EndDisabled()
	end
	ImGui.EndDisabled()

	if (shouldDrawRenamePopup) then
		newNameBuff.value = customName
		ImGui.OpenPopup(renamePopupLabel)
		shouldDrawRenamePopup = false
	end

	if (ImGui.BeginPopupModal(
			renamePopupLabel,
			true,
			ImGuiWindowFlags.AlwaysAutoResize
			| ImGuiWindowFlags.NoSavedSettings
			| ImGuiWindowFlags.NoMove
		)) then
		drawRenamePopup(newNameBuff, clubhouse)
		ImGui.EndPopup()
	end

	ImGui.Spacing()
	ImGui.SeparatorText(_T("YRV3_BUSINESSES_LABEL"))

	local subs = clubhouse:GetSubBusinesses()
	if (not subs or #subs == 0) then
		ImGui.Text(_T("YRV3_MC_NONE_OWNED"))
		return
	end

	ImGui.BeginTabBar("##mc_businesses")
	for i, bb in ipairs(subs) do
		local norm = bb:GetNormalizedName()
		local name = norm or _T("GENERIC_UNKNOWN")
		ImGui.PushID(i)
		if (ImGui.BeginTabItem(name)) then
			drawFactory(bb)
			ImGui.EndTabItem()
		end
		ImGui.PopID()
	end
	ImGui.EndTabBar()
end
