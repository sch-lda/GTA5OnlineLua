-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


--------------------------------------
-- Class: Pair
--------------------------------------
---@class Pair<K, V> : { first: K, second: V }
---@overload fun(k: K, v: V): Pair<K, V>
local Pair = Callable("Pair", { ctor = function(t, ...) return t:new(...) end })


local _mt <const> = {}
_mt.__index       = function(self, k)
	if (k == "first") then
		return self._raw[1]
	end

	if (k == "second") then
		return self._raw[2]
	end

	return _mt[k]
end

_mt.__newindex    = function(self, k, v)
	if (type(k) == "number") then -- table.insert won't work without this
		if (k == 1) then
			self._raw[1] = v
			return
		elseif (k == 2) then
			self._raw[2] = v
			return
		else
			error("Pair index out of bounds!")
		end
	end

	if (k == "first") then
		self._raw[1] = v
		return
	end

	if (k == "second") then
		self._raw[2] = v
		return
	end

	error("Pair only supports 'first' and 'second' keys")
end

function _mt:__len()
	return 2
end

function _mt:__ipairs()
	return ipairs(self._raw)
end

function _mt:__pairs()
	return pairs(self._raw)
end

---@generic K, V
---@param a K
---@param b V
---@return Pair<K, V>
function Pair:new(a, b)
	local obj = { _raw = { a, b } }
	return setmetatable(obj, _mt)
end

return Pair
