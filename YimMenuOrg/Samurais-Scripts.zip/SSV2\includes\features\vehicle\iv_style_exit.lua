-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local FeatureBase = require("includes.modules.FeatureBase")

---@class IVStyleExit : FeatureBase
---@field private m_entity PlayerVehicle
---@field private m_triggered boolean
---@field private m_timer Timer
---@field private m_steering_timer Timer
---@field private m_pending_steering boolean
---@field private m_last_steer_angle float
local IVStyleExit = setmetatable({}, FeatureBase)
IVStyleExit.__index = IVStyleExit

---@param pv PlayerVehicle
---@return IVStyleExit
function IVStyleExit.new(pv)
	local self = FeatureBase.new(pv)
	---@diagnostic disable-next-line
	return setmetatable(self, IVStyleExit)
end

function IVStyleExit:Init()
	self.m_triggered        = false
	self.m_pending_steering = false
	self.m_last_steer_angle = 0.0
	self.m_steering_timer   = Timer(200)
	self.m_timer            = Timer(1000)
	self.m_timer:Pause()
	self.m_steering_timer:Pause()
end

function IVStyleExit:ShouldRun()
	return (self.m_entity
			and self.m_entity:IsValid()
			and self.m_entity:IsLandVehicle()
			and LocalPlayer:IsDriving()
			and LocalPlayer:IsOutside()
			and (GVars.features.vehicle.iv_exit or GVars.features.vehicle.no_wheel_recenter))
		and not Backend:AreControlsDisabled()
		and not HUD.IS_MP_TEXT_CHAT_TYPING()
end

function IVStyleExit:Cleanup()
	self.m_triggered = false
	self.m_timer:Reset()
	self.m_timer:Pause()
end

function IVStyleExit:ShouldReapplySteering()
	local fVal = math.abs(self.m_last_steer_angle)
	return math.is_inrange(fVal, 0.01, 1.0)
end

---@param keepEngineOn boolean
function IVStyleExit:LeaveVehicle(keepEngineOn)
	local vehHandle = self.m_entity:GetHandle()
	local enabled   = GVars.features.vehicle.no_wheel_recenter and self.m_entity:IsCar()
	LocalPlayer:SetConfigFlag(Enums.ePedConfigFlags.LeaveEngineOnWhenExitingVehicles, keepEngineOn)

	if (enabled) then
		self.m_last_steer_angle = self.m_entity:Resolve().m_steering_angle:get_float()
		if (not keepEngineOn) then
			VEHICLE.SET_VEHICLE_ENGINE_ON(self.m_entity:GetHandle(), false, true, false)
		end
	end

	TASK.TASK_LEAVE_VEHICLE(LocalPlayer:GetHandle(), vehHandle, 0)

	if (self:ShouldReapplySteering()) then
		self.m_pending_steering = true
		self.m_steering_timer:Reset()
		self.m_steering_timer:Resume()
	end

	self:Cleanup()
end

function IVStyleExit:Update()
	local veh     = self.m_entity
	local iv_exit = GVars.features.vehicle.iv_exit
	if (iv_exit) then
		PAD.DISABLE_CONTROL_ACTION(0, 75, true)

		if (PAD.IS_DISABLED_CONTROL_PRESSED(0, 75)) then
			if (veh:GetSpeed() >= 15) then
				TASK.TASK_LEAVE_VEHICLE(LocalPlayer:GetHandle(), veh:GetHandle(), 4160)
				self:Cleanup()
				return
			end

			self.m_triggered = true
			self.m_timer:Resume()
		end
	end

	if (self.m_triggered) then
		if (PAD.IS_DISABLED_CONTROL_RELEASED(0, 75) and not self.m_timer:IsDone()) then
			self:LeaveVehicle(true)
		elseif (PAD.IS_DISABLED_CONTROL_PRESSED(0, 75) and self.m_timer:IsDone()) then
			self:LeaveVehicle(false)
		end
	end

	if (self.m_pending_steering) then
		if (veh and veh:IsValid()) then
			local pSteering = veh:Resolve().m_steering_angle
			pSteering:set_float(self.m_last_steer_angle)
		end

		if (self.m_steering_timer:IsDone()) then
			self.m_pending_steering = false
			self.m_last_steer_angle = 0.0
		end
	end

	if (self.m_triggered and not LocalPlayer:IsDriving()) then
		LocalPlayer:SetConfigFlag(Enums.ePedConfigFlags.LeaveEngineOnWhenExitingVehicles, false)
		self:Cleanup()
	end
end

return IVStyleExit
