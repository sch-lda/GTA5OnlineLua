-- Copyright (C) 2026 SAMURAI (xesdoog) & Contributors.
-- This file is part of Samurai's Scripts.
--
-- Permission is hereby granted to copy, modify, and redistribute
-- this code as long as you respect these conditions:
--	* Credit the owner and contributors.
--	* Provide a copy of or a link to the original license (GPL-3.0 or later); see LICENSE.md or <https://www.gnu.org/licenses/>.


local SGSL                    = require("includes.services.SGSL")
local RawBusinessData         = require("includes.data.yrv3_data")

---@enum eCasinoPrize
Enums.eCasinoPrize            = {
	VEHICLE  = 1,
	MYSTERY  = 2,
	CASH     = 3,
	CHIPS    = 4,
	RP       = 5,
	DISCOUNT = 6,
	CLOTHING = 7,
	RANDOM   = 8,
}

local CasinoPrizes <const>    = {
	[Enums.eCasinoPrize.VEHICLE]  = 18,
	[Enums.eCasinoPrize.MYSTERY]  = 11,
	[Enums.eCasinoPrize.CASH]     = 19,
	[Enums.eCasinoPrize.CHIPS]    = 15,
	[Enums.eCasinoPrize.RP]       = 17,
	[Enums.eCasinoPrize.DISCOUNT] = 4,
	[Enums.eCasinoPrize.CLOTHING] = 8
}

local CardNumToString <const> = {
	[0]  = "CP_CARD_KING",
	[1]  = "CP_CARD_KING",
	[11] = "CP_CARD_KING",
	[12] = "CP_CARD_KING",
}


---@class CasinoPacino
---@field private m_arcade_prop { coords: vec3, gxt: string }
---@field protected m_thread Thread?
---@field protected m_initialized boolean
local CasinoPacino   = {}
CasinoPacino.__index = CasinoPacino

---@return CasinoPacino
function CasinoPacino:init()
	if (self.m_initialized) then
		return self
	end

	local instance = setmetatable({}, self)
	instance.m_initialized = true
	instance.m_thread = ThreadManager:RegisterLooped("SS_DUNK", function()
		instance:Main()
	end)

	return instance
end

---@return boolean
function CasinoPacino:CanAccess()
	return Backend:IsUpToDate()
		and Game.IsOnline()
		and not Backend:IsMockEnv()
		and not script.is_active("maintransition")
		and not NETWORK.NETWORK_IS_ACTIVITY_SESSION()
end

---@return { coords: vec3, gxt: string }?
function CasinoPacino:GetOwnedArcade()
	if (not self.m_arcade_prop) then
		local arcade_idx = stats.get_int("MPX_ARCADE_OWNED")
		local property = RawBusinessData.Arcades[arcade_idx]
		if (not property) then
			return
		end
		self.m_arcade_prop = property
	end

	return self.m_arcade_prop
end

---@param prizeID eCasinoPrize
function CasinoPacino:GiveWheelPrize(prizeID)
	if (not script.is_active("casino_lucky_wheel")) then
		Notifier:ShowError("CasinoPacino", _T("CP_MUST_BE_AT_WHEEL"))
		return
	end

	local win_state_local         = SGSL:Get(SGSL.data.prize_wheel_win_state)
	local prize_wheel_win_state   = win_state_local:AsLocal()
	local prize_wheel_prize       = win_state_local:GetOffset(1)
	local prize_wheel_prize_state = SGSL:Get(SGSL.data.prize_wheel_prize_state):GetOffset(1)
	local idx                     = prizeID

	if (prizeID == Enums.eCasinoPrize.RANDOM) then
		math.randomseed(math.floor(os.time() * 60))
		idx = math.random(Enums.eCasinoPrize.VEHICLE, Enums.eCasinoPrize.CLOTHING)
	end

	local val = CasinoPrizes[idx]
	if (not val) then
		log.fdebug("Unknown prize ID: %d", prizeID)
		return
	end

	prize_wheel_win_state:At(prize_wheel_prize):WriteInt(val)
	prize_wheel_win_state:At(prize_wheel_prize_state):WriteInt(11)
end

---@param card_index number
function CasinoPacino:GetCardNameFromIndex(card_index)
	if (card_index == 0) then
		return "Rolling"
	end

	local cardNum  = math.fmod(card_index, 13)
	local label    = CardNumToString[cardNum]
	local cardName = label and _T(label) or tostring(cardNum)
	local cardSuit = ""

	if (card_index >= 1 or card_index <= 13) then
		cardSuit = _T("CP_CARD_CLUBS")
	elseif (card_index >= 14 or card_index <= 26) then
		cardSuit = _T("CP_CARD_DIAMONDS")
	elseif (card_index >= 27 or card_index <= 39) then
		cardSuit = _T("CP_CARD_HEARTS")
	elseif (card_index >= 40 or card_index <= 52) then
		cardSuit = _T("CP_CARD_SPADES")
	end

	return _F("%s of %s", cardName, cardSuit)
end

function CasinoPacino:ForceDealerBust()
	if (not script.is_active("three_card_poker")) then
		return
	end

	ThreadManager:Run(function()
		if (not Game.TakeControlOfScript("blackjack")) then
			return
		end

		local player_id                    = LocalPlayer:GetID()
		local bjc_obj                      = SGSL:Get(SGSL.data.blackjack_cards)
		local btp_obj                      = SGSL:Get(SGSL.data.blackjack_table_players)
		local blackjack_cards              = bjc_obj:GetValue()
		local blackjack_decks              = bjc_obj:GetOffset(1)
		local blackjack_table_players      = btp_obj:GetValue()
		local blackjack_table_players_size = btp_obj:GetOffset(1)
		local blackjack_table              = locals.get_int("blackjack",
			blackjack_table_players
			+ 1
			+ (player_id * blackjack_table_players_size)
			+ 4
		) --The Player's current table he is sitting at.

		if (blackjack_table == -1) then
			return
		end

		local BJCards = ScriptLocal(blackjack_cards, "blackjack")
			:At(blackjack_decks)
			:At(1)
			:At(blackjack_table * 13)

		BJCards:At(1):WriteInt(11)
		BJCards:At(2):WriteInt(12)
		BJCards:At(3):WriteInt(13)
		BJCards:At(12):WriteInt(3)
	end)
end

---@param player_id integer
---@param players_current_table integer
---@param card_one integer
---@param card_two integer
---@param card_three integer
function CasinoPacino:SetPokerCards(player_id, players_current_table, card_one, card_two, card_three)
	local tcpc_obj                         = SGSL:Get(SGSL.data.three_card_poker_cards)
	local tcp_ac_obj                       = SGSL:Get(SGSL.data.three_card_poker_anti_cheat)
	local three_card_poker_cards           = tcpc_obj:GetValue()
	local three_card_poker_current_deck    = tcpc_obj:GetOffset(1)
	local three_card_poker_deck_size       = SGSL:Get(SGSL.data.three_card_poker_deck_size):GetValue()
	local three_card_poker_anti_cheat      = tcp_ac_obj:GetValue()
	local three_card_poker_anti_cheat_deck = tcp_ac_obj:GetOffset(1)


	local TCPCards = ScriptLocal(three_card_poker_cards, "three_card_poker")
		:At(three_card_poker_current_deck)
		:At(1)
		:At(players_current_table * three_card_poker_deck_size)
		:At(2)

	local TCPAC    = ScriptLocal(three_card_poker_anti_cheat, "three_card_poker")
		:At(three_card_poker_anti_cheat_deck)
		:At(1)
		:At(1)
		:At(players_current_table * three_card_poker_deck_size)


	TCPCards:At(1):At(player_id * 3):WriteInt(card_one)
	TCPAC:At(1):At(player_id * 3):WriteInt(card_one)

	TCPCards:At(2):At(player_id * 3):WriteInt(card_two)
	TCPAC:At(2):At(player_id * 3):WriteInt(card_two)

	TCPCards:At(3):At(player_id * 3):WriteInt(card_three)
	TCPAC:At(3):At(player_id * 3):WriteInt(card_three)
end

function CasinoPacino:ForcePokerCards()
	if (not GVars.features.dunk.force_poker_cards or not script.is_active("three_card_poker")) then
		return
	end

	if (not Game.TakeControlOfScript("three_card_poker")) then
		return
	end

	local player_id                     = LocalPlayer:GetID()
	local tcpt_obj                      = SGSL:Get(SGSL.data.three_card_poker_table)
	local tcpc_obj                      = SGSL:Get(SGSL.data.three_card_poker_cards)
	local three_card_poker_table        = tcpt_obj:GetValue()
	local three_card_poker_table_size   = tcpt_obj:GetOffset(1)
	local three_card_poker_cards        = tcpc_obj:GetValue()
	local three_card_poker_current_deck = tcpc_obj:GetOffset(1)
	local three_card_poker_deck_size    = SGSL:Get(SGSL.data.three_card_poker_deck_size):GetValue()
	local TCTable                       = ScriptLocal(three_card_poker_table, "three_card_poker"):At(1)
	local players_current_table         = TCTable:At(player_id * three_card_poker_table_size):At(2):ReadInt()

	if (players_current_table == -1) then
		return
	end

	local PlayerCardLocal = ScriptLocal(three_card_poker_cards, "three_card_poker")
		:At(three_card_poker_current_deck)
		:At(1)
		:At(players_current_table * three_card_poker_deck_size)
		:At(2)

	local player_0_card_1 = PlayerCardLocal:At(1):At(0 * 3):ReadInt()
	local player_0_card_2 = PlayerCardLocal:At(2):At(0 * 3):ReadInt()
	local player_0_card_3 = PlayerCardLocal:At(3):At(0 * 3):ReadInt()

	if (player_0_card_1 == 50 or player_0_card_2 == 51 or player_0_card_3 == 52) then
		return
	end

	local total_players = 0
	for player_iter = 0, 31, 1 do
		local player_table = TCTable:At(player_iter * three_card_poker_table_size):At(2):ReadInt()
		if ((player_iter ~= player_id) and (player_table == players_current_table)) then
			total_players = total_players + 1
		end
	end

	for playing_player_iter = 0, total_players, 1 do
		self:SetPokerCards(playing_player_iter, players_current_table, 50, 51, 52)
	end

	if (GVars.features.dunk.set_dealers_poker_cards) then
		self:SetPokerCards(total_players + 1, players_current_table, 1, 8, 22)
	end
end

function CasinoPacino:ForceRouletteWheel()
	if (not GVars.features.dunk.force_roulette_wheel or not script.is_active("casinoroulette")) then
		return
	end

	if (not Game.TakeControlOfScript("casinoroulette")) then
		return
	end

	local rmt_obj                 = SGSL:Get(SGSL.data.roulette_master_table)
	local roulette_master_table   = rmt_obj:GetValue()
	local roulette_outcomes_table = rmt_obj:GetOffset(1)
	local roulette_ball_table     = SGSL:Get(SGSL.data.roulette_ball_table_offset):GetValue()

	for table_iter = 0, 6, 1 do
		locals.set_int(
			"casinoroulette",
			(roulette_master_table)
			+ (roulette_outcomes_table)
			+ (roulette_ball_table)
			+ (table_iter),
			18
		)
	end
end

function CasinoPacino:RigSlotMachine()
	if (not script.is_active("casino_slots")) then
		return
	end

	local needs_run        = false
	local rig_enabled      = GVars.features.dunk.rig_slot_machine
	local SlotsResultLocal = SGSL:Get(SGSL.data.slots_random_result_table):AsLocal()

	if (rig_enabled) then
		for slots_iter = 3, 196, 1 do
			if (slots_iter == 67 or slots_iter == 132) then
				goto continue
			end

			if (SlotsResultLocal:At(slots_iter):ReadInt() ~= 6) then
				needs_run = true
			end

			::continue::
		end
	else
		local sum = 0
		for slots_iter = 3, 196, 1 do
			if (slots_iter ~= 67 and slots_iter ~= 132) then
				sum = sum + SlotsResultLocal:At(slots_iter):ReadInt()
			end
		end
		needs_run = sum == 1152
	end

	if (not needs_run) then
		return
	end

	for slots_iter = 3, 196, 1 do
		if (slots_iter == 67 or slots_iter == 132) then
			goto continue
		end

		local slot_result = 6
		if (not rig_enabled) then
			math.randomseed(os.time() + slots_iter)
			slot_result = math.random(0, 7)
		end

		SlotsResultLocal:At(slots_iter):WriteInt(slot_result)

		::continue::
	end
end

function CasinoPacino:AutoPlaySlots()
	if (not GVars.features.dunk.autoplay_slots) then
		return
	end

	local slots_slot_machine_state = SGSL:Get(SGSL.data.slots_slot_machine_state):AsLocal()
	local slotstate = slots_slot_machine_state:ReadInt()
	local autoplay_cap = GVars.features.dunk.cap_slot_machine_chips
	local delay = GVars.features.dunk.autoplay_slots_delay

	if (GVars.features.dunk.autoplay_slots_delay_random) then
		math.randomseed(os.time() * 60)
		delay = math.random(500, 1e4)
	end

	if (Bit.IsBitSet(slotstate, 0)) then --The user is sitting at a slot machine.
		local chips = stats.get_int("MPX_CASINO_CHIPS")
		local chip_cap = GVars.features.dunk.slot_machine_cap
		if ((autoplay_cap and chips < chip_cap) or not autoplay_cap) then
			if (not Bit.IsBitSet(slotstate, 24)) then --The slot machine is not currently spinning.
				yield()                      -- Wait for the previous spin to clean up, if we just came from a spin.
				slotstate = Bit.Set(slotstate, 3) -- Bitwise set the 3rd bit (begin playing)
				slots_slot_machine_state:WriteInt(slotstate)
				sleep(delay)                 -- If we rewrite the begin playing bit again, the machine will get stuck.
			end
		end
	end
end

---@return string
function CasinoPacino:GetCooldownString()
	local cooldown_time = tunables.get_int("VC_CASINO_CHIP_MAX_WIN_LOSS_COOLDOWN")
	local time_delta    = os.time() - stats.get_int("MPPLY_CASINO_CHIPS_WONTIM")
	local minutes_left  = (cooldown_time - time_delta) / 60
	local chipswon_gd   = stats.get_int("MPPLY_CASINO_CHIPS_WON_GD")
	local max_chip_wins = tunables.get_int("VC_CASINO_CHIP_MAX_WIN_DAILY")

	return (chipswon_gd >= max_chip_wins)
		and _F(_T("CP_COOLDOWN_BYPASS_STATUS_FORMAT"), minutes_left)
		or _T("CP_COOLDOWN_BYPASS_STATUS_OFF")
end

---@return string
function CasinoPacino:GetBJDealerCard()
	if (not script.is_active("blackjack")) then
		return _T("CP_NOT_IN_CASINO")
	end

	local bjc_obj                      = SGSL:Get(SGSL.data.blackjack_cards)
	local bjtp_obj                     = SGSL:Get(SGSL.data.blackjack_table_players)
	local blackjack_cards              = bjc_obj:GetValue()
	local blackjack_decks              = bjc_obj:GetOffset(1)
	local blackjack_table_players      = bjtp_obj:GetValue()
	local blackjack_table_players_size = bjtp_obj:GetOffset(1)
	local blackjack_table              = locals.get_int("blackjack",
		blackjack_table_players
		+ 1
		+ (LocalPlayer:GetID() * blackjack_table_players_size)
		+ 4
	)

	if (blackjack_table == -1) then
		return _T("CP_NOT_PLAYING_BLACKJACK")
	end

	local dealers_card = locals.get_int("blackjack",
		blackjack_cards
		+ blackjack_decks
		+ 1
		+ (blackjack_table * 13)
		+ 1
	)
	return self:GetCardNameFromIndex(dealers_card)
end

function CasinoPacino:SetCartAutoGrab()
	local FMMC_OBJ     = SGSL:Get(SGSL.data.fm_mission_controller_cart_grab)
	local SceneLocal   = FMMC_OBJ:AsLocal()
	local PlaybackRate = FMMC_OBJ:GetOffset(1)
	local SceneState   = SceneLocal:ReadInt()

	if (SceneState == 3) then
		SceneLocal:WriteInt(4)
	elseif (SceneState == 4) then
		if (SceneLocal:At(PlaybackRate):ReadFloat() < 2.0) then
			SceneLocal:At(PlaybackRate):WriteFloat(2.0)
		end
	end
end

function CasinoPacino:BypassCooldown()
	if (not GVars.features.dunk.bypass_casino_bans) then
		return
	end

	stats.set_int("MPPLY_CASINO_CHIPS_WON_GD", 0)
	stats.set_int("MPPLY_CASINO_CHIPS_WONTIM", 0)
	stats.set_int("MPPLY_CASINO_GMBLNG_GD", 0)
	stats.set_int("MPPLY_CASINO_BAN_TIME", 0)
	stats.set_int("MPPLY_CASINO_CHIPS_PURTIM", 0)
	stats.set_int("MPPLY_CASINO_CHIPS_PUR_GD", 0)
	stats.set_int("MPPLY_CASINO_CHIPS_SOLD", 0)
	stats.set_int("MPPLY_CASINO_CHIPS_SELTIM", 0)
end

function CasinoPacino:Main()
	yield()

	if (not self:CanAccess()) then
		return
	end

	self:BypassCooldown()
	self:ForcePokerCards()
	self:ForceRouletteWheel()
	self:RigSlotMachine()
	self:AutoPlaySlots()

	if (script.is_active("fm_mission_controller") and GVars.features.dunk.ch_cart_autograb) then
		self:SetCartAutoGrab()
	end
end

return CasinoPacino:init()
